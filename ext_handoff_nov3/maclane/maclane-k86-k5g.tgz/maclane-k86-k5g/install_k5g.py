"""maclane k5g add-on installer (install_k5g.sh runs it).  usage: python3 install_k5g.py <add-on folder> <pack folder>
Same rules as the v2 / k5d / k5e add-ons' installers; it requires the k5e add-on (and so v2 and k5d) to be installed in the pack.  After
its own files it installs the bundled family data add-ons e, f, g (k5g/data/maclane-k86-fam-<x>.tgz) with tools/install_fam.py, which
appends their fam/FAMILIES.txt lines."""
import os, sys, hashlib, time, subprocess
A = os.path.abspath(sys.argv[1]); P = os.path.abspath(sys.argv[2]); PL = os.path.join(A, 'payload')
PACKED = '/tmp/' + 'maclane-k86'   # the root as packed, split so that a relocation never rewrites this line
MAIN_MANIFEST = 'e43670b926218d611be82a4db7c75dbb'   # md5 of MANIFEST.md5 of maclane-k86.tgz (2fa853ec), the pack this add-on extends
N = 'fs/home/claude/GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp/s86_f2b7'
FAMS = ('e', 'f', 'g')


def md5b(b): return hashlib.md5(b).hexdigest()
def die(msg, rc): print('install_k5g: ' + msg); sys.exit(rc)


# 1. the add-on itself
files = []; bad = 0
for l in open(os.path.join(A, 'MANIFEST_k5g.md5')):
    h, f = l.rstrip('\n').split('  ', 1); p = os.path.join(PL, f)
    if not os.path.isfile(p) or md5b(open(p, 'rb').read()) != h: bad += 1; print('BAD %s' % f)
    files.append(f)
print('add-on manifest: %d files, %d bad' % (len(files), bad))
if bad: die('the add-on is damaged; unpack maclane-k86-k5g.tgz again (check its md5 first)', 3)
# 2. the pack: maclane-k86 (2fa853ec), relocated, with the v2, k5d and k5e add-ons
for need in ('.root', 'MANIFEST.md5', 'tools/relocate.py', N + '/eng_p1r/pcheck.py', N + '/env86.sh', N + '/maclib.sh', 'stop.sh'):
    if not os.path.exists(os.path.join(P, need)): die('%s is not a maclane-k86 pack folder (no %s)' % (P, need), 2)
mm = md5b(open(os.path.join(P, 'MANIFEST.md5'), 'rb').read())
if mm != MAIN_MANIFEST and os.environ.get('MACLANE_K5G_ANYPACK') != '1':
    die('%s is not the maclane-k86 pack this add-on extends (MANIFEST.md5 md5 %s, want %s; MACLANE_K5G_ANYPACK=1 overrides)' % (P, mm, MAIN_MANIFEST), 2)
for need in ('v2addon/INSTALLED_v2.tsv', 'k5d/INSTALLED_k5d.tsv', N + '/U86e.sh', 'tools/cmp_v2b.py', N + '/args_A97_F_W13K3l5d.txt', N + '/args_A97_F_W13K3gB5d.txt'):
    if not os.path.exists(os.path.join(P, need)): die('the v2 / k5d add-ons are not installed in %s (no %s): install them first' % (P, need), 2)
K5E = [N + '/' + f for f in ('k5e_lib.py', 'launch_k86MS2.sh', 'outbox86_k5e.py', 'repladder_k5e.py', 'watch86_k5e.sh', 'tightwatch_k5e.sh',
                             'tighten_k5e.sh', 'mkeng_p1t.sh', 'eng_p1t/prelay2.py', 'args_A97_F_W13K3l5e.txt', 'args_A97_F_W13K3gB5e.txt', 'w13/pat_K5e_C.cfast')] + \
      ['ref/k5e/sol_S1MW07k240e.json', 'stop_k5e.sh']
ROOT = open(os.path.join(P, '.root')).read().strip()
if os.path.realpath(ROOT) != os.path.realpath(P):
    die('the pack at %s is not relocated to its folder (its .root says %s): run  bash %s/relocate.sh  first' % (P, ROOT, P), 2)
if ' ' in ROOT: die('the pack root must not contain spaces: %s' % ROOT, 2)
if not os.path.isfile(os.path.join(P, 'k5e', 'INSTALLED_k5e.tsv')) or not os.path.isfile(os.path.join(P, 'k5e', 'MANIFEST_k5e.md5')):
    die('the k5e add-on is not installed in %s (no k5e/INSTALLED_k5e.tsv): install maclane-k86-k5e.tgz first (bash install_k5e.sh)' % P, 2)
man5 = dict(reversed(l.rstrip('\n').split('  ', 1)) for l in open(os.path.join(P, 'k5e', 'MANIFEST_k5e.md5')) if '  ' in l)
for f in K5E:
    p = os.path.join(P, f)
    if not os.path.isfile(p): die('the k5e add-on is not complete in %s (no %s): install maclane-k86-k5e.tgz (bash install_k5e.sh)' % (P, f), 2)
    if f in man5 and md5b(open(p, 'rb').read().replace(ROOT.encode(), PACKED.encode())) != man5[f]:
        print('install_k5g: WARNING: %s is not the k5e add-on\'s file (k5e/MANIFEST_k5e.md5); the k5g lanes run it as it is now' % f)
# 3. plan: rewrite the packed root, compare with what the pack has
prev = {}
ip = os.path.join(P, 'k5g', 'INSTALLED_k5g.tsv')
if os.path.exists(ip):
    for l in open(ip):
        if l.startswith('#') or not l.strip(): continue
        f, h = l.rstrip('\n').split('\t')[:2]; prev[f] = h
plan = []; same = 0; upd = 0; conflicts = []; nrw = 0; nfrw = 0; inst = []
for f in files:
    src = os.path.join(PL, f); data = open(src, 'rb').read()
    if PACKED.encode() in data and b'\x00' not in data[:65536] and ROOT != PACKED:
        nrw += data.count(PACKED.encode()); nfrw += 1; data = data.replace(PACKED.encode(), ROOT.encode())
    mode = 0o755 if (os.stat(src).st_mode & 0o111 or f.endswith('.sh')) else 0o644
    d = os.path.join(P, f); inst.append((f, md5b(data)))
    if os.path.lexists(d):
        if not os.path.isfile(d) or os.path.islink(d): conflicts.append('%s (exists and is not a plain file)' % f); continue
        cur = open(d, 'rb').read()
        if cur == data: same += 1; continue
        if prev.get(f) == md5b(cur): upd += 1   # a file of an earlier install of this add-on, unchanged since: replace it
        else: conflicts.append('%s (the pack already has this file with other content)' % f); continue
    plan.append((f, data, mode))
if conflicts:
    for c in conflicts: print('CONFLICT %s' % c)
    die('%d conflicts: nothing written.  Move those files aside (or unpack the pack again) and rerun.' % len(conflicts), 4)
# 4. write (each file atomically: temp file + rename)
for f, data, mode in plan:
    d = os.path.join(P, f); os.makedirs(os.path.dirname(d), exist_ok=True)
    t = d + '.k5gtmp'
    with open(t, 'wb') as fh: fh.write(data)
    os.chmod(t, mode); os.replace(t, d)
# 5. records in <pack>/k5g/
VD = os.path.join(P, 'k5g'); os.makedirs(VD, exist_ok=True)
for fn in ('MANIFEST_k5g.md5', 'ORIGMD5_k5g.tsv', 'README_k5g.md'):
    with open(os.path.join(VD, fn), 'wb') as fh: fh.write(open(os.path.join(A, fn), 'rb').read())
with open(ip + '.tmp', 'w') as fh:
    fh.write('# file (pack relpath)\tmd5 as installed (root %s)\n' % ROOT)
    for f, h in inst: fh.write('%s\t%s\n' % (f, h))
os.replace(ip + '.tmp', ip)
with open(os.path.join(VD, 'INSTALLED.txt'), 'a') as fh:
    fh.write('%s  add-on %s -> pack %s: %d written (%d replaced), %d identical\n' % (time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), A, P, len(plan), upd, same))
print('install_k5g: %d files written (%d of them replacing an earlier install), %d already identical; root %s -> %s in %d files (%d occurrences)'
      % (len(plan), upd, same, PACKED, ROOT, nfrw, nrw))
# 6. the bundled family data add-ons, in chain order (each one's args extend the previous one's)
for x in FAMS:
    t = os.path.join(P, 'k5g', 'data', 'maclane-k86-fam-%s.tgz' % x)
    r = subprocess.run(['python3', os.path.join(P, 'tools', 'install_fam.py'), t, P], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, universal_newlines=True)
    for l in r.stdout.rstrip().splitlines(): print('  ' + l)
    if r.returncode != 0: die('family %s: install_fam.py exit %d (see above)' % (x, r.returncode), r.returncode)
print('install_k5g: families in fam/FAMILIES.txt: %s' % ' '.join(l.split()[0][4:] for l in open(os.path.join(P, 'fam', 'FAMILIES.txt')) if l.startswith('suf=')))
