#!/bin/bash
# maclane k5g add-on install: copies the add-on's payload into a maclane-k86 pack folder that is relocated and has the v2, k5d and k5e
# add-ons installed, then installs the bundled family data add-ons e, f, g (fam/FAMILIES.txt).  usage: bash install_k5g.sh [pack folder]
# (default: the maclane-k86 folder next to this add-on folder).  Same rules as install_k5e.sh (install_k5g.py): every payload file
# checked against MANIFEST_k5g.md5; the folder must be the maclane-k86 pack (its MANIFEST.md5), relocated (.root), with the earlier
# add-ons in; the packed root /tmp/maclane-k86 in text files is rewritten to the pack's root; new files only (a file the pack already
# has with other content stops the install before anything is written; identical files are skipped; files of an earlier install of
# this add-on are replaced).  Nothing to compile.  Never stops, starts or changes a running lane.  Safe to run again.
A=$(cd "$(dirname "$0")" && pwd -P)
P=${1:-$(dirname "$A")/maclane-k86}
[ -d "$P" ] || { echo "install_k5g: pack folder $P not found.  usage: bash install_k5g.sh <maclane-k86 folder>" >&2; exit 2; }
P=$(cd "$P" && pwd -P)
case "$P" in *" "*) echo "install_k5g: the pack folder path must not contain spaces: $P" >&2; exit 2;; esac
python3 "$A/install_k5g.py" "$A" "$P" || exit $?
echo "install_k5g: done.  Next:"
echo "  cd $P && bash smoke_k5g.sh               # about 15 min; must end with SMOKE-K5G: PASS (SMOKE_FAMS=g: only family g, about 7 min)"
echo "  DRY=1 bash launch_upper_fam.sh g         # the plan: lane, in-point, warm set, what stops and starts"
echo "  bash launch_upper_fam.sh g               # stops the running upper lane (results kept), starts the next k86MS<n> on K3gB5g / K3l5g"
echo "  bash status_fam.sh; bash recheck_fam.sh g <point>; bash stop_fam.sh"
