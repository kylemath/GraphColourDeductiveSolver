"""maclane k5g add-on: install a family data add-on (install_fam.sh runs it; install_k5g.py runs it for the bundled e / f / g entries).
usage: python3 install_fam.py <data add-on .tgz or folder> <pack folder>
A data add-on folder maclane-k86-fam-<x>/ holds FAMILY.txt (its one fam/FAMILIES.txt line: suf= prev= pat= pat_md5= l= l_md5= gb= gb_md5=
expect= expect_md5= status= note=...), MANIFEST.md5 (md5  relpath of every payload file) and payload/ (pack-relative paths; the root
/tmp/maclane-k86 in text files is rewritten to the pack's root)."""
import os, sys, re, hashlib, tarfile, tempfile, shutil, subprocess, time
SRC = os.path.abspath(sys.argv[1]); P = os.path.abspath(sys.argv[2])
PACKED = '/tmp/' + 'maclane-k86'   # split so that a relocation never rewrites this line
N = 'fs/home/claude/GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp/s86_f2b7'


def md5b(b): return hashlib.md5(b).hexdigest()
def die(msg, rc): print('install_fam: ' + msg); sys.exit(rc)


TMP = None
if os.path.isfile(SRC):
    TMP = tempfile.mkdtemp(prefix='install_fam_')
    with tarfile.open(SRC) as tf:
        for m in tf.getmembers():
            if m.name.startswith('/') or '..' in m.name.split('/') or not (m.isfile() or m.isdir()): die('unsafe member %r in %s' % (m.name, SRC), 3)
        if hasattr(tarfile, 'data_filter'): tf.extractall(TMP, filter='data')   # Python versions with extraction filters
        else: tf.extractall(TMP)
    tops = [d for d in os.listdir(TMP) if os.path.isdir(os.path.join(TMP, d))]
    if len(tops) != 1: die('%s must hold one folder maclane-k86-fam-<x>/' % SRC, 3)
    A = os.path.join(TMP, tops[0])
else: A = SRC
try:
    line = [l.rstrip('\n') for l in open(os.path.join(A, 'FAMILY.txt')) if l.startswith('suf=')]
    if len(line) != 1: die('%s/FAMILY.txt must hold exactly one suf= line' % A, 3)
    line = line[0]; head = line.partition(' note=')[0]; d = dict(w.split('=', 1) for w in head.split() if '=' in w); x = d.get('suf', '')
    for k in ('suf', 'prev', 'pat', 'pat_md5', 'l', 'l_md5', 'gb', 'gb_md5', 'expect', 'expect_md5', 'status'):
        if not d.get(k): die('FAMILY.txt has no %s=' % k, 3)
    if not re.match(r'^[a-z0-9]+$', x): die('bad suffix %r' % x, 3)
    files = []; bad = 0
    for l in open(os.path.join(A, 'MANIFEST.md5')):
        h, f = l.rstrip('\n').split('  ', 1); p = os.path.join(A, 'payload', f)
        if not os.path.isfile(p) or md5b(open(p, 'rb').read()) != h: bad += 1; print('BAD %s' % f)
        files.append(f)
    print('family %s data add-on: %d files, %d bad' % (x, len(files), bad))
    if bad: die('the data add-on is damaged; unpack it again (check its md5 first)', 3)
    for need in ('.root', N + '/fam_lib.py', N + '/k5e_lib.py', 'k5e/INSTALLED_k5e.tsv', 'launch_upper_fam.sh'):
        if not os.path.exists(os.path.join(P, need)): die('%s has no %s: install the k5e and k5g add-ons first' % (P, need), 2)
    ROOT = open(os.path.join(P, '.root')).read().strip()
    if os.path.realpath(ROOT) != os.path.realpath(P): die('the pack at %s is not relocated to its folder (.root says %s): run bash %s/relocate.sh first' % (P, ROOT, P), 2)
    FF = os.path.join(P, 'fam', 'FAMILIES.txt'); have = [l.rstrip('\n') for l in open(FF)] if os.path.isfile(FF) else []
    old = [l for l in have if l.startswith('suf=%s ' % x)]
    if old and old[0] != line: die('fam/FAMILIES.txt already has another line for suffix %s:\n  %s\nnothing written' % (x, old[0]), 4)
    plan = []; same = 0; conflicts = []
    for f in files:
        data = open(os.path.join(A, 'payload', f), 'rb').read()
        if PACKED.encode() in data and b'\x00' not in data[:65536] and ROOT != PACKED: data = data.replace(PACKED.encode(), ROOT.encode())
        dst = os.path.join(P, f)
        if os.path.lexists(dst):
            if not os.path.isfile(dst) or os.path.islink(dst): conflicts.append('%s (exists and is not a plain file)' % f); continue
            if open(dst, 'rb').read() == data: same += 1; continue
            conflicts.append('%s (the pack already has this file with other content)' % f); continue
        plan.append((f, data))
    if conflicts:
        for c in conflicts: print('CONFLICT %s' % c)
        die('%d conflicts: nothing written' % len(conflicts), 4)
    for f, data in plan:
        dst = os.path.join(P, f); os.makedirs(os.path.dirname(dst), exist_ok=True); t = dst + '.famtmp'
        with open(t, 'wb') as fh: fh.write(data)
        os.chmod(t, 0o644); os.replace(t, dst)
    # the line is appended only when the family checks against it (fam_lib.py famcheck with the new FAMILIES.txt)
    os.makedirs(os.path.dirname(FF), exist_ok=True); new = FF + '.new'
    with open(new, 'w') as fh:
        if not have: fh.write('# maclane upper-lane families: one line per kill family, appended by install_fam.sh (never edited).  launch_upper_fam.sh <suf> /\n'
                              '# recheck_fam.sh / smoke_fam.sh refuse a suffix whose kill file or args are missing or differ from the md5s here (args: md5 with\n'
                              '# the pack root taken out = the container\'s).  l / gb = the check / LP args, each = the prev suffix\'s args + one line cpat=<pat> (or pat=<pat>).\n')
        for l in have: fh.write(l + '\n')
        if not old: fh.write(line + '\n')
    r = subprocess.run(['python3', os.path.join(P, N, 'fam_lib.py'), 'famcheck', x], env=dict(os.environ, FAM_FILE=new), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, universal_newlines=True)
    if r.returncode != 0:
        os.remove(new); print(r.stdout.rstrip())
        for f, data in plan: os.remove(os.path.join(P, f))   # they were new: the pack is as before
        die('family %s does not check against its line: nothing installed (fam/FAMILIES.txt not changed; the %d new files removed again)' % (x, len(plan)), 5)
    os.replace(new, FF)
    with open(os.path.join(P, 'fam', 'INSTALLED_fam.txt'), 'a') as fh:
        fh.write('%s  family %s from %s: %d written, %d identical, FAMILIES.txt line %s\n' % (time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), x, SRC, len(plan), same, 'kept' if old else 'added'))
    print(r.stdout.rstrip().replace(os.path.join(P, N) + '/', '').replace(P + '/', ''))
    print('install_fam: family %s: %d files written, %d already identical; FAMILIES.txt line %s (status %s).  Next: bash smoke_fam.sh %s' % (x, len(plan), same, 'already there' if old else 'added', d['status'], x))
finally:
    if TMP: shutil.rmtree(TMP, ignore_errors=True)
