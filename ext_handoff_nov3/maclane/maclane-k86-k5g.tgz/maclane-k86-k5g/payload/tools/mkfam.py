"""maclane k5g add-on: build the data add-on of one new binder kill, maclane-k86-fam-<x>.tgz (+ .md5), for install_fam.sh.  Run it where
the kill landed (the Opus container; it reads only) with python3 3.9 or later.
usage: python3 mkfam.py <x> <prev> <out dir> [--n DIR] [--pat REL] [--llog F] [--gblog F] [--verdict S] [--status S] [--note S]
  x, prev     the new suffix and the one it extends (args K3l5<x> = K3l5<prev> + one line cpat=<kill file> (C kill) or pat=<kill file>
              (D kill); the same for K3gB5<x>)
  --n         the s86_f2b7 folder holding w13/, the args and logs/ (default: the container's)
  --pat       the kill file, relative to it (default w13/pat_K5<x>_C.cfast)
  --llog      a log whose lines up to "patterns:" become EXPECT section 1 (default logs/upper_P_K3l5<x>.log: an upperR2 start on args
              K3l5<x> + p1r/cg_keys_r13w16_16fik.txt with flags gkwin gkleaf c6le f2b7 f2b=<rules c67fa1d1 + A5 twins> rpatN=<rpatN3
              rotation-justified>, stopped once "patterns:" is out); only the f2b / gkeys / jcheck / exname / patterns lines are kept,
              paths stripped
  --gblog     the same on K3gB5<x>, EXPECT section 2 (default logs/upper_P_K3gB5<x>.log)
  --verdict   EXPECT section 3: recheck_fam.sh <x> on ref/k5e/sol_S1MW07k240e.json (default "UPPER-R2: FEASIBLE at t = 0.025171803977":
              a kill only takes configurations out of the check, so the reference point stays FEASIBLE; smoke_fam.sh checks it)
  --status    E2 once the Lead's [E2] note is in (default: E2 when the kill file's comment says [E2], else P); launch_upper_fam.sh needs
              E2 or E2_NOTE=...
  --note      one line (default: the kill file's comment, the text in parentheses)
Writes <out dir>/maclane-k86-fam-<x>/ (FAMILY.txt = its fam/FAMILIES.txt line, MANIFEST.md5, payload/ with the kill file, both args
(container root -> the packed root /tmp/maclane-k86/fs, as relocate.sh / install_fam.py expect) and fam/EXPECT_K3l5<x>_k240.txt),
<out dir>/maclane-k86-fam-<x>.tgz and its .md5.  Nothing else is written."""
import os, re, sys, hashlib, tarfile, io, gzip

CN = '/home/claude/' + 'GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp/s86_f2b7'
PACKED = '/tmp/' + 'maclane-k86'   # split: a relocation never rewrites this line
RX = re.compile(r'(?<![A-Za-z0-9_./-])(/home/claude/GraphColourDeductiveSolver/|/tmp/claude-0/|/mnt/project-files/)')   # as the pack builder
KEEP = ('f2b: ', 'gkeys: ', 'jcheck: ', 'exname: ', 'patterns: ', 'bonus links: ')
REF_T = '0.025171803977'


def md5b(b): return hashlib.md5(b).hexdigest()
def strip(l): return re.sub(r"(?<![\w.-])/[^\s,:;'\"()\[\]{}]+/([^\s/,:;'\"()\[\]{}]+)", r'\1', l.rstrip('\n'))
def die(m): print('mkfam: ' + m); sys.exit(1)


def head(log):
    """the KEEP lines of log up to its first "patterns:" line (as smoke_fam.sh / fam_lib.py expect read them)"""
    out = []
    for l in open(log, errors='replace'):
        if not l.strip() or l.startswith('hshim: '): continue
        if l.startswith(KEEP): out.append(strip(l))
        if l.startswith('patterns: '): return out
    die('%s has no "patterns:" line' % log)


def counts(pl):
    m = re.search(r'patterns: (\d+) files read.*?by d \{(.*?)\}; by kind \{(.*?)\}', pl)
    if not m: return '?'
    d9 = re.search(r'\b9: (\d+)', m.group(2)); k = dict((a, int(b)) for a, b in re.findall(r"'(\w+)': (\d+)", m.group(3)))
    return '%s files read, D %s / C %s / RPAT %s / RPATN %s, distinct d9 %s' % (m.group(1), k.get('D'), k.get('C'), k.get('RPAT'), k.get('RPATN'), d9.group(1) if d9 else '?')


def main(a):
    if len(a) < 3 or a[0].startswith('-'): print(__doc__); return 2
    x, pv, out = a[0], a[1], os.path.abspath(a[2]); o = {}; i = 3
    while i < len(a):
        if a[i] not in ('--n', '--pat', '--llog', '--gblog', '--verdict', '--status', '--note') or i + 1 >= len(a): print(__doc__); return 2
        o[a[i][2:]] = a[i + 1]; i += 2
    if not re.match(r'^[a-z0-9]+$', x) or not re.match(r'^[a-z0-9]*$', pv): die('suffixes are lower-case letters / digits')
    n = os.path.abspath(o.get('n', CN)); pat = o.get('pat', 'w13/pat_K5%s_C.cfast' % x)
    lrel, grel = 'args_A97_F_W13K3l5%s.txt' % x, 'args_A97_F_W13K3gB5%s.txt' % x
    llog = o.get('llog', os.path.join(n, 'logs', 'upper_P_K3l5%s.log' % x)); gblog = o.get('gblog', os.path.join(n, 'logs', 'upper_P_K3gB5%s.log' % x))
    for p in (os.path.join(n, pat), os.path.join(n, lrel), os.path.join(n, grel), llog, gblog):
        if not os.path.isfile(p): die('%s missing' % p)
    pb = open(os.path.join(n, pat), 'rb').read(); patabs = CN + '/' + pat
    lines = {}
    for kind, rel in (('K3l5', lrel), ('K3gB5', grel)):
        pa = os.path.join(n, 'args_A97_F_W13%s%s.txt' % (kind, pv))
        if not os.path.isfile(pa): die('%s missing (the previous family)' % pa)
        old, new = open(pa).read(), open(os.path.join(n, rel)).read()
        if PACKED in new or CN not in new: die('%s is not the container\'s file (it names the packed root, or not the container\'s s86_f2b7)' % rel)
        w = new[len(old):].split() if new.startswith(old) else None
        if w not in (['cpat=' + patabs], ['pat=' + patabs]):
            die('%s is not %s + one line cpat=%s (or pat=)' % (rel, os.path.basename(pa), patabs))
        lines[kind] = (w[0].split('=')[0], md5b(open(pa, 'rb').read()))
    s1, s2 = head(llog), head(gblog)
    txt = pb.decode('utf-8', 'replace'); cm = re.search(r'\(([^()]*(?:\([^()]*\)[^()]*)*)\)\s*$', txt.strip())
    note = o.get('note', cm.group(1) if cm else txt.strip().splitlines()[0]); note = ' '.join(note.split())
    status = o.get('status', 'E2' if '[E2]' in txt else 'P')
    if not re.match(r'^[A-Za-z0-9]+$', status): die('bad status %r' % status)
    verdict = o.get('verdict', 'UPPER-R2: FEASIBLE at t = ' + REF_T)
    if not verdict.startswith('UPPER-R2: '): die('a verdict starts "UPPER-R2: "')
    lm, gm = md5b(open(os.path.join(n, lrel), 'rb').read()), md5b(open(os.path.join(n, grel), 'rb').read())
    E = ['# EXPECT for the Studio K3l5%s / K3gB5%s + 240-key checks (family data add-on maclane-k86-fam-%s; upperR2 log lines, paths stripped).' % (x, x, x),
         '# K3l5%s = %s (%s) = K3l5%s (%s) + %s=%s (%s; %s).  K3gB5%s = %s (%s) = K3gB5%s (%s) + the same line.  Keys p1r/cg_keys_r13w16_16fik.txt (3d996dbb).'
         % (x, lrel, lm[:8], pv, lines['K3l5'][1][:8], lines['K3l5'][0], pat, md5b(pb)[:8], note, x, grel, gm[:8], pv, lines['K3gB5'][1][:8]),
         '# counts: K3l5%s: %s; K3gB5%s: %s' % (x, counts(s1[-1]), x, counts(s2[-1])),
         '# sections: 1 and 2 = the first lines (up to "patterns:") of an upperR2 run on K3l5%s / K3gB5%s (smoke_fam.sh %s steps 2 and 3, and the first'
         ' lines of step 4); 3 = the verdict of recheck_fam.sh %s on ref/k5e/sol_S1MW07k240e.json (step 4).  From %s and %s.' % (x, x, x, x, os.path.basename(llog), os.path.basename(gblog)),
         '',
         '## K3l5%s + 240 keys, upperR2 on eng_p1r, flags gkwin gkleaf c6le f2b7 f2b=rules_c67fa1d1_plus_A5_twins.json rpatN=rpatN3_rotation_justified.txt' % x] + s1 + [
         '',
         '## K3gB5%s + 240 keys (the LP family), the same flags' % x] + s2 + [
         '',
         '## recheck_fam.sh %s ref/k5e/sol_S1MW07k240e.json (= repS1MW_07, e4e93b2c; t = %s): the verdict' % (x, REF_T), verdict, '']
    ex = '\n'.join(E).encode()
    if PACKED.encode() in ex: die('EXPECT text names the packed root')
    exrel = 'fam/EXPECT_K3l5%s_k240.txt' % x
    pay = {'fs' + CN + '/' + pat: pb, exrel: ex}
    for rel in (lrel, grel):
        b = open(os.path.join(n, rel)).read()
        if PACKED in b: die('%s names the packed root already' % rel)
        pay['fs' + CN + '/' + rel] = RX.sub(lambda m: PACKED + '/fs' + m.group(1), b).encode()
    fl = ('suf=%s prev=%s pat=%s pat_md5=%s l=%s l_md5=%s gb=%s gb_md5=%s expect=%s expect_md5=%s status=%s note=%s'
          % (x, pv, pat, md5b(pb), lrel, lm, grel, gm, exrel, md5b(ex), status, note))
    top = 'maclane-k86-fam-%s' % x; A = os.path.join(out, top)
    if os.path.exists(A) or os.path.exists(A + '.tgz'): die('%s or its .tgz exists already' % A)
    files = {'FAMILY.txt': ('# maclane family data add-on %s (k5g format): bash install_fam.sh %s.tgz; then bash smoke_fam.sh %s; bash launch_upper_fam.sh %s\n%s\n'
                            % (x, top, x, x, fl)).encode(),
             'MANIFEST.md5': ''.join('%s  %s\n' % (md5b(b), r) for r, b in sorted(pay.items())).encode()}
    files.update(('payload/' + r, b) for r, b in pay.items())
    buf = io.BytesIO(); gz = gzip.GzipFile(filename='', mode='wb', fileobj=buf, mtime=0)   # the same bytes on every build
    with tarfile.open(fileobj=gz, mode='w', format=tarfile.USTAR_FORMAT) as tf:
        dirs = set()
        for r in sorted(files):
            parts = (top + '/' + r).split('/')
            for k in range(1, len(parts)):
                dd = '/'.join(parts[:k])
                if dd not in dirs:
                    dirs.add(dd); ti = tarfile.TarInfo(dd); ti.type = tarfile.DIRTYPE; ti.mode = 0o755; ti.mtime = 0; tf.addfile(ti)
            ti = tarfile.TarInfo(top + '/' + r); ti.size = len(files[r]); ti.mode = 0o644; ti.mtime = 0; tf.addfile(ti, io.BytesIO(files[r]))
    for r, b in files.items():
        p = os.path.join(A, r); os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, 'wb') as fh: fh.write(b)
    gz.close(); tb = buf.getvalue()
    with open(A + '.tgz', 'wb') as fh: fh.write(tb)
    with open(A + '.tgz.md5', 'w') as fh: fh.write('%s  %s.tgz\n' % (md5b(tb), top))
    print('mkfam: %s.tgz %s: %s' % (A, md5b(tb), fl[:fl.index(' note=')]))
    print('  K3l5%s: %s\n  K3gB5%s: %s\n  section 3: %s\n  status %s, note: %s' % (x, counts(s1[-1]), x, counts(s2[-1]), verdict, status, note))
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
