#!/bin/bash
# maclane k5g add-on: the smoke test of one family suffix x (run after its data add-on is installed; launch_upper_fam.sh x needs the
# smoke_fam_<x>.ok it writes).  One engine run at a time, 1 thread, < 2 GB; about 6 min (3 checks: two short ones, one recheck).
#  1 famcheck: x's fam/FAMILIES.txt line; the kill file, both args and the EXPECT file have the md5s listed there (args with the pack root
#    taken out = the container's); both args are the previous suffix's args + exactly one line cpat= (or pat=) naming the kill file; the status
#  2 the patterns of K3l5x + 240 keys (upperR2 on the reference point, stopped once the "patterns:" line is out): its first lines must
#    equal section 1 of fam/EXPECT_K3l5<x>_k240.txt (files read, distinct patterns by d, D / C / RPAT / RPATN), re-derived here
#  3 the same for the LP family K3gB5x: section 2
#  4 recheck_fam.sh x on the reference point ref/k5e/sol_S1MW07k240e.json (= repS1MW_07, e4e93b2c; RECHECK_UPPER=0): its verdict must be
#    section 3 of the EXPECT file, and its first lines section 1 again.  SMOKE_FAM_RECHECK=0 skips this step (and so the DRY step's
#    in-point check)
#  5 DRY=1 FORCE=1 launch_upper_fam.sh x <reference point>: the plan is made; nothing stops or starts
# env: SMOKE_MINMEM (MB; wait for that much available memory before each engine run; 0 = no wait, the Studio default)
# usage: bash smoke_fam.sh <suffix>     must end "SMOKE-FAM <x>: PASS"; logs smoke_fam_<x>*.log
R=/tmp/maclane-k86
B=$R/fs/home/claude/GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp; N=$B/s86_f2b7; NN=$N
SD=$R/fs/tmp/claude-0/-home-claude/501dd3ae-0fa3-53a8-b24b-82020727c8dd/scratchpad/sD
PATH=$R/macshim:$PATH; export PATH
. $N/maclib.sh
X=$1; [ -n "$X" ] || { echo "usage: bash smoke_fam.sh <suffix>   (suffixes: $(python3 $N/fam_lib.py families 2>/dev/null))" >&2; exit 2; }
NF=0; LOG=$R/smoke_fam_$X.log; PT=$R/ref/k5e/sol_S1MW07k240e.json
say() { echo "$*" | tee -a $LOG; }
ok() { say "   OK   $*"; }
bad() { say "   FAIL $*"; NF=$((NF + 1)); }
: > $LOG; rm -f $R/smoke_fam_$X.ok
say "maclane fam smoke, family $X, $(date -u +%Y-%m-%dT%H:%M:%SZ) on $(uname -sm)"
HERE=$(cd "$(dirname "$0")" && pwd -P)
[ "$(cd $R 2>/dev/null && pwd -P)" = "$HERE" ] || { bad "the scripts point at $R but smoke_fam.sh is in $HERE: run relocate.sh / install_k5g.sh"; exit 1; }
for f in $N/fam_lib.py $N/k5e_lib.py $N/U86e.sh $N/launch_msfam.sh $R/recheck_fam.sh $R/launch_upper_fam.sh $PT $R/tools/cmp_v2b.py; do
  [ -s $f ] || { bad "$f missing (install the k5d, k5e and k5g add-ons)"; exit 1; }; done

say "1. family $X: fam/FAMILIES.txt line, md5s, args chain"
if FC=$(python3 $N/fam_lib.py famcheck $X); then ok "$(echo "$FC" | head -1 | sed "s|$N/||g; s|$R/||g")"; echo "$FC" | tail -n +2 | tee -a $LOG
else bad "famcheck:"; echo "$FC" | tee -a $LOG; say "SMOKE-FAM $X: FAIL"; exit 1; fi
LA=$(echo "$FC" | head -1 | sed -n 's/.* l=\([^ ]*\) .*/\1/p'); GA=$(echo "$FC" | head -1 | sed -n 's/.* gb=\([^ ]*\) .*/\1/p')
EX=$(echo "$FC" | head -1 | sed -n 's/.* expect=\([^ ]*\).*/\1/p')

# the first lines of an upperR2 run on args $1 (stopped once its patterns line is out) -> $2
patrun() {
  memgate ${SMOKE_MINMEM:-0}
  (
    export STACK=s77 ARGS=$1 KEYS=$N/p1r/cg_keys_r13w16_16fik.txt FAM=full KS=0; unset EGK; . $NN/env86.sh; N=$NN
    WK=$SD/famsmoke_$$; rm -rf $WK; mkdir -p $WK; cd $N/eng_p1r; : > $2
    nice -n 12 python3 pcheck.py upperR2 $F $X nomax sol=$PT $A threads=1 work=$WK gkeys=$KEYS gkwin gkleaf \
      c6le f2b7 f2b=$N/rules/A5final/rules_c67fa1d1_plus_A5_twins.json rpatN=$N/rpat/rpatN3_rotation_justified.txt > $2 2>&1 &
    P=$!; S=0
    while kill -0 $P 2>/dev/null && [ $S -lt 600 ]; do grep -q '^patterns: ' $2 2>/dev/null && break; sleep 1; S=$((S + 1)); done
    kill $P 2>/dev/null; sleep 1; kill -9 $P 2>/dev/null; wait $P 2>/dev/null
    rm -rf $WK
  )
}
upto() { grep -v '^hshim: ' $1 | grep -v '^[[:space:]]*$' | grep -n '^patterns: ' | head -1 | cut -d: -f1; }   # lines up to the patterns line (as k5e_lib expect counts them)

say "2. patterns of K3l5$X + 240 keys (upperR2 start, eng_p1r)"
T0=$(date +%s); L1=$R/smoke_fam_${X}_l.log; patrun $LA $L1; n=$(upto $L1)
if [ -n "$n" ] && python3 $N/fam_lib.py expect $L1 $EX 1 $n > $R/smoke_fam_${X}_e1.log 2>&1; then ok "EXPECT section 1 re-derived ($(( $(date +%s) - T0 ))s): $(grep '^counts:' $R/smoke_fam_${X}_e1.log)"
else bad "EXPECT section 1 differs ($L1, $R/smoke_fam_${X}_e1.log):"; head -12 $R/smoke_fam_${X}_e1.log | tee -a $LOG; tail -3 $L1 | tee -a $LOG; fi

say "3. patterns of K3gB5$X + 240 keys (the LP family)"
T0=$(date +%s); L2=$R/smoke_fam_${X}_gb.log; patrun $GA $L2; n=$(upto $L2)
if [ -n "$n" ] && python3 $N/fam_lib.py expect $L2 $EX 2 $n > $R/smoke_fam_${X}_e2.log 2>&1; then ok "EXPECT section 2 re-derived ($(( $(date +%s) - T0 ))s): $(grep '^counts:' $R/smoke_fam_${X}_e2.log)"
else bad "EXPECT section 2 differs ($L2, $R/smoke_fam_${X}_e2.log):"; head -12 $R/smoke_fam_${X}_e2.log | tee -a $LOG; tail -3 $L2 | tee -a $LOG; fi

if [ "${SMOKE_FAM_RECHECK:-1}" != 0 ]; then
  say "4. recheck_fam.sh $X on ref/k5e/sol_S1MW07k240e.json (= repS1MW_07; RECHECK_UPPER=0; about 5 min)"
  T0=$(date +%s); memgate ${SMOKE_MINMEM:-0}
  RECHECK_UPPER=0 bash $R/recheck_fam.sh $X $PT 1 > $R/smoke_fam_${X}_recheck.out 2>&1
  UL=$N/logs/upper_F_S1MW07k240e_K3l5$X.log; V=$(grep '^UPPER-R2' $UL 2>/dev/null | tail -1)
  W=$(awk '/^## /{s++; next} s == 3 && NF && !/^#/ {print; exit}' $EX); n=$(upto $UL)
  if [ -n "$V" ] && [ "$V" = "$W" ] && [ -n "$n" ] && python3 $N/fam_lib.py expect $UL $EX 1 $n > $R/smoke_fam_${X}_e3.log 2>&1; then ok "$V, as EXPECT section 3; its first lines = section 1 ($(( $(date +%s) - T0 ))s)"
  else bad "verdict '${V:-none}' (want '$W') or its first lines differ ($UL, $R/smoke_fam_${X}_e3.log)"; tail -3 $R/smoke_fam_${X}_recheck.out | tee -a $LOG; fi
else say "4. (skipped: SMOKE_FAM_RECHECK=0)"; fi

say "5. DRY=1 FORCE=1 launch_upper_fam.sh $X <reference point> (the plan only)"
if DRY=1 FORCE=1 bash $R/launch_upper_fam.sh $X $PT > $R/smoke_fam_${X}_dry.log 2>&1 && grep -q "launch_msfam: (dry) would run: " $R/smoke_fam_${X}_dry.log; then
  ok "$(grep '^launch_msfam: k86MS' $R/smoke_fam_${X}_dry.log | sed "s|$N/||g; s|$R/||g" | cut -c1-260)"
else bad "($R/smoke_fam_${X}_dry.log):"; tail -5 $R/smoke_fam_${X}_dry.log | tee -a $LOG; fi

say ""
if [ $NF = 0 ]; then
  { date -u +%Y-%m-%dT%H:%M:%SZ; grep "^suf=$X " $R/fam/FAMILIES.txt; } > $R/smoke_fam_$X.ok
  say "SMOKE-FAM $X: PASS (log $LOG)"
else say "SMOKE-FAM $X: FAIL ($NF) (log $LOG)"; exit 1; fi
