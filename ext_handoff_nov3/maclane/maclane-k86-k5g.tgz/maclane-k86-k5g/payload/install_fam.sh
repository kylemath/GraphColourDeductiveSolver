#!/bin/bash
# maclane k5g add-on: install a family data add-on (one binder kill: its kill file, the two args, its EXPECT file and its fam/FAMILIES.txt
# line) into this pack.  usage: bash install_fam.sh <maclane-k86-fam-<x>.tgz or its unpacked folder>
# Rules as the add-ons': every file checked against the data add-on's MANIFEST.md5; the pack must be relocated and have the k5g add-on;
# new files only (a file the pack already has with other content stops the install before anything is written; identical files are
# skipped); the FAMILIES.txt line is appended only after the kill file, the args (md5s with the pack root taken out) and the EXPECT file
# check against it and both args are the previous family's + one kill line (cpat=, or pat=).  Then: bash smoke_fam.sh <x>; bash launch_upper_fam.sh <x>.
R=/tmp/maclane-k86
[ -n "$1" ] && [ -e "$1" ] || { echo "usage: bash install_fam.sh <maclane-k86-fam-<x>.tgz or folder>" >&2; exit 2; }
exec python3 $R/tools/install_fam.py "$1" $R
