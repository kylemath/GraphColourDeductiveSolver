#!/bin/bash
# maclane k5g add-on: move the Mac upper lane to the family of suffix x (LP K3gB5x, checks K3l5x, the 240 keys on eng_p1r), whatever lane
# runs now: k86MS2 (k5e add-on) -> k86MS3 -> k86MS4 ...  One script for every later binder kill: a kill only needs its data add-on
# (bash install_fam.sh maclane-k86-fam-<x>.tgz) and its smoke (bash smoke_fam.sh <x>).
#  1. checks, before anything is stopped: x has a fam/FAMILIES.txt line and its kill file and both args are there with the md5s listed
#     there (args = the previous suffix's args + one kill line cpat= or pat=: fam_lib.py famcheck); its status is E2 (else E2_NOTE="<the Lead's note>"
#     is needed and goes into run.log); smoke_fam_<x>.ok exists (FORCE=1 overrides).  The current lane = the newest k86MS<n> start line
#     of run.log.  The fallback in-point (the given one, else FAM_DEFAULT, else the current lane's own in-point; with no k86MS lane yet
#     sol_repS1MW_07, the k5e default) must be FEASIBLE on
#     K3l5x + 240 keys here; when run.log has no such check yet it is rechecked now (recheck_fam.sh, FAM_RECHECK_THREADS = 2; the
#     current lane keeps running meanwhile);
#  2. stops the current lane cleanly, keeping its outbox/upper points, rows and K.log: k86MS2 and later with stop_fam.sh <tag> (watchers,
#     ladder, tighten, checks, K run, then one last outbox pass under its own family); k86MS1 with TAG_UPPER=k86MS1 bash stop.sh upper
#     plus the last K3l pass;
#  3. in-point: the newest outbox/upper point filed after the fallback, of a check family (K3l, K3l5<any>), with a lower t, that passes
#     the K3l5x recheck (newest first, at most FAM_MAXRECHECK = 3 rechecks; known K3l5x results here are reused); else the fallback.
#     A point given as argument (or INPOINT=) is the in-point itself: no search;
#  4. starts the next tag k86MS<n+1> (warm = the current lane's warm list + its rows), or restarts the current tag when it is already on
#     family x (then its own warm list and rows): launch_msfam.sh.
# usage: bash launch_upper_fam.sh <suffix> [point: cand name, outbox/upper name or sol json]
# env: DRY=1 (the plan: stops, rechecks and starts nothing), FORCE=1, E2_NOTE, FAM_DEFAULT, FAM_MAXRECHECK (3), FAM_RECHECK_THREADS (2),
#      INPOINT, and launch_msfam.sh's knobs (UPPER_THREADS, MAXIT, REPL_PAR, REPL_MINMEM, TIGHTWATCH, TIGHT_MINMEM, HSHIM_SOLVER)
R=/tmp/maclane-k86
N=$R/fs/home/claude/GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp/s86_f2b7
PATH=$R/macshim:$PATH; export PATH
X=$1; IP=${2:-$INPOINT}; DRY=${DRY:-0}; O=$R/outbox/upper; MAXR=${FAM_MAXRECHECK:-3}; RTH=${FAM_RECHECK_THREADS:-2}
say() { echo "launch_upper_fam: $*"; }
die() { echo "launch_upper_fam: $1" >&2; exit $2; }
resolve() {   # cand name / outbox name / json -> absolute json path (empty if none)
  if [ -f "$1" ]; then echo "$(cd "$(dirname "$1")" && pwd -P)/$(basename "$1")"
  elif [ -f $N/cand/$1.json ]; then echo $N/cand/$1.json
  elif [ -f $N/cand/sol_$1.json ]; then echo $N/cand/sol_$1.json
  elif [ -f $O/$1.json ]; then echo $O/$1.json
  elif [ -f $O/sol_$1.json ]; then echo $O/sol_$1.json; fi
}
running() {   # any process of upper lane $1
  pgrep -f "tag=$1 " > /dev/null || pgrep -f "(watch86|watch86_k5e|tightwatch|tightwatch_k5e)\.sh $1( |\$)" > /dev/null || pgrep -f "outbox86(_k5e|_fam)?\.(sh|py) $1( |\$)" > /dev/null || pgrep -f "repladder(_k5e)?\.py $1 " > /dev/null
}
[ -n "$X" ] || die "usage: bash launch_upper_fam.sh <suffix> [in-point]   (suffixes in fam/FAMILIES.txt: $(python3 $N/fam_lib.py families 2>/dev/null))" 2
for f in $N/launch_msfam.sh $N/fam_lib.py $N/k5e_lib.py $N/U86e.sh $R/recheck_fam.sh $R/stop_fam.sh $R/stop.sh; do [ -f $f ] || die "$f missing (install the k5d, k5e and k5g add-ons)" 2; done
[ "$DRY" = 1 ] && say "DRY RUN: nothing is stopped, rechecked or started"

# 1. the family, the lanes, the fallback in-point
FC=$(python3 $N/fam_lib.py famcheck $X) || die "family $X refused (nothing was stopped):
$FC" 2
ST=$(echo "$FC" | head -1 | sed -n 's/.* status=\([^ ]*\) .*/\1/p'); say "family $X: $(echo "$FC" | head -1 | sed "s|$N/||g")"
if [ "$ST" != E2 ]; then
  [ -n "$E2_NOTE" ] || die "family $X has status $ST in fam/FAMILIES.txt, not E2: launch it only after the Lead's [E2] note, then with E2_NOTE=\"<the note>\" bash launch_upper_fam.sh $X (nothing was stopped)" 2
  say "status $ST, launched with E2_NOTE: $E2_NOTE"
fi
[ -f $R/smoke_fam_$X.ok ] || [ "${FORCE:-0}" = 1 ] || die "no smoke_fam_$X.ok in $R: run bash smoke_fam.sh $X first (FORCE=1 overrides); nothing was stopped" 2
read CUR CS MX CIP CLA <<< "$(python3 $N/fam_lib.py lane)"
if [ "$CUR" = none ]; then CUR=k86MS1; CS=-; say "no k86MS lane in run.log yet: the previous lane is k86MS1"; fi
if [ "$CS" = "$X" ]; then TAG=$CUR; TP=$CUR; say "the newest lane $CUR is on family $X already: $(running $CUR && echo "it is running" || echo "restarting it")"
  running $CUR && die "$CUR runs on family $X already (bash $R/status_fam.sh; bash $R/stop_fam.sh $CUR to stop it)" 3
else TAG=k86MS$((MX + 1)); TP=$CUR; say "current lane $CUR (family ${CS}, $(running $CUR && echo running || echo "not running")) -> new lane $TAG on family $X"; fi
pgrep -f "tag=$TAG " > /dev/null && die "$TAG is already running" 3
if [ -n "$IP" ]; then FB=$(resolve "$IP"); [ -n "$FB" ] || die "no point $IP (cand/, outbox/upper/ or a json path)" 2; WHY="given"
elif [ -n "$FAM_DEFAULT" ]; then FB=$(resolve "$FAM_DEFAULT"); [ -n "$FB" ] || die "FAM_DEFAULT $FAM_DEFAULT not found" 2; WHY="FAM_DEFAULT"
elif [ "$CIP" = - ]; then   # no k86MS lane yet (k86MS1 runs): the k5e add-on's default, the Mac's repS1MW_07
  FB=$(resolve repS1MW_07); [ -n "$FB" ] || FB=$(resolve $R/ref/k5e/sol_S1MW07k240e.json)
  [ -n "$FB" ] || die "no in-point: name one (bash launch_upper_fam.sh $X <point>); nothing was stopped" 2; WHY="the k5e default"
else
  FB=""; [ -f "$CIP" ] && FB=$CIP
  [ -n "$FB" ] || FB=$(resolve $(basename "$CIP" .json))
  [ -n "$FB" ] || die "the current lane's in-point ($CIP) is not here: name one (bash launch_upper_fam.sh $X <point>); nothing was stopped" 2
  WHY="$CUR's"
fi
if python3 $N/fam_lib.py verified $X $FB > /dev/null 2>&1; then say "$WHY in-point $(basename $FB .json): FEASIBLE on K3l5$X here ($(python3 $N/fam_lib.py verified $X $FB | awk '{print $2, "t =", $3}'))"
elif [ "$DRY" = 1 ]; then say "$WHY in-point $(basename $FB .json): no K3l5$X check here yet; would run: bash $R/recheck_fam.sh $X $FB $RTH"
else
  say "$WHY in-point $(basename $FB .json): checking it on K3l5$X + 240 keys first (bash recheck_fam.sh, $RTH threads; $CUR keeps running)"
  bash $R/recheck_fam.sh $X $FB $RTH < /dev/null; RC=$?
  [ $RC = 0 ] || die "$(basename $FB .json): recheck_fam.sh exit $RC (1 = not FEASIBLE on K3l5$X; outbox/fam/RECHECK.txt): nothing was stopped; name another point" 1
fi

# 2. stop the current lane (results kept), one last outbox pass under its own family
if [ "$TP" != "$TAG" ] && running $TP; then
  if [ "$DRY" = 1 ]; then say "would stop $TP: $( [ $TP = k86MS1 ] && echo "TAG_UPPER=k86MS1 bash $R/stop.sh upper" || echo "bash $R/stop_fam.sh $TP")"
  else
    IT=$(grep '^iter ' $N/runK_$TP/K.log 2>/dev/null | tail -1 | cut -c1-100)
    if [ $TP = k86MS1 ]; then say "stopping $TP (TAG_UPPER=$TP bash stop.sh upper); last iteration: ${IT:-none}"; TAG_UPPER=$TP bash $R/stop.sh upper
    else say "stopping $TP (bash stop_fam.sh $TP); last iteration: ${IT:-none}"; bash $R/stop_fam.sh $TP; fi
    for i in $(seq 1 30); do running $TP || break; sleep 2; done
    running $TP && die "$TP is still running after its stop: stop it by hand, then rerun" 3
    RWF=$N/eng_p1r/rows_$TP.txt; [ -f $RWF ] || RWF=$N/eng/rows_$TP.txt
    echo "$(date -u +%H:%M:%SZ) [maclane] fam: stopped $TP for $TAG on family $X (last iteration: ${IT:-none}); kept runK_$TP/K.log, $(basename $(dirname $RWF))/rows_$TP.txt ($(grep -c . $RWF 2>/dev/null || echo 0) lines), outbox/upper" >> $N/run.log
  fi
elif [ "$TP" != "$TAG" ]; then say "$TP is not running"; fi
if [ "$DRY" != 1 ] && [ "$TP" = k86MS1 ]; then (cd $N && python3 $N/k5e_lib.py prevpass k86MS1 K3l | sed 's/^/launch_upper_fam: last outbox pass: /'); fi

# 3. the in-point
CH=$FB
if [ -z "$IP" ]; then
  PK=$(python3 $N/fam_lib.py pick $FB $MAXR 2>&1) || say "pick: $PK"
  NC=$(echo "$PK" | grep -c '^CAND '); say "$NC newer outbox/upper point(s) with t below $(basename $FB .json)'s (newest first, at most $MAXR)"
  while read -r k name js t fam; do
    [ "$k" = CAND ] || continue
    SS=$(python3 $N/fam_lib.py state $X $js | awk '{print $1}')
    if [ "$SS" = OK ]; then say "  $name (t $t, $fam): FEASIBLE on K3l5$X here already"; CH=$js; break; fi
    if [ "$SS" = NOTFEASIBLE ]; then say "  $name (t $t, $fam): checked on K3l5$X here before, not FEASIBLE: skipped"; continue; fi
    if [ "$DRY" = 1 ]; then say "  $name (t $t, $fam): would recheck (bash recheck_fam.sh $X $js $RTH)"; continue; fi
    say "  $name (t $t, $fam): rechecking on K3l5$X"
    if bash $R/recheck_fam.sh $X $js $RTH < /dev/null; then CH=$js; break; else say "  $name: not FEASIBLE on K3l5$X (or the recheck could not run)"; fi
  done <<< "$PK"
fi
say "in-point: $(basename $CH .json) ($CH, md5 $(md5sum < $CH | cut -c1-8))"
[ "$DRY" = 1 ] || echo "$(date -u +%H:%M:%SZ) [maclane] fam: in-point for $TAG (family $X): $(basename $CH .json) (md5 $(md5sum < $CH | cut -c1-8)), $( [ "$CH" = "$FB" ] && echo "the fallback ($WHY)" || echo "the newest outbox/upper point FEASIBLE on K3l5$X")${E2_NOTE:+; E2_NOTE: $E2_NOTE}" >> $N/run.log

# 4. start
DRY=$DRY TAG=$TAG PREV_TAG=$TP FAM_SUFFIX=$X exec bash $N/launch_msfam.sh $CH
