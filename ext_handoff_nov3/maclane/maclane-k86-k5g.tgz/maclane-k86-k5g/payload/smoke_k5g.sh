#!/bin/bash
# maclane k5g add-on smoke test (run after install_k5g.sh): the generic scripts, the families e / f / g in fam/FAMILIES.txt, then
# smoke_fam.sh for each family of SMOKE_FAMS (default "f g"; about 6 min each, one engine run at a time, 1 thread, < 2 GB).  Each family
# that passes gets its smoke_fam_<x>.ok (launch_upper_fam.sh <x> needs it).  Nothing here stops, starts or touches a running lane.
# usage: bash smoke_k5g.sh      must end "SMOKE-K5G: PASS"; logs smoke_k5g.log, smoke_fam_<x>*.log
R=/tmp/maclane-k86
N=$R/fs/home/claude/GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp/s86_f2b7
PATH=$R/macshim:$PATH; export PATH
NF=0; LOG=$R/smoke_k5g.log
say() { echo "$*" | tee -a $LOG; }
ok() { say "   OK   $*"; }
bad() { say "   FAIL $*"; NF=$((NF + 1)); }
: > $LOG; rm -f $R/smoke_k5g.ok
say "maclane k5g add-on smoke $(date -u +%Y-%m-%dT%H:%M:%SZ) on $(uname -sm)"
say "1. installed"
HERE=$(cd "$(dirname "$0")" && pwd -P); MISS=""; SYN=""
for f in $N/fam_lib.py $N/outbox86_fam.py $N/launch_msfam.sh $N/k5e_lib.py $N/U86e.sh $N/repladder_k5e.py $N/watch86_k5e.sh $N/tightwatch_k5e.sh \
         $N/tighten_k5e.sh $N/mkeng_p1t.sh $R/launch_upper_fam.sh $R/recheck_fam.sh $R/stop_fam.sh $R/status_fam.sh $R/smoke_fam.sh \
         $R/install_fam.sh $R/tools/install_fam.py $R/fam/FAMILIES.txt $R/ref/k5e/sol_S1MW07k240e.json; do [ -s $f ] || MISS="$MISS $(basename $f)"; done
for f in $N/launch_msfam.sh $R/launch_upper_fam.sh $R/recheck_fam.sh $R/stop_fam.sh $R/status_fam.sh $R/smoke_fam.sh $R/install_fam.sh; do
  bash -n $f 2> /dev/null || SYN="$SYN $(basename $f)"; done
for f in $N/fam_lib.py $N/outbox86_fam.py $R/tools/install_fam.py; do python3 -c "import ast, sys; ast.parse(open(sys.argv[1]).read())" $f 2> /dev/null || SYN="$SYN $(basename $f)"; done
if [ "$(cd $R 2>/dev/null && pwd -P)" != "$HERE" ]; then bad "the scripts point at $R but smoke_k5g.sh is in $HERE: run relocate.sh / install_k5g.sh"; exit 1
elif [ -n "$MISS$SYN" ]; then bad "missing:${MISS:- none}; syntax:${SYN:- ok} (install the k5e add-on, then this one)"; exit 1
else ok "k5e add-on, k5g scripts (they parse)"; fi
say "2. families in fam/FAMILIES.txt"
FS=$(python3 $N/fam_lib.py families); B=""
for x in $FS; do python3 $N/fam_lib.py famcheck $x quiet > $R/smoke_k5g_fam_$x.log 2>&1 || B="$B $x"; done
python3 -c "import sys; f = sys.argv[1:]; sys.exit(0 if all(x in f for x in 'efg') and f.index('e') < f.index('f') < f.index('g') else 1)" $FS || B="$B (want e f g in this order, have: $FS)"
if [ -z "$B" ]; then ok "$FS: every kill file and args file there with the listed md5s, each args = the previous one + one kill line"
  for x in $FS; do say "        $(grep "^suf=$x " $R/fam/FAMILIES.txt | sed 's/ note=.*//' | sed 's/\([0-9a-f]\{8\}\)[0-9a-f]\{24\}/\1/g')"; done
else bad "famcheck failed for:$B"; for x in $FS; do cat $R/smoke_k5g_fam_$x.log | tee -a $LOG; done; fi
say "3. the newest upper lane in run.log: $(python3 $N/fam_lib.py lane | sed "s|$N/||g")"
for x in ${SMOKE_FAMS:-f g}; do
  say "4.$x smoke_fam.sh $x"
  if bash $R/smoke_fam.sh $x > $R/smoke_k5g_$x.out 2>&1; then ok "$(tail -1 $R/smoke_k5g_$x.out)"; grep -E '^   (OK|FAIL) ' $R/smoke_fam_$x.log | sed 's/^/     /' | cut -c1-230 | tee -a $LOG > /dev/null
  else bad "$(tail -1 $R/smoke_k5g_$x.out)"; grep -E '^[0-9]\. |^   (OK|FAIL) ' $R/smoke_fam_$x.log | tee -a $LOG; fi
done
say ""
if [ $NF = 0 ]; then date -u +%Y-%m-%dT%H:%M:%SZ > $R/smoke_k5g.ok; say "SMOKE-K5G: PASS (log $LOG)"; else say "SMOKE-K5G: FAIL ($NF) (log $LOG)"; exit 1; fi
