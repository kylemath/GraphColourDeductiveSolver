#!/bin/bash
# maclane k5e add-on stop: stops the upper lane k86MS2.  Watchers first (watch86_k5e, tightwatch_k5e: no new checks start), then the
# ladder, the tighten runs and the lane's upperR2 checks, then the K run; then the outbox poller, followed by one last outbox pass
# (outbox86_k5e.py <tag> once).  usage: bash stop_k5e.sh   (TAG_MS2 overrides k86MS2)
# Results already written stay: cand/, outbox/upper/, runK_<tag>/K.log, eng_p1r/rows_<tag>.txt (warm rows for a restart: launch_k86MS2.sh
# adds them).  Hand-started rechecks (recheck_k5d.sh / recheck_k5e.sh) and the other lanes are not touched.
R=/tmp/maclane-k86
N=$R/fs/home/claude/GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp/s86_f2b7
SD=$R/fs/tmp/claude-0/-home-claude/501dd3ae-0fa3-53a8-b24b-82020727c8dd/scratchpad/sD
PATH=$R/macshim:$PATH; export PATH
TM=${TAG_MS2:-k86MS2}; T2=$(echo $TM | sed 's/.*\(..\)$/\1/'); RF=${REPL_FAM:-MW}
kill_tree() {   # children first (BSD / GNU pgrep -P)
  local c
  for c in $(pgrep -P $1 2>/dev/null); do kill_tree $c; done
  kill $1 2>/dev/null
}
stop_pat() {
  local p n=0
  for p in $(pgrep -f "$1" 2>/dev/null); do [ "$p" = "$$" ] && continue; kill_tree $p; n=$((n + 1)); done
  [ $n -gt 0 ] && echo "  stopped $n: $1"
  return 0
}
echo "upper lane $TM (k5e):"
stop_pat "watch86_k5e.sh $TM"; stop_pat "tightwatch_k5e.sh $TM"; stop_pat "repladder_k5e.py $TM"
stop_pat "tighten_k5e.sh $N/cand/sol_(${TM}_in|rep${T2}${RF}_)"
stop_pat "U86e.sh (sol_${TM}_in|F_rep${T2}${RF}_|F_${TM}_in)"; stop_pat "work=$SD/wr86r_(sol_${TM}_in|F_rep${T2}${RF}_|F_${TM}_in)"
stop_pat "runK86p.sh [0-9]+ [0-9]+ $TM "; stop_pat "tag=$TM "
stop_pat "outbox86_k5e.py $TM"
sleep 2
(cd $N && python3 $N/outbox86_k5e.py $TM once | sed 's/^/  last outbox pass: /')
left=$(pgrep -f "tag=$TM " 2>/dev/null | wc -l | tr -d ' ')
echo "processes of $TM still running: $left"
exit 0
