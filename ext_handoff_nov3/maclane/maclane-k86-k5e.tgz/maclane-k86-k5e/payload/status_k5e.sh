#!/bin/bash
# maclane k5e add-on status: the upper lane k86MS2 (and whether k86MS1 still runs), its last iterations, ladder and tighten lines, the
# outbox points by family.   usage: bash status_k5e.sh [lines, default 6]
R=/tmp/maclane-k86
N=$R/fs/home/claude/GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp/s86_f2b7
SD=$R/fs/tmp/claude-0/-home-claude/501dd3ae-0fa3-53a8-b24b-82020727c8dd/scratchpad/sD
. $N/maclib.sh
K=${1:-6}; TM=${TAG_MS2:-k86MS2}; TP=${PREV_TAG:-k86MS1}; O=$R/outbox/upper
up() { if pgrep -f "$1" > /dev/null 2>&1; then echo "running"; else echo "-"; fi; }
echo "== maclane k5e $(date -u +%Y-%m-%dT%H:%M:%SZ)  load:$(uptime | sed 's/.*load average[s]*://')  available memory $(memavail_mb) MB"
echo "== UPPER $TM   K run: $(up "tag=$TM ")  repladder: $(up "repladder_k5e.py $TM")  watch: $(up "watch86_k5e.sh $TM")  tightwatch: $(up "tightwatch_k5e.sh $TM")  outbox: $(up "outbox86_k5e.py $TM")  upperR2 checks now: $(pgrep -f "work=$SD/wr86r_" 2>/dev/null | wc -l | tr -d ' ')   ($TP K run: $(up "tag=$TP "))"
if [ -f $N/runK_$TM/K.log ]; then grep -E '^iter |in-point: t_in|warm rows admitted|^hshim: run|Traceback|Error' $N/runK_$TM/K.log | tail -n $K | cut -c1-220
else echo "  (no K.log yet)"; fi
echo "-- ladder / tighten / in-points (run.log, last $K):"
grep -E "\[s86REP-$TM\]|\[s86T\] tighten|\[watch86-$TM\]|\[maclane-outbox-$TM\]|\[maclane-outbox-k5e" $N/run.log 2>/dev/null | tail -n $K | cut -c1-240
echo "-- outbox/upper/POINTS.txt (name  t  md5  family  log  filed-at): $(grep -c '    K3l5e    ' $O/POINTS.txt 2>/dev/null) K3l5e, $(grep -c '    K3gB5e    ' $O/POINTS.txt 2>/dev/null) K3gB5e, $(grep -c '    K3l    ' $O/POINTS.txt 2>/dev/null) K3l lines; last $K:"
[ -f $O/POINTS.txt ] && tail -n $K $O/POINTS.txt
echo "-- outbox/k5e/RECHECK.txt (last $K):"
[ -f $R/outbox/k5e/RECHECK.txt ] && tail -n $K $R/outbox/k5e/RECHECK.txt
exit 0
