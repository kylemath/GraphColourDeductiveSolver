#!/bin/bash
# maclane k5e add-on smoke test (run after install_k5e.sh; about 17 min in the container, 1 thread, < 2 GB, one process at a time).
# OK / FAIL per step; must end "SMOKE-K5E: PASS".  Nothing it does touches k86MS1 / k86MS2 / the other lanes or the outbox/upper folder.
#  1 installed: the v2 + k5d add-ons, this add-on's files (bash -n on its scripts), eng_p1r's separators
#  2 the families: args_A97_F_W13K3gB5e.txt / args_A97_F_W13K3l5e.txt are the container's (md5 8849c09f / 2b31d32d with the pack root
#    taken out), w13/pat_K5e_C.cfast is 9d00aa01, and every file they name is in the pack
#  3 recheck_k5e.sh (RECHECK_UPPER=0) on the Mac's own point repS1MW_07 (ref/k5e/sol_S1MW07k240e.json, md5 e4e93b2c) on K3l5e + 240
#    keys with eng_p1r: the whole log must match the container's logs/upper_F_S1MW07k240e.log (UPPER-R2: FEASIBLE at t = 0.025171803977)
#    except its 'sender rows: min value' line (a diagnostic the pack's eng_p1r predates), and its EXPECT lines must equal section 1 of
#    EXPECT_K3l5e_k240.txt (311 files; D 18142, C 704, RPAT 158, RPATN 2034; distinct d9 3321): the EXPECT counts re-derived here
#  4 tighten_k5e.sh on that point (engine eng_p1t made by mkeng_p1t.sh; outputs in smoke_k5e_tight/, not cand/): the probe log carries the
#    container's sender line exactly, the final check is FEASIBLE at the expected tightened t.  SMOKE_K5E_TIGHT=0 skips (2 checks).
#  5 the start of k86MS2's K run (launch_k86MS2.sh's command on K3gB5e + 240 keys, eng_p1r, maxit 1, stopped once the conservation basis
#    rows are in): its first 11 lines as the container's k86GS9 K.log, and its EXPECT lines = section 2 (K3gB5e: 310 files, D 18232,
#    C 773).  SMOKE_K5E_HEAD=0 skips.
#  6 DRY=1 launch_upper_k5e.sh with that point: the plan is made (in-point FEASIBLE on K3l5e here, warm list complete); nothing starts
# Writes smoke_k5e.ok on PASS (launch_upper_k5e.sh needs it; FORCE=1 overrides).  Logs: smoke_k5e.log, smoke_k5e_*.log.
R=/tmp/maclane-k86
B=$R/fs/home/claude/GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp; N=$B/s86_f2b7; NN=$N
PATH=$R/macshim:$PATH; export PATH
NF=0; LOG=$R/smoke_k5e.log; CMP=$R/tools/cmp_v2b.py; EX=$R/ref/k5e/EXPECT_K3l5e_k240.txt; PT=$R/ref/k5e/sol_S1MW07k240e.json
SENDERS="sender rows: min value 0.974829002395 -> senders need t >= 0.025170997605"
TT_WANT="0.025170999"
say() { echo "$*" | tee -a $LOG; }
ok() { say "   OK   $*"; }
bad() { say "   FAIL $*"; NF=$((NF + 1)); }
cmd5() { python3 -c "import sys, hashlib; print(hashlib.md5(open(sys.argv[1], 'rb').read().replace(sys.argv[2].encode() + b'/fs/', b'/')).hexdigest()[:8])" "$1" "$R"; }
: > $LOG; rm -f $R/smoke_k5e.ok
say "maclane k5e add-on smoke $(date -u +%Y-%m-%dT%H:%M:%SZ) on $(uname -sm)"

say "1. installed"
HERE=$(cd "$(dirname "$0")" && pwd -P); MISS=""; SYN=""
for b in eng_p1r/bin/jsepf_gk_k192 eng_p1r/bin/jsepf_gk eng_p1r/bin/jsep3; do [ -x $N/$b ] || MISS="$MISS $b"; done
for f in $N/U86e.sh $N/args_A97_F_W13K3l5d.txt $N/w13/pat_K5d_D.out $N/w13/pat_K5c_C.cfast $N/args_A97_F_W13K3gB5e.txt $N/args_A97_F_W13K3l5e.txt \
         $N/w13/pat_K5e_C.cfast $N/eng_p1t/prelay2.py $N/k5e_lib.py $N/outbox86_k5e.py $N/repladder_k5e.py $N/launch_k86MS2.sh $N/mkeng_p1t.sh \
         $N/watch86_k5e.sh $N/tightwatch_k5e.sh $N/tighten_k5e.sh $N/tighten_floor.py $N/maclib.sh $R/launch_upper_k5e.sh $R/recheck_k5e.sh \
         $R/stop_k5e.sh $R/status_k5e.sh $CMP $EX $PT $R/ref/k5e/upper_F_S1MW07k240e.log $R/ref/k5e/K_k86GS9_head11.log; do
  [ -s $f ] || MISS="$MISS $(basename $f)"; done
for f in $N/launch_k86MS2.sh $N/mkeng_p1t.sh $N/watch86_k5e.sh $N/tightwatch_k5e.sh $N/tighten_k5e.sh $R/launch_upper_k5e.sh $R/recheck_k5e.sh $R/stop_k5e.sh $R/status_k5e.sh; do
  bash -n $f 2> /dev/null || SYN="$SYN $(basename $f)"; done
for f in $N/k5e_lib.py $N/outbox86_k5e.py $N/repladder_k5e.py; do python3 -c "import ast, sys; ast.parse(open(sys.argv[1]).read())" $f 2> /dev/null || SYN="$SYN $(basename $f)"; done
if [ "$(cd $R 2>/dev/null && pwd -P)" != "$HERE" ]; then bad "the scripts point at $R but smoke_k5e.sh is in $HERE: run relocate.sh / install_k5e.sh"; echo "smoke_k5e: stopping"; exit 1
elif [ -n "$MISS$SYN" ]; then bad "missing:${MISS:- none}; syntax:${SYN:- ok} (install the v2 and k5d add-ons, then this one; build.sh builds eng_p1r)"; echo "smoke_k5e: stopping"; exit 1
else ok "v2 / k5d add-ons, k5e files (scripts parse), eng_p1r separators"; fi

say "2. families K3gB5e and K3l5e"
M1=$(cmd5 $N/args_A97_F_W13K3gB5e.txt); M2=$(cmd5 $N/args_A97_F_W13K3l5e.txt); M3=$(md5sum < $N/w13/pat_K5e_C.cfast | cut -c1-8); MS=""
for a in $N/args_A97_F_W13K3gB5e.txt $N/args_A97_F_W13K3l5e.txt; do
  for f in $(tr ' ,=:' '\n\n\n\n' < $a | grep "^$R/fs/" | sort -u); do [ -e $f ] || MS="$MS $(basename $f)"; done; done
MS2=$(for x in $MS; do echo $x; done | grep -v '^r_[34]\.cfast$' | tr '\n' ' ' | sed 's/ *$//')
if [ "$M1" = 8849c09f ] && [ "$M2" = 2b31d32d ] && [ "$M3" = 9d00aa01 ] && [ -z "$MS2" ]; then ok "K3gB5e $M1, K3l5e $M2 (container md5s), pat_K5e_C $M3; every file they name is in the pack${MS:+ (missing as in the container:$MS)}"
else bad "K3gB5e $M1 (want 8849c09f), K3l5e $M2 (want 2b31d32d), pat_K5e_C $M3 (want 9d00aa01), missing files: ${MS2:-none}"; fi

say "3. upper recheck on K3l5e + 240 keys (RECHECK_UPPER=0 bash recheck_k5e.sh, eng_p1r; about 5 min)"
T0=$(date +%s)
RECHECK_UPPER=0 bash $R/recheck_k5e.sh $PT 1 > $R/smoke_k5e_upper.out 2>&1
UL=$N/logs/upper_F_S1MW07k240e_K3l5e.log
grep -v '^sender rows: min value ' $R/ref/k5e/upper_F_S1MW07k240e.log > $R/smoke_k5e_upper_ref.log
if [ -f $UL ] && python3 $CMP $R/smoke_k5e_upper_ref.log $UL "UPPER-R2: " > $R/smoke_k5e_upper_cmp.log 2>&1 && grep -q "^UPPER-R2: FEASIBLE at t = 0.025171803977$" $UL; then
  ok "matches the container's log ($(( $(date +%s) - T0 ))s; $(tail -1 $R/smoke_k5e_upper_cmp.log | cut -d';' -f1)): $(grep '^UPPER-R2' $UL)"
else bad "differs from the container's log or not FEASIBLE ($(( $(date +%s) - T0 ))s; $R/smoke_k5e_upper_cmp.log, $UL):"; head -20 $R/smoke_k5e_upper_cmp.log 2>/dev/null | tee -a $LOG; tail -3 $R/smoke_k5e_upper.out | tee -a $LOG; fi
if [ -f $UL ] && python3 $N/k5e_lib.py expect $UL $EX 1 > $R/smoke_k5e_expect1.log 2>&1; then ok "EXPECT section 1 (K3l5e) re-derived: $(grep '^counts:' $R/smoke_k5e_expect1.log)"
else bad "EXPECT section 1 (K3l5e) differs ($R/smoke_k5e_expect1.log):"; head -12 $R/smoke_k5e_expect1.log | tee -a $LOG; fi

if [ "${SMOKE_K5E_TIGHT:-1}" != 0 ]; then
  say "4. tighten_k5e.sh on that point (eng_p1t; probe + final check, about 10 min; outputs in smoke_k5e_tight/)"
  T0=$(date +%s); rm -rf $R/smoke_k5e_tight
  TIGHT_DIR=$R/smoke_k5e_tight bash $N/tighten_k5e.sh $PT 0.003 > $R/smoke_k5e_tight.out 2>&1; RC=$?
  PL=$N/logs/upper_F_S1MW07k240e_probe.log; TL=$N/logs/upper_F_S1MW07k240e_tight.log
  SL=$(grep '^sender rows: min value ' $PL 2>/dev/null | tail -1); TV=$(grep '^UPPER-R2' $TL 2>/dev/null | tail -1); TT=$(echo "$TV" | sed -n 's/^UPPER-R2: FEASIBLE at t = //p')
  TOK=$(python3 -c "import sys; w = sys.argv[2]; sys.exit(0 if sys.argv[1] and (w.startswith('@@') or abs(float(sys.argv[1]) - float(w)) <= 2e-9) else 1)" "$TT" "$TT_WANT" 2>/dev/null && echo 1)
  if [ $RC = 0 ] && [ "$SL" = "$SENDERS" ] && [ -n "$TT" ] && [ "$TOK" = 1 ] && [ -L $N/eng_p1t/pcheck.py ]; then
    ok "probe: the container's sender line; final: $TV (want $TT_WANT; from 0.025171803977) ($(( $(date +%s) - T0 ))s; $(grep '\[s86T\] tighten S1MW07k240e ' $N/run.log | tail -1 | sed 's/.*(floor \([0-9.]*\);.*/floor \1/'))"
  else bad "exit $RC ($(( $(date +%s) - T0 ))s; $R/smoke_k5e_tight.out): sender line '${SL:-none}' (want '$SENDERS'); final '${TV:-none}' (want t = $TT_WANT)"; tail -3 $R/smoke_k5e_tight.out | tee -a $LOG; fi
fi

if [ "${SMOKE_K5E_HEAD:-1}" != 0 ]; then
  say "5. start of k86MS2's K run on K3gB5e (launch_k86MS2.sh's command, stopped once the conservation basis rows are in)"
  T0=$(date +%s)
  (
    export STACK=s77 ARGS=$N/args_A97_F_W13K3gB5e.txt KEYS=$N/p1r/cg_keys_r13w16_16fik.txt FAM=full KS=0; unset EGK; . $NN/env86.sh; N=$NN
    XF="c6le f2b7 f2b=$N/rules/A5final/rules_c67fa1d1_plus_A5_twins.json rpatN=$N/rpat/rpatN3_rotation_justified.txt"
    WK=$SD/k5ehead_$$; mkdir -p $WK; cd $N/eng_p1r; : > $R/smoke_k5e_head.log
    PYTHONUNBUFFERED=1 nice -n 12 python3 pcheck.py solveR2 $F $X keeppen tag=k5esmokehead $A $CB warm=$(cat $N/maclane_warm_upper.txt) feas=$PT xcap=3 xpen=1e-3 lpmax=45 \
      threads=1 maxit=1 work=$WK gkeys=$KEYS gkwin gkleaf $XF inout=0.4,0.8,0.1 inoutk=4 inoutmove inoutprobe=0.25 inoutnprobe=3 q7pen=1e-3 feascols feasall consk=20 consfrac=0.25 > $R/smoke_k5e_head.log 2>&1 &
    P=$!; S=0
    while kill -0 $P 2>/dev/null && [ $S -lt 900 ]; do grep -q '^conservation basis rows added' $R/smoke_k5e_head.log 2>/dev/null && break; sleep 1; S=$((S + 1)); done
    kill $P 2>/dev/null; sleep 1; kill -9 $P 2>/dev/null; wait $P 2>/dev/null
    rm -rf $WK; rm -f $N/eng_p1r/rows_k5esmokehead.txt $N/eng_p1r/sol_k5esmokehead*.json $N/eng_p1r/cert_k5esmokehead*.json $N/eng_p1r/inject_k5esmokehead.*
  )
  if python3 $CMP $R/ref/k5e/K_k86GS9_head11.log $R/smoke_k5e_head.log "patterns:" 11 > $R/smoke_k5e_head_cmp.log 2>&1; then
    ok "first 11 lines as the container's k86GS9 K.log ($(( $(date +%s) - T0 ))s): $(grep '^conservation basis rows added' $R/smoke_k5e_head.log)"
  else bad "($(( $(date +%s) - T0 ))s; $R/smoke_k5e_head_cmp.log):"; head -12 $R/smoke_k5e_head_cmp.log | tee -a $LOG; fi
  if python3 $N/k5e_lib.py expect $R/smoke_k5e_head.log $EX 2 11 > $R/smoke_k5e_expect2.log 2>&1; then ok "EXPECT section 2 (K3gB5e) re-derived: $(grep '^counts:' $R/smoke_k5e_expect2.log)"
  else bad "EXPECT section 2 (K3gB5e) differs ($R/smoke_k5e_expect2.log):"; head -12 $R/smoke_k5e_expect2.log | tee -a $LOG; fi
fi

say "6. DRY=1 launch_upper_k5e.sh (the plan only, with the step-3 point)"
if pgrep -f "tag=k86MS2 " > /dev/null; then ok "skipped: k86MS2 is running"
else
  DRY=1 FORCE=1 bash $R/launch_upper_k5e.sh $PT > $R/smoke_k5e_dry.log 2>&1; RC=$?
  if [ $RC = 0 ] && grep -q "FEASIBLE on K3l5e here" $R/smoke_k5e_dry.log && grep -q "(dry) would run: bash .*/p1r/runK86p.sh [0-9]* [0-9]* k86MS2 inout=0.4,0.8,0.1 " $R/smoke_k5e_dry.log; then
    ok "$(grep '^launch_k86MS2: k86MS2: ' $R/smoke_k5e_dry.log | sed 's/^launch_k86MS2: //' | cut -c1-260)"
  else bad "exit $RC ($R/smoke_k5e_dry.log):"; tail -5 $R/smoke_k5e_dry.log | tee -a $LOG; fi
fi
say ""
if [ $NF = 0 ]; then say "SMOKE-K5E: PASS (log $LOG)"; date -u +%Y-%m-%dT%H:%M:%SZ > $R/smoke_k5e.ok; else say "SMOKE-K5E: FAIL ($NF failed steps; log $LOG)"; fi
[ $NF = 0 ]
