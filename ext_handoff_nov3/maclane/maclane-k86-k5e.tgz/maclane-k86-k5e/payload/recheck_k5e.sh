#!/bin/bash
# maclane k5e add-on: recheck an upper point on family K3l5e + the 240-key file with the eng_p1r engine: the exhaustive upperR2 (gkwin
# gkleaf) the container's k86GS9 ladder runs for its rechecks (repladder_e.py REPL_ARGS2 -> U86.sh with E86OVR=eng_p1r; flags c6le f2b7
# f2b=<rules c67fa1d1> rpatN=<rpatN3 rotation-justified>), as recheck_k5d.sh does for K3l5d.  About 5 min and ~1.6 GB on 1 thread.
# usage: bash recheck_k5e.sh <point> [threads, default 1]
#   point: a name in cand/ (repS1MW_07 or sol_repS1MW_07), in outbox/upper/, or the path of a sol json
# env: RECHECK_ARGS (default args_A97_F_W13K3l5e.txt), RECHECK_TAG (default F_<name>_K3l5e), RECHECK_UPPER (1; 0 = do not file into outbox/upper)
# Result: logs/upper_<tag>.log, a run.log line; in outbox/k5e/: the log and one line in RECHECK.txt (name  md5 (8)  family  verdict  log
# checked-at); and when FEASIBLE on K3l5e: outbox/upper/sol_<name>__K3l5e.json + .log and a POINTS.txt line with family K3l5e (the family
# in the file name, so a K3l point of k86MS1 and its K3l5e recheck cannot be confused).  Exit status 0 = FEASIBLE.
R=/tmp/maclane-k86
N=$R/fs/home/claude/GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp/s86_f2b7
PATH=$R/macshim:$PATH; export PATH
P=$1; TH=${2:-1}
[ -n "$P" ] || { echo "usage: bash recheck_k5e.sh <cand name, outbox/upper name or sol json> [threads]" >&2; exit 2; }
if [ -f "$P" ]; then SOL=$(cd "$(dirname "$P")" && pwd -P)/$(basename "$P")
elif [ -f $N/cand/$P.json ]; then SOL=$N/cand/$P.json
elif [ -f $N/cand/sol_$P.json ]; then SOL=$N/cand/sol_$P.json
elif [ -f $R/outbox/upper/$P.json ]; then SOL=$R/outbox/upper/$P.json
elif [ -f $R/outbox/upper/sol_$P.json ]; then SOL=$R/outbox/upper/sol_$P.json
else echo "recheck_k5e: no point $P (looked for it as a file, cand/$P.json, cand/sol_$P.json and in outbox/upper/)" >&2; exit 2; fi
NAME=$(basename $SOL .json); NAME=${NAME#sol_}; NAME=$(echo $NAME | sed 's/__K3[A-Za-z0-9]*$//')
ARG=${RECHECK_ARGS:-$N/args_A97_F_W13K3l5e.txt}; FAMN=$(basename $ARG .txt); FAMN=${FAMN#args_A97_F_W13}
TAG=${RECHECK_TAG:-F_${NAME}_$FAMN}
for f in $N/eng_p1r/bin/jsepf_gk_k192 $N/eng_p1r/bin/jsepf_gk $N/eng_p1r/bin/jsep3; do [ -x $f ] || { echo "recheck_k5e: $f missing (bash build.sh)" >&2; exit 2; }; done
for f in $ARG $N/U86e.sh $N/k5e_lib.py; do [ -f $f ] || { echo "recheck_k5e: $f missing (install_k5d.sh, install_k5e.sh)" >&2; exit 2; }; done
SD=$R/fs/tmp/claude-0/-home-claude/501dd3ae-0fa3-53a8-b24b-82020727c8dd/scratchpad/sD   # U86e.sh work dir: a killed check leaves it, and U86e.sh would reuse its class table
pgrep -f "work=$SD/wr86r_$TAG " > /dev/null && { echo "recheck_k5e: a check with tag $TAG is running already" >&2; exit 2; }
rm -rf $SD/wr86r_$TAG
echo "recheck_k5e: $NAME on $(basename $ARG) + cg_keys_r13w16_16fik.txt, engine eng_p1r, $TH thread(s): log $N/logs/upper_$TAG.log"
E86OVR=$N/eng_p1r STACK=s77 ARGS=$ARG KEYS=$N/p1r/cg_keys_r13w16_16fik.txt bash $N/U86e.sh $TAG $SOL $TH \
  c6le f2b7 f2b=$N/rules/A5final/rules_c67fa1d1_plus_A5_twins.json rpatN=$N/rpat/rpatN3_rotation_justified.txt
V=$(grep '^UPPER-R2' $N/logs/upper_$TAG.log | tail -1); [ -n "$V" ] || V="no verdict ($(grep -c Traceback $N/logs/upper_$TAG.log) tracebacks)"
O=$R/outbox/k5e; mkdir -p $O; cp $N/logs/upper_$TAG.log $O/
echo "$NAME    $(md5sum < $SOL | cut -c1-8)    $FAMN    $V    upper_$TAG.log    $(date -u +%Y-%m-%dT%H:%M:%SZ)" >> $O/RECHECK.txt
echo "recheck_k5e: $NAME: $V"
case "$V" in "UPPER-R2: FEASIBLE"*) ;; *) exit 1;; esac
if [ "$FAMN" = K3l5e ] && [ "${RECHECK_UPPER:-1}" != 0 ]; then echo "recheck_k5e: outbox/upper: $(python3 $N/k5e_lib.py file sol_$NAME $SOL $TAG)"; fi
exit 0
