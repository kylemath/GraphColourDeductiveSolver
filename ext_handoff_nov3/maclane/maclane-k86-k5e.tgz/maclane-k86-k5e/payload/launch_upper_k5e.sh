#!/bin/bash
# maclane k5e add-on: move the Mac upper lane from k86MS1 (LP on K3l, keys r13w16, engine eng) to k86MS2 (LP on K3gB5e + the 240 keys on
# eng_p1r; in-points, ladder sub-checks and tightening on K3l5e + the 240 keys; see fs/.../s86_f2b7/launch_k86MS2.sh).
#  1. checks, before anything is stopped: smoke_k5e.ok, the fallback in-point (default sol_repS1MW_07: t 0.025171803977, md5 e4e93b2c,
#     FEASIBLE on K3l5e in the container) exists in cand/ or outbox/upper/ and is FEASIBLE on K3l5e + 240 keys here; when no such check
#     is in run.log yet it is run now (recheck_k5e.sh, K5E_RECHECK_THREADS = 2 threads; k86MS1 keeps running meanwhile);
#  2. stops k86MS1 cleanly: TAG_UPPER=k86MS1 bash stop.sh upper (its watchers first, then ladder / tighten / checks, then the K run).
#     Its outbox/upper points, eng/rows_k86MS1.txt and runK_k86MS1/K.log stay; one last pass files any FEASIBLE k86MS1 point its
#     outbox86.sh had not filed yet (plain name, family K3l, as before);
#  3. in-point: the newest outbox/upper point filed after the fallback, with a lower t, that passes the K3l5e recheck (newest first, at
#     most K5E_MAXRECHECK = 3 rechecks; a point already FEASIBLE on K3l5e here needs none); else the fallback.  A point given as argument
#     (or INPOINT=) is the in-point itself: no search;
#  4. starts k86MS2 from it (launch_k86MS2.sh: warm = k86MS1's warm list + k86MS1's rows, complete lines).
# usage: bash launch_upper_k5e.sh [point: cand name, outbox/upper name or sol json]
# env: DRY=1 (show the plan: stops, rechecks and starts nothing), FORCE=1 (without smoke_k5e.ok), K5E_DEFAULT (sol_repS1MW_07),
#      K5E_MAXRECHECK (3), K5E_RECHECK_THREADS (2), INPOINT, PREV_TAG (k86MS1), and launch_k86MS2.sh's knobs (UPPER_THREADS, MAXIT,
#      REPL_PAR, REPL_MINMEM, TIGHTWATCH, TIGHT_MINMEM, WATCH_ARGS, HSHIM_SOLVER)
R=/tmp/maclane-k86
N=$R/fs/home/claude/GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp/s86_f2b7
PATH=$R/macshim:$PATH; export PATH
TM=k86MS2; TP=${PREV_TAG:-k86MS1}; DEF=${K5E_DEFAULT:-sol_repS1MW_07}; MAXR=${K5E_MAXRECHECK:-3}; RTH=${K5E_RECHECK_THREADS:-2}
DRY=${DRY:-0}; O=$R/outbox/upper; IP=${1:-$INPOINT}
say() { echo "launch_upper_k5e: $*"; }
die() { echo "launch_upper_k5e: $1" >&2; exit $2; }
resolve() {   # cand name / outbox name / json -> absolute json path (empty if none)
  if [ -f "$1" ]; then echo "$(cd "$(dirname "$1")" && pwd -P)/$(basename "$1")"
  elif [ -f $N/cand/$1.json ]; then echo $N/cand/$1.json
  elif [ -f $N/cand/sol_$1.json ]; then echo $N/cand/sol_$1.json
  elif [ -f $O/$1.json ]; then echo $O/$1.json
  elif [ -f $O/sol_$1.json ]; then echo $O/sol_$1.json; fi
}
k5e_ok() { python3 $N/k5e_lib.py verified "$1" > /dev/null 2>&1; }
for f in $N/launch_k86MS2.sh $N/k5e_lib.py $N/U86e.sh $R/recheck_k5e.sh $R/stop.sh; do [ -f $f ] || die "$f missing (install the k5d and k5e add-ons)" 2; done
[ -f $R/smoke_k5e.ok ] || [ "${FORCE:-0}" = 1 ] || die "no smoke_k5e.ok in $R: run bash smoke_k5e.sh first (FORCE=1 overrides)" 2
pgrep -f "tag=$TM " > /dev/null && die "k86MS2 is already running (bash $R/status_k5e.sh; bash $R/stop_k5e.sh to stop it)" 3
[ "$DRY" = 1 ] && say "DRY RUN: nothing is stopped, rechecked or started"

# 1. the fallback in-point (or the given one), FEASIBLE on K3l5e here before anything is stopped
if [ -n "$IP" ]; then FB=$(resolve "$IP"); [ -n "$FB" ] || die "no point $IP (cand/, outbox/upper/ or a json path)" 2; WHY="given"
else FB=$(resolve $DEF); [ -n "$FB" ] || die "the default in-point $DEF is in neither cand/ nor outbox/upper/: give one (bash launch_upper_k5e.sh <point>); nothing was stopped" 2; WHY="default"
  M=$(md5sum < $FB | cut -c1-8); [ "$DEF" != sol_repS1MW_07 ] || [ "$M" = e4e93b2c ] || say "WARNING: $DEF here has md5 $M, the container's copy e4e93b2c"
fi
if k5e_ok $FB; then say "$WHY in-point $(basename $FB .json): FEASIBLE on K3l5e here ($(python3 $N/k5e_lib.py verified $FB | awk '{print $2, "t =", $3}'))"
elif [ "$DRY" = 1 ]; then say "$WHY in-point $(basename $FB .json): no K3l5e check here yet; would run: bash $R/recheck_k5e.sh $FB $RTH"
else
  say "$WHY in-point $(basename $FB .json): checking it on K3l5e + 240 keys first (bash recheck_k5e.sh, $RTH threads; k86MS1 keeps running)"
  bash $R/recheck_k5e.sh $FB $RTH || die "$(basename $FB .json) is not FEASIBLE on K3l5e (outbox/k5e/RECHECK.txt): nothing was stopped" 1
fi

# 2. stop k86MS1, keep its results, one last outbox pass
if pgrep -f "tag=$TP " > /dev/null || pgrep -f "outbox86.sh $TP" > /dev/null || pgrep -f "repladder.py $TP" > /dev/null || pgrep -f "watch86.sh $TP" > /dev/null; then
  if [ "$DRY" = 1 ]; then say "would stop $TP: TAG_UPPER=$TP bash $R/stop.sh upper"
  else
    IT=$(grep '^iter ' $N/runK_$TP/K.log 2>/dev/null | tail -1 | cut -c1-100)
    say "stopping $TP (TAG_UPPER=$TP bash stop.sh upper); last iteration: ${IT:-none}"
    TAG_UPPER=$TP bash $R/stop.sh upper
    for i in $(seq 1 30); do pgrep -f "tag=$TP " > /dev/null || pgrep -f "outbox86.sh $TP" > /dev/null || break; sleep 2; done
    pgrep -f "tag=$TP " > /dev/null && die "$TP is still running after stop.sh upper: stop it by hand, then rerun" 3
    echo "$(date -u +%H:%M:%SZ) [maclane] k5e: stopped $TP for k86MS2 (last iteration: ${IT:-none}); kept runK_$TP/K.log, eng/rows_$TP.txt ($(grep -c . $N/eng/rows_$TP.txt 2>/dev/null || echo 0) lines), outbox/upper" >> $N/run.log
  fi
else say "$TP is not running"; fi
if [ "$DRY" != 1 ]; then (cd $N && python3 $N/k5e_lib.py prevpass $TP K3l | sed 's/^/launch_upper_k5e: last outbox pass: /'); fi

# 3. the in-point
CH=$FB
if [ -z "$IP" ]; then
  PK=$(python3 $N/k5e_lib.py pick $(basename $FB .json) $MAXR 2>&1) || say "pick: $PK"
  NC=$(echo "$PK" | grep -c '^CAND '); say "$NC newer outbox/upper point(s) with t below $(basename $FB .json)'s (newest first, at most $MAXR)"
  while read -r k name js t fam; do
    [ "$k" = CAND ] || continue
    ST=$(python3 $N/k5e_lib.py state $js | awk '{print $1}')
    if [ "$ST" = OK ]; then say "  $name (t $t, $fam): FEASIBLE on K3l5e here already"; CH=$js; break; fi
    if [ "$ST" = NOTFEASIBLE ]; then say "  $name (t $t, $fam): checked on K3l5e here before, not FEASIBLE: skipped"; continue; fi
    if [ "$DRY" = 1 ]; then say "  $name (t $t, $fam): would recheck (bash recheck_k5e.sh $js $RTH)"; continue; fi
    say "  $name (t $t, $fam): rechecking on K3l5e"
    if bash $R/recheck_k5e.sh $js $RTH < /dev/null; then CH=$js; break; else say "  $name: not FEASIBLE on K3l5e"; fi
  done <<< "$PK"
fi
say "in-point: $(basename $CH .json) ($CH, md5 $(md5sum < $CH | cut -c1-8))"
[ "$DRY" = 1 ] || echo "$(date -u +%H:%M:%SZ) [maclane] k5e: in-point for k86MS2: $(basename $CH .json) (md5 $(md5sum < $CH | cut -c1-8)), $( [ "$CH" = "$FB" ] && echo "the $WHY one" || echo "the newest outbox/upper point FEASIBLE on K3l5e")" >> $N/run.log

# 4. start k86MS2
DRY=$DRY PREV_TAG=$TP exec bash $N/launch_k86MS2.sh $CH
