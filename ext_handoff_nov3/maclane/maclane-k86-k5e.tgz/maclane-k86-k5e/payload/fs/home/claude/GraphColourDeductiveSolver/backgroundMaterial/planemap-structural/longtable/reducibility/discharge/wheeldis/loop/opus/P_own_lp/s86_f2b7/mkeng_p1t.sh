# maclane k5e add-on: make the engine dir eng_p1t = eng_p1r with one change, for tighten_k5e.sh.  The container's eng_p1r prelay2.py gained
# 3 lines at 06:39Z 8 Nov ("s86 tighten": the upperR2 log line "sender rows: min value V -> senders need t >= 1 - V", which tighten.sh's
# floor reads); the pack's eng_p1r copy predates them, and installed files are never edited.  eng_p1t/prelay2.py comes with this add-on
# (= the pack's eng_p1r/prelay2.py + those 3 lines); every other .py / .cpp file and bin/ are symlinks to ../eng_p1r/ (same separators,
# same hshim; pcheck.py takes its engine dir from its own path, so it loads eng_p1t/prelay2.py).  Idempotent; exit 0 = ready.
# usage: bash mkeng_p1t.sh
N=/tmp/maclane-k86/fs/home/claude/GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp/s86_f2b7; E=$N/eng_p1r; T=$N/eng_p1t
[ -f $T/prelay2.py ] && grep -q "senders need t >= " $T/prelay2.py || { echo "mkeng_p1t: $T/prelay2.py missing or not the k5e one (install_k5e.sh)" >&2; exit 2; }
for b in jsepf_gk_k192 jsepf_gk jsep3; do [ -x $E/bin/$b ] || { echo "mkeng_p1t: $E/bin/$b missing (bash build.sh)" >&2; exit 2; }; done
[ -L $T/bin ] || [ -e $T/bin ] || ln -s ../eng_p1r/bin $T/bin
for f in $E/*.py $E/*.cpp; do
  b=$(basename $f); [ "$b" = prelay2.py ] && continue
  [ -L $T/$b ] && continue
  [ -e $T/$b ] && { echo "mkeng_p1t: $T/$b exists and is not a link to ../eng_p1r/$b" >&2; exit 2; }
  ln -s ../eng_p1r/$b $T/$b
done
for b in pcheck.py hshim.py edge56.py bin/jsepf_gk_k192; do [ -e $T/$b ] || { echo "mkeng_p1t: $T/$b does not resolve" >&2; exit 2; }; done
exit 0
