"""maclane k5e add-on: the outbox filer of the k86MS2 lane (outbox86.sh's job, with the family in each file name).
usage: nohup python3 outbox86_k5e.py <tag> &   (launch_k86MS2.sh starts it; stop_k5e.sh stops it after one last pass:
       python3 outbox86_k5e.py <tag> once).   env: OUTBOX_UPPER (default <pack>/outbox/upper), OUTBOX_POLL (120 s), REPL_FAM (MW)
The lane's points: cand/sol_<tag>_inNN (watch86_k5e.sh), cand/sol_rep<last 2 of tag><REPL_FAM>_NN (repladder_k5e.py) and the
sol_<x>_tight points tighten_k5e.sh makes of them.  A point is filed once, under the strongest family a check of exactly this file
(same md5; k5e_lib.py) found FEASIBLE:
  K3l5e   its in-point check, its ladder sub-check (F_<x>_sub) or its tighten final (F_<x>_tight) -> <name>__K3l5e.json / .log
  K3gB5e  a ladder point whose LP-family check (F_<x>) is FEASIBLE and whose K3l5e sub-check ended without FEASIBLE (in the last pass
          also one whose sub-check never ran) -> <name>__K3gB5e.json / .log
POINTS.txt gets "<name>__<family>  t  md5  family  <name>__<family>.log  filed-at" (k86MS1's lines: plain names, family K3l);
MD5SUMS is refreshed; one run.log line per point."""
import os, re, sys, time, glob
import k5e_lib as K

TAG = sys.argv[1]; ONCE = sys.argv[2:3] == ['once']
RF = os.environ.get('REPL_FAM', 'MW'); POLL = int(os.environ.get('OUTBOX_POLL', '120'))
OWN = re.compile(r'^sol_(%s_in\d\d|rep%s%s_\d\d)(_tight)?$' % (re.escape(TAG), re.escape(TAG[-2:]), re.escape(RF)))
L = K.RunLog()


def one_pass():
    L.update(); n = 0
    for f in sorted(glob.glob(os.path.join(K.N, 'cand', 'sol_*.json'))):
        b = os.path.basename(f)[:-5]
        if not OWN.match(b) or glob.glob(os.path.join(K.O, glob.escape(b) + '__*.json')): continue
        m8 = K.md5f(f)[:8]; x = b[4:]; tq, tm = 'F_%s_sub' % x, 'F_%s' % x
        pick = None
        for tg in (b, tq, tm):
            r = L.recs.get(tg)
            if K.valid(r, m8, K.QF) and K.feasible(r) and K.log_ok(r): pick = (r, K.QF); break
        if pick is None and b.startswith('sol_rep') and not b.endswith('_tight'):
            rq, rm = L.recs.get(tq), L.recs.get(tm)
            sub_done = (K.valid(rq, m8, K.QF) and not K.feasible(rq)) or (ONCE and rq is None)
            if sub_done and K.valid(rm, m8, K.LF) and K.feasible(rm) and K.log_ok(rm): pick = (rm, K.LF)
        if pick:
            s = K.file_point(b, f, pick[0], pick[1], TAG); n += 1
            print('%s %s' % (time.strftime('%H:%M:%SZ', time.gmtime()), s), flush=True)
    return n


if ONCE:
    print('%s: %d point(s) filed' % (TAG, one_pass())); sys.exit(0)
print('%s outbox86_k5e %s: watching cand/ for the lane\'s points, outbox %s' % (time.strftime('%H:%M:%SZ', time.gmtime()), TAG, K.O), flush=True)
while True:
    try: one_pass()
    except Exception as e: print('%s pass failed: %r' % (time.strftime('%H:%M:%SZ', time.gmtime()), e), flush=True)
    time.sleep(POLL)
