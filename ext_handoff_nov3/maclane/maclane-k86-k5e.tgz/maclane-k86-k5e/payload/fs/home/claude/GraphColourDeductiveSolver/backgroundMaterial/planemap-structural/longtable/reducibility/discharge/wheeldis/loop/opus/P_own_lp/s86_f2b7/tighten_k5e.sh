# maclane k5e add-on: tighten.sh (the pack's Mac copy) for the k86MS2 lane: lower t on a point FEASIBLE on K3l5e + the 240 keys, its
# weights fixed (ladder points keep slack).  The same two steps:
# 1. probe: upperR2 at t_p = t - drop with every violated receiver listed (vfile); every row family is linear in t with coefficient 1, so
#    the floor = max(t_p + max receiver excess, t_p + cons worst excess, senders' 1 - min value)  (tighten_floor.py);
# 2. final: upperR2 at ceil(floor, 1e-9) + 1e-9 -> <TIGHT_DIR>/sol_<X>_tight.json, logs/upper_F_<X>_tight.log, one [s86T] run.log line.
# Each check runs through U86e.sh on TIGHT_ENG (default eng_p1t, made by mkeng_p1t.sh: eng_p1r + the 'senders need t >=' line the floor
# needs).  ARGS default K3l5e, KEYS default the 240 keys (p1r/cg_keys_r13w16_16fik.txt).  Any tail / pattern-free failure at the probe stops it.
# usage: [ARGS=<args> KEYS=<keys> TIGHT_ENG=<engine dir> TIGHT_DIR=<dir, default cand/>] bash tighten_k5e.sh <sol json> [probe drop, default 0.003]
N=/tmp/maclane-k86/fs/home/claude/GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp/s86_f2b7; B=$(dirname $N)
SOL=$1; DROP=${2:-0.003}; X=$(basename $SOL .json); X=${X#sol_}; TD=${TIGHT_DIR:-$N/cand}; TE=${TIGHT_ENG:-$N/eng_p1t}
export STACK=s77 ARGS=${ARGS:-$N/args_A97_F_W13K3l5e.txt} KEYS=${KEYS:-$N/p1r/cg_keys_r13w16_16fik.txt}
[ -f "$SOL" ] || { echo "tighten_k5e: no point $SOL" >&2; exit 2; }
if [ "$TE" = "$N/eng_p1t" ]; then bash $N/mkeng_p1t.sh || exit 2; fi
FAMX="c6le f2b7 f2b=$N/rules/A5final/rules_c67fa1d1_plus_A5_twins.json rpatN=$N/rpat/rpatN3_rotation_justified.txt"
mkdir -p $TD $N/logs; P=$TD/sol_${X}_probe.json
SD=/tmp/maclane-k86/fs/tmp/claude-0/-home-claude/501dd3ae-0fa3-53a8-b24b-82020727c8dd/scratchpad/sD   # U86e.sh work dirs: a check that was killed leaves its dir, and U86e.sh would reuse its class table
for w in F_${X}_probe F_${X}_tight; do pgrep -f "work=$SD/wr86r_$w " > /dev/null || rm -rf $SD/wr86r_$w; done
T0=$(python3 -c "
import json, sys; S = json.load(open(sys.argv[1])); t = S['t']; S['t'] = t - float(sys.argv[2]); S['note'] = S.get('note', '') + ' | s86 tighten probe at t - ' + sys.argv[2]; json.dump(S, open(sys.argv[3], 'w')); print(t)" $SOL $DROP $P)
rm -f $N/logs/viol_F_${X}_probe.txt $N/logs/viol_F_${X}_tight.txt
E86OVR=$TE bash $N/U86e.sh F_${X}_probe $P 1 $FAMX vK=1000000 vfile=$N/logs/viol_F_${X}_probe.txt
L=$N/logs/upper_F_${X}_probe.log
if grep -q "Traceback" $L || ! grep -q "UPPER-R2" $L; then echo "tighten_k5e $X: probe failed to run" >&2; exit 3; fi
if grep -qE "exact pattern-free: [1-9]" $L; then echo "tighten_k5e $X: tail fails at the probe; not handled" >&2; exit 4; fi
grep -q "senders need t >= " $L || { echo "tighten_k5e $X: the probe log has no 'senders need t >=' line (engine $(basename $TE))" >&2; exit 5; }
FL=$(python3 $N/tighten_floor.py $SOL $L $N/logs/viol_F_${X}_probe.txt)
read FLOOR TOLD SRC <<< "$FL"
if [ -z "$FLOOR" ]; then echo "tighten_k5e $X: could not read the floor" >&2; exit 5; fi
TT=$(python3 -c "import math; f=$FLOOR; print('%.9f' % (math.ceil(f*1e9)/1e9 + 1e-9))")
if python3 -c "import sys; sys.exit(0 if $TT < $TOLD else 1)"; then :; else echo "tighten_k5e $X: floor $FLOOR not below t $TOLD" >&2; rm -f $P; exit 6; fi
O=$TD/sol_${X}_tight.json
python3 -c "
import json, sys; S = json.load(open(sys.argv[1])); S['t'] = float(sys.argv[2]); S['note'] = S.get('note', '') + ' | s86 tighten: same weights, t = %s (floor %s)' % (sys.argv[2], sys.argv[3]); json.dump(S, open(sys.argv[4], 'w'))" $SOL $TT $FLOOR $O
E86OVR=$TE bash $N/U86e.sh F_${X}_tight $O 1 $FAMX vK=1000000 vfile=$N/logs/viol_F_${X}_tight.txt
echo "$(date -u +%H:%M:%SZ) [s86T] tighten $X ($(basename $ARGS), $(basename $TE)): t $TOLD -> $TT (floor $FLOOR; sources $SRC): $(grep 'UPPER-R2' $N/logs/upper_F_${X}_tight.log | tail -1)" >> $N/run.log
rm -f $P
grep -q "^UPPER-R2: FEASIBLE" $N/logs/upper_F_${X}_tight.log
