# maclane k5e add-on: the upper lane k86MS2 = the pack's k86MS1 (launch_k86MS1.sh: same in-out flags, separator threads, maxit and ladder
# settings) moved to the K5e family and the 240 keys, as the container's k86GS9 (launch_k86GS9.sh, its reference for the flags):
#   LP      K3gB5e = args_A97_F_W13K3gB5e.txt (container md5 8849c09f = K3gB5d + cpat w13/pat_K5e_C.cfast 9d00aa01, K-5e B2 [E2] Studio
#           K3CHK11) + keys p1r/cg_keys_r13w16_16fik.txt (240, 3d996dbb; standard coefficients, no p1r flag) on the engine eng_p1r
#           (jsepf_gk_k192 for the 89 payer-7 keys): p1r/runK86p.sh <maxit> <threads> k86MS2 inout=0.4,0.8,0.1 inoutk=4 inoutmove
#           inoutprobe=0.25 inoutnprobe=3 q7pen=1e-3 feascols feasall consk=20 consfrac=0.25
#   checks  K3l5e = args_A97_F_W13K3l5e.txt (2b31d32d = K3l5d + the same file) + the 240 keys on eng_p1r: every in-point (watch86_k5e.sh),
#           the sub-check of every ladder point (repladder_k5e.py: main check on K3gB5e decides the new in-point, as k86GS9; REPL_ARGS2 =
#           K3l5e), tightening (tightwatch_k5e.sh / tighten_k5e.sh on eng_p1t = eng_p1r + the senders' floor line, mkeng_p1t.sh)
#   outbox  outbox86_k5e.py files the lane's points into outbox/upper as <name>__K3l5e (ladder points FEASIBLE only on the LP family:
#           <name>__K3gB5e), the family also in POINTS.txt's family column
# Warm: k86MS1's warm list (runK_k86MS1/warmlist.txt, else maclane_warm_upper.txt) + the complete lines of k86MS1's rows (eng/rows_k86MS1.txt
#   -> warm/rows_MS1_snap_k86MS2.txt: no 'k86MS1' in k86MS2's command line, so ps / pgrep k86MS1 never shows it); rows the family does not admit are dropped on admission (K.log 'warm rows admitted').  On a
#   restart of k86MS2: the previous k86MS2 warm list + the complete lines of its rows (eng_p1r/rows_k86MS2.txt -> warm/rows_k86MS2_snap_<UTC>.txt);
#   its K.log is kept as runK_k86MS2/K_prev_<UTC>.log (runK86p.sh truncates K.log).
# usage: bash launch_k86MS2.sh <in-point json>   (launch_upper_k5e.sh stops k86MS1, picks the in-point and runs this.)  The in-point must be
#   upperR2 FEASIBLE on K3l5e + the 240 keys on this machine (a run.log check of this exact file: k5e_lib.py verified).
# Knobs (env): UPPER_THREADS / MAXIT / REPL_PAR (default: k86MS1's, read from run.log; else 2 / 200 / 2), REPL_MINMEM (0), TIGHTWATCH (1),
#   TIGHT_MINMEM (0), WATCH_ARGS (K3l5e), TAG (k86MS2), PREV_TAG (k86MS1), HSHIM_SOLVER, DRY=1 (print what would start, start nothing).
R=/tmp/maclane-k86
N=/tmp/maclane-k86/fs/home/claude/GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp/s86_f2b7; B=$(dirname $N)
PATH=$R/macshim:$PATH; export PATH
TAG=${TAG:-k86MS2}; TP=${PREV_TAG:-k86MS1}; DRY=${DRY:-0}; FEAS=$1; S=$(date -u +%Y%m%dT%H%MZ)
cmd5() { python3 -c "import sys, hashlib; print(hashlib.md5(open(sys.argv[1], 'rb').read().replace(sys.argv[2].encode() + b'/fs/', b'/')).hexdigest()[:8])" "$1" "$R"; }   # md5 with the pack root taken out (= the container's)
die() { echo "launch_k86MS2: $1" >&2; exit $2; }
[ -n "$FEAS" ] && [ -f "$FEAS" ] || die "usage: bash launch_k86MS2.sh <in-point json>  (or bash $R/launch_upper_k5e.sh)" 2
[ "${FEAS#/}" != "$FEAS" ] || FEAS=$(cd "$(dirname "$FEAS")" && pwd -P)/$(basename "$FEAS")
for b in jsepf_gk_k192 jsepf_gk jsep3; do [ -x $N/eng_p1r/bin/$b ] || die "eng_p1r/bin/$b missing: run build.sh first" 2; done
for f in $N/args_A97_F_W13K3gB5e.txt $N/args_A97_F_W13K3l5e.txt $N/w13/pat_K5e_C.cfast $N/w13/pat_K5d_D.out $N/U86e.sh $N/p1r/runK86p.sh \
         $N/p1r/cg_keys_r13w16_16fik.txt $N/repladder_k5e.py $N/outbox86_k5e.py $N/watch86_k5e.sh $N/tightwatch_k5e.sh $N/tighten_k5e.sh $N/maclane_warm_upper.txt; do
  [ -f $f ] || die "$f missing: install the v2, k5d and k5e add-ons" 2; done
[ "$(cmd5 $N/args_A97_F_W13K3gB5e.txt)" = 8849c09f ] && [ "$(cmd5 $N/args_A97_F_W13K3l5e.txt)" = 2b31d32d ] || die "args K3gB5e / K3l5e are not the container's (8849c09f / 2b31d32d)" 2
pgrep -f "tag=$TAG " > /dev/null && die "a run with tag=$TAG is already going (bash $R/stop_k5e.sh first)" 3
if pgrep -f "tag=$TP " > /dev/null || pgrep -f "outbox86.sh $TP" > /dev/null || pgrep -f "repladder.py $TP" > /dev/null; then
  if [ "$DRY" = 1 ]; then echo "launch_k86MS2: (dry) $TP is still running; launch_upper_k5e.sh stops it first"
  else die "$TP (or its outbox86 / repladder) is still running: stop it first (bash $R/launch_upper_k5e.sh does: TAG_UPPER=$TP bash $R/stop.sh upper)" 3; fi
fi
if V=$(python3 $N/k5e_lib.py verified $FEAS); then :
elif [ "$DRY" = 1 ]; then echo "launch_k86MS2: (dry) $(basename $FEAS) has no FEASIBLE K3l5e check here yet (launch_upper_k5e.sh rechecks it first)"; V="- (to-be-rechecked) -"
else die "in-point $FEAS is not upperR2 FEASIBLE on K3l5e + 240 keys on this machine ($V): bash $R/recheck_k5e.sh $FEAS" 2; fi
TIN=$(echo "$V" | awk '{print $3}'); MIN=$(md5sum < $FEAS | cut -c1-8)
if [ "${TIGHTWATCH:-1}" != 0 ]; then bash $N/mkeng_p1t.sh || die "eng_p1t could not be made (TIGHTWATCH=0 runs without tightening)" 2; fi
# k86MS1's settings, from its run.log lines (env overrides)
L1=$(grep "\[s86K-$TP\] start " $N/run.log 2>/dev/null | tail -1); L2=$(grep "\[maclane\] launch $TP: " $N/run.log 2>/dev/null | tail -1)
MI0=$(echo "$L1" | sed -n 's/.* maxit \([0-9]*\) threads [0-9]* .*/\1/p'); TH0=$(echo "$L1" | sed -n 's/.* maxit [0-9]* threads \([0-9]*\) .*/\1/p')
RP0=$(echo "$L2" | sed -n 's/.* REPL_PAR \([0-9]*\),.*/\1/p')
TH=${UPPER_THREADS:-${TH0:-2}}; MI=${MAXIT:-${MI0:-200}}; RP=${REPL_PAR:-${RP0:-2}}
QA=${WATCH_ARGS:-$N/args_A97_F_W13K3l5e.txt}
export STACK=s77 ARGS=$N/args_A97_F_W13K3gB5e.txt KEYS=$N/p1r/cg_keys_r13w16_16fik.txt FEAS
export XF="c6le f2b7 f2b=$N/rules/A5final/rules_c67fa1d1_plus_A5_twins.json rpatN=$N/rpat/rpatN3_rotation_justified.txt"
# warm
mkdir -p $N/warm $N/logs $N/cand $N/runK_$TAG
if [ -s $N/runK_$TAG/warmlist.txt ]; then WARM=$(cat $N/runK_$TAG/warmlist.txt); WS="the previous $TAG run's warm list"
else
  if [ -s $N/runK_$TP/warmlist.txt ]; then WARM=$(cat $N/runK_$TP/warmlist.txt); WS="$TP's warm list (runK_$TP/warmlist.txt)"
  else WARM=$(cat $N/maclane_warm_upper.txt); WS="maclane_warm_upper.txt"; fi
  if [ -s $N/eng/rows_$TP.txt ]; then
    WP=$N/warm/rows_${TP#k86}_snap_$TAG.txt
    [ "$DRY" = 1 ] || python3 $N/k5e_lib.py snaprows $N/eng/rows_$TP.txt $WP > /dev/null
    WARM=$WARM,$WP; WS="$WS + $TP's rows"
  fi
fi
if [ -s $N/eng_p1r/rows_$TAG.txt ]; then
  [ "$DRY" = 1 ] || python3 $N/k5e_lib.py snaprows $N/eng_p1r/rows_$TAG.txt $N/warm/rows_${TAG}_snap_$S.txt > /dev/null
  WARM=$WARM,$N/warm/rows_${TAG}_snap_$S.txt; WS="$WS + the previous $TAG run's rows"
fi
WARM=$(echo "$WARM" | tr ',' '\n' | awk 'NF && !s[$0]++' | paste -s -d, -); export WARM
NW=$(echo "$WARM" | tr ',' '\n' | grep -c .); MISS=""
for w in $(echo "$WARM" | tr ',' ' '); do
  [ -e $w ] && continue
  [ "$DRY" = 1 ] && [ "${w%_snap_*}" != "$w" ] && continue   # (dry: snapshots are not made)
  MISS="$MISS $w"
done
[ -z "$MISS" ] || die "warm files missing:$MISS" 2
NR=0; [ -s $N/eng/rows_$TP.txt ] && NR=$(grep -c . $N/eng/rows_$TP.txt)
echo "launch_k86MS2: $TAG: LP $(basename $ARGS) ($(cmd5 $ARGS)) + $(basename $KEYS) ($(md5sum < $KEYS | cut -c1-8)) on eng_p1r; checks on $(basename $QA) ($(cmd5 $QA)); in-point $(basename $FEAS) (md5 $MIN, t $TIN; $(echo $V | awk '{print $2}')); maxit $MI, threads $TH, REPL_PAR $RP, tightwatch ${TIGHTWATCH:-1}; $NW warm files: $WS"
if [ "$DRY" = 1 ]; then
  echo "launch_k86MS2: (dry) would run: bash $N/p1r/runK86p.sh $MI $TH $TAG inout=0.4,0.8,0.1 inoutk=4 inoutmove inoutprobe=0.25 inoutnprobe=3 q7pen=1e-3 feascols feasall consk=20 consfrac=0.25"
  echo "launch_k86MS2: (dry) + watch86_k5e.sh $TAG, outbox86_k5e.py $TAG, $( [ "${TIGHTWATCH:-1}" != 0 ] && echo "tightwatch_k5e.sh $TAG, ")repladder_k5e.py $TAG (REPL_ARGS K3gB5e, REPL_ARGS2 $(basename $QA), REPL_PAR $RP)"
  exit 0
fi
if [ -s $N/runK_$TAG/K.log ]; then mv $N/runK_$TAG/K.log $N/runK_$TAG/K_prev_$S.log; fi
echo "$(date -u +%H:%M:%SZ) [maclane] launch $TAG (k5e): LP ARGS $(basename $ARGS) (container md5 $(cmd5 $ARGS)), keys $(basename $KEYS) ($(md5sum < $KEYS | cut -c1-8)), engine eng_p1r; in-points / ladder sub-checks / tightening on $(basename $QA) ($(cmd5 $QA)); in-point $(basename $FEAS) (md5 $MIN, t = $TIN, FEASIBLE on K3l5e: $(echo $V | awk '{print $2}')), threads $TH, maxit $MI, REPL_PAR $RP, $NW warm files ($WS; $TP rows: $NR lines)" >> $N/run.log
nohup bash $N/p1r/runK86p.sh $MI $TH $TAG inout=0.4,0.8,0.1 inoutk=4 inoutmove inoutprobe=0.25 inoutnprobe=3 q7pen=1e-3 feascols feasall consk=20 consfrac=0.25 > $N/logs/runK_$TAG.out 2>&1 &
sleep 5
cd $N && ENGD=eng_p1r WATCH_ARGS=$QA nohup bash $N/watch86_k5e.sh $TAG > $N/logs/watch86_$TAG.out 2>&1 &
cd $N && REPL_FAM=MW nohup python3 $N/outbox86_k5e.py $TAG >> $N/logs/outbox86_$TAG.out 2>&1 &
if [ "${TIGHTWATCH:-1}" != 0 ]; then cd $N && ARGS=$QA REPL_FAM=MW nohup bash $N/tightwatch_k5e.sh $TAG >> $N/logs/tightwatch_$TAG.out 2>&1 & fi
cd $N && REPL_ENGD=eng_p1r REPL_FAM=MW REPL_ARGS=$ARGS REPL_ARGS2=$QA REPL_KEYS=$KEYS REPL_PAR=$RP REPL_MINMEM=${REPL_MINMEM:-0} nohup python3 $N/repladder_k5e.py $TAG $FEAS 60 >> $N/logs/repladder_$TAG.out 2>&1 &
sleep 2; echo "launched $TAG: K run log $N/runK_$TAG/K.log, outbox $R/outbox/upper/POINTS.txt (family column K3l5e / K3gB5e), status: bash $R/status_k5e.sh, stop: bash $R/stop_k5e.sh"
