# maclane k5e add-on: tightwatch.sh (the pack's Mac copy) for the k86MS2 lane.  Tightens (tighten_k5e.sh, one at a time) every point of
# the lane that an upperR2 check on the tighten family (ARGS, default K3l5e) just found FEASIBLE: its in-points (watch86_k5e.sh, tag
# sol_<tag>_inNN) and its ladder points (repladder_k5e.py's K3l5e sub-check F_rep<last 2 of tag><REPL_FAM>_NN_sub).  The container's
# tightwatch.sh triggers on the ladder's NEW IN-POINT line (the LP family's verdict) and then tightens on K3l5e; here only points already
# FEASIBLE on K3l5e are tightened, so no probe is spent on a point that cannot pass.
# usage: [ARGS=<args> KEYS=<keys> REPL_FAM=MW TIGHT_MINMEM=0] nohup bash tightwatch_k5e.sh <tag> >> logs/tightwatch_<tag>.out 2>&1 &
N=/tmp/maclane-k86/fs/home/claude/GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp/s86_f2b7; TAG=$1; cd $N; . $N/maclib.sh
TA=${ARGS:-$N/args_A97_F_W13K3l5e.txt}; TAB=$(basename $TA); T2=$(echo $TAG | sed 's/.*\(..\)$/\1/'); RF=${REPL_FAM:-MW}
tail -n0 -F run.log | while read -r line; do
  case "$line" in *"[s86U-"*"] "*" ARGS=$TAB "*": UPPER-R2: FEASIBLE at t = "*) ;; *) continue ;; esac
  tg=$(echo "$line" | sed -n 's/^[^[]*\[s86U-\([^]]*\)\] .*/\1/p')
  sol=""
  case "$tg" in
    sol_${TAG}_in[0-9][0-9]) sol=$tg.json ;;
    F_rep${T2}${RF}_[0-9][0-9]_sub) x=${tg#F_}; sol=sol_${x%_sub}.json ;;
  esac
  [ -z "$sol" ] && continue
  [ -s cand/$sol ] || { echo "$(date -u +%H:%M:%SZ) tightwatch_k5e: cand/$sol missing"; continue; }
  memgate ${TIGHT_MINMEM:-0}
  echo "$(date -u +%H:%M:%SZ) tightwatch_k5e: tightening $sol (FEASIBLE on $TAB: check $tg)"
  ARGS=$TA bash $N/tighten_k5e.sh $N/cand/$sol 0.003
done
