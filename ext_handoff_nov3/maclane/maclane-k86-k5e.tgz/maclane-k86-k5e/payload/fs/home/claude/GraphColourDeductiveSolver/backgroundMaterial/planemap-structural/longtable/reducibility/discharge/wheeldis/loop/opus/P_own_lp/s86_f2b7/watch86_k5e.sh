# maclane k5e add-on: the container's watch86e.sh (k86GS9: ENGD = engine dir) for the Mac lane k86MS2.  Checks every new in-point
# $ENGD/sol_<tag>_inNN.json of the K run with U86e.sh (E86OVR = that engine) on WATCH_ARGS (default K3l5e, the family the Mac files its
# points on; the container's k86GS9 checks its in-points on its LP family K3gB5e) + KEYS from the env, extra flags $XF.  A file that does
# not parse yet (the K run still writing it) waits for the next round.
# usage: [ENGD=eng_p1r WATCH_ARGS=<args> KEYS=<keys> XF=<flags>] nohup bash watch86_k5e.sh <tag> &      (launch_k86MS2.sh starts it)
Z=/tmp/maclane-k86/fs/home/claude/GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp/s86_f2b7; TAG=$1; ED=$Z/${ENGD:-eng_p1r}; mkdir -p $Z/cand
WA=${WATCH_ARGS:-$Z/args_A97_F_W13K3l5e.txt}
while true; do
  for f in $(ls $ED/sol_${TAG}_in[0-9][0-9].json 2>/dev/null); do
    b=$(basename $f .json); [ -e $Z/cand/$b.json ] && continue
    python3 -c "import json, sys; json.load(open(sys.argv[1]))" $f 2> /dev/null || continue
    cp $f $Z/cand/$b.json; t=$(python3 -c "import json, sys; print(json.load(open(sys.argv[1]))['t'])" $Z/cand/$b.json)
    echo "$(date -u +%H:%M:%SZ) [watch86-$TAG] candidate $b t=$t -> upperR2 on $(basename $WA) ($(basename $ED)) gkwin gkleaf $XF" >> $Z/run.log
    E86OVR=$ED STACK=s77 ARGS=$WA bash $Z/U86e.sh $b $Z/cand/$b.json 1 $XF
  done
  pgrep -f "tag=$TAG " > /dev/null || { sleep 30; exit 0; }
  sleep 60
done
