#!/bin/bash
# maclane k5e add-on install: copies the add-on's payload into a maclane-k86 pack folder that is relocated and has the v2 and k5d add-ons
# installed.  usage: bash install_k5e.sh [pack folder]   (default: the maclane-k86 folder next to this add-on folder)
# Same rules as install_v2.sh / install_k5d.sh (install_k5e.py): every payload file checked against MANIFEST_k5e.md5; the folder must be
# the maclane-k86 pack (its MANIFEST.md5), relocated (.root), with the v2 and k5d add-ons in; the packed root /tmp/maclane-k86 in the
# payload's text files is rewritten to the pack's root; new files only (a file the pack already has with other content stops the install
# before anything is written; identical files are skipped; files of an earlier install of this add-on are replaced).  Nothing to compile:
# k86MS2 runs the binaries build.sh made (eng_p1r).  Never touches a running lane's files.  Safe to run again.
A=$(cd "$(dirname "$0")" && pwd -P)
P=${1:-$(dirname "$A")/maclane-k86}
[ -d "$P" ] || { echo "install_k5e: pack folder $P not found.  usage: bash install_k5e.sh <maclane-k86 folder>" >&2; exit 2; }
P=$(cd "$P" && pwd -P)
case "$P" in *" "*) echo "install_k5e: the pack folder path must not contain spaces: $P" >&2; exit 2;; esac
python3 "$A/install_k5e.py" "$A" "$P" || exit $?
N=$P/fs/home/claude/GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp/s86_f2b7
for b in eng_p1r/bin/jsepf_gk_k192 eng_p1r/bin/jsepf_gk eng_p1r/bin/jsep3; do [ -x $N/$b ] || echo "install_k5e: WARNING: $b is not built (main pack: bash build.sh)"; done
echo "install_k5e: done.  Next:"
echo "  cd $P && bash smoke_k5e.sh            # about 20 min; must end with SMOKE-K5E: PASS"
echo "  DRY=1 bash launch_upper_k5e.sh        # the plan: in-point, warm set, what stops and starts"
echo "  bash launch_upper_k5e.sh              # stops k86MS1 (results kept), starts k86MS2 on K3gB5e / K3l5e"
echo "  bash status_k5e.sh; bash recheck_k5e.sh <point>; bash stop_k5e.sh"
