"""hshim_check.py <engine dir> <hshim_ref.json> -- the highspy shim (hshim.py in the engine dir) against reference LPs solved with the
real highspy 1.15.1 in the container (tools/hshim_ref.json): 40 random LPs with <= / >= / ranged / equality rows and free / capped /
boxed columns, each solved twice on ONE Highs object (the second time after cost changes, a bound change and an added row, as the
engine edits its model between runs).  Compares status, objective (rel 1e-7) and, where the reference vertex is nondegenerate (unique
primal and dual), x, row duals (HiGHS sign convention) and column duals (abs 1e-6).  Runs both shim methods (ipm, simplex).
Prints one summary line per method and 'HSHIM CHECK: PASS' / 'HSHIM CHECK: FAIL'; exit status 0 / 1."""
import sys, os, json
import numpy as np
eng = os.path.abspath(sys.argv[1]); sys.path.insert(0, eng)
import hshim
R = json.load(open(sys.argv[2]))
INF = hshim.kHighsInf


def b(v, s): return s * INF if v is None else v


def cmp(h, ref, tag, st):
    stn = h.modelStatusToString(h.getModelStatus())
    if stn != ref['status']: st['fail'].append('%s status %s, reference %s' % (tag, stn, ref['status'])); return
    if stn != 'Optimal': return
    o = h.getInfo().objective_function_value; d = abs(o - ref['obj']) / (1 + abs(ref['obj'])); st['maxobj'] = max(st['maxobj'], d)
    if d > 1e-7: st['fail'].append('%s objective %.12g, reference %.12g' % (tag, o, ref['obj']))
    if not ref.get('nondeg'): return
    S = h.getSolution(); st['nondeg'] += 1
    for key, got in (('x', S.col_value), ('row_dual', S.row_dual), ('col_dual', S.col_dual)):
        e = float(np.max(np.abs(np.array(got) - np.array(ref[key])))) if len(ref[key]) else 0.0
        st['max_' + key] = max(st['max_' + key], e)
        if e > 1e-6: st['fail'].append('%s %s differs by %.3g' % (tag, key, e))
    y = np.array(S.row_dual); yr = np.array(ref['row_dual'])
    st['signs'] += int(np.sum(np.abs(yr) > 1e-9)); st['sign_bad'] += int(np.sum(np.sign(np.round(y, 9)) != np.sign(np.round(yr, 9))))


def main():
    bad = 0
    for solver in ('ipm', 'simplex'):
        st = dict(n=0, nondeg=0, maxobj=0.0, max_x=0.0, max_row_dual=0.0, max_col_dual=0.0, signs=0, sign_bad=0, fail=[])
        for k, c in enumerate(R['cases']):
            h = hshim.Highs(); h.setOptionValue('output_flag', False); h.setOptionValue('solver', solver)
            for lo, hi, cc in c['cols']: h.addVar(b(lo, -1), b(hi, 1))
            for j, (lo, hi, cc) in enumerate(c['cols']): h.changeColCost(j, cc)
            for lo, hi, idx, val in c['rows']: h.addRow(b(lo, -1), b(hi, 1), len(idx), np.array(idx, dtype=np.int32), np.array(val, dtype=float))
            h.run(); st['n'] += 1; cmp(h, c['ref'], 'lp%d/%s/first' % (k, solver), st)
            # the second solve on the same object: changed costs and bounds, one added row
            for j, ((lo, hi, c1), (lo2, hi2, c2)) in enumerate(zip(c['cols'], c['cols2'])):
                if c2 != c1: h.changeColCost(j, c2)
                if (lo2, hi2) != (lo, hi): h.changeColBounds(j, b(lo2, -1), b(hi2, 1))
            for lo, hi, idx, val in c['rows2'][len(c['rows']):]:
                h.addRow(b(lo, -1), b(hi, 1), len(idx), np.array(idx, dtype=np.int32), np.array(val, dtype=float))
            h.run(); st['n'] += 1; cmp(h, c['ref2'], 'lp%d/%s/second' % (k, solver), st)
        print('[%s] %d solves vs highspy %s: max rel obj diff %.2e; %d nondegenerate: max |dx| %.2e, max |d row_dual| %.2e, max |d col_dual| %.2e, '
              'row-dual signs %d compared, %d wrong; %d failures' % (solver, st['n'], R.get('highspy', '?'), st['maxobj'], st['nondeg'], st['max_x'],
              st['max_row_dual'], st['max_col_dual'], st['signs'], st['sign_bad'], len(st['fail'])))
        for f in st['fail'][:10]: print('   FAIL', f)
        bad += len(st['fail'])
    print('HSHIM CHECK: %s' % ('PASS' if not bad else 'FAIL'))
    sys.exit(1 if bad else 0)


main()
