# maclane: see relocate.sh.  usage: python3 relocate.py <new root>
import os, sys, hashlib
NEW = os.path.abspath(sys.argv[1]).rstrip('/')
HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if os.path.realpath(HERE) != os.path.realpath(NEW): print('relocate: run me from the pack folder (%s != %s)' % (HERE, NEW)); sys.exit(2)
OLD = open(os.path.join(HERE, '.root')).read().strip()
PACKED = '/tmp/' + 'maclane-k86'   # the root as packed, split so that relocation never rewrites this line
if OLD == PACKED and os.path.exists(os.path.join(HERE, 'MANIFEST.md5')):   # first run: the files are as packed
    bad = 0; n = 0
    for l in open(os.path.join(HERE, 'MANIFEST.md5')):
        h, f = l.rstrip('\n').split('  ', 1); n += 1
        p = os.path.join(HERE, f)
        if not os.path.exists(p) or hashlib.md5(open(p, 'rb').read()).hexdigest() != h: bad += 1; print('BAD %s' % f)
    print('manifest: %d files, %d bad' % (n, bad))
    if bad: print('relocate: the pack is damaged; unpack it again'); sys.exit(3)
if OLD == NEW: print('relocate: already at %s, nothing to do' % NEW); sys.exit(0)
o, nw = OLD.encode(), NEW.encode(); nf = 0; nr = 0
for d, ds, fs in os.walk(HERE):
    ds[:] = [x for x in ds if x not in ('bin', '__pycache__')]
    for f in fs:
        p = os.path.join(d, f)
        if os.path.islink(p) or f in ('MANIFEST.md5', 'ORIGMD5.tsv'): continue
        b = open(p, 'rb').read()
        if o not in b or b'\x00' in b[:65536]: continue
        st = os.stat(p); nr += b.count(o); b = b.replace(o, nw)
        with open(p + '.reloc', 'wb') as fh: fh.write(b)
        os.chmod(p + '.reloc', st.st_mode); os.replace(p + '.reloc', p); nf += 1
open(os.path.join(HERE, '.root'), 'w').write(NEW + '\n')
print('relocate: %s -> %s: %d occurrences in %d files rewritten' % (OLD, NEW, nr, nf))
