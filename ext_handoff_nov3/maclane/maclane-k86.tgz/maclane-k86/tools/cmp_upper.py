"""cmp_upper.py <reference upperR2 log> <new upperR2 log> -- compare two upperR2 logs of the same point / family line by line after
normalising what legitimately differs between machines: absolute paths (-> base names), timings ('63.1s', '%.0fs'), and the md5 of
files whose paths were rewritten.  Everything else (pattern counts, key counts, l3q / sender / conservation values, per-d leaf counters
and violated counts, the UPPER-R2 verdict and t) must match.  A line whose words all match except decimal numbers (with a '.' or an
exponent) that agree to 2e-5 relative (one unit in the 6th digit) counts as 'close' (printed, not a failure): last-digit diagnostics may differ between the
container's GCC build and this build.  Integers and the verdict line must match exactly.
Exit 0 = identical or close only, 1 = real differences."""
import sys, re, difflib


def norm(l):
    l = re.sub(r"(?<![\w.-])/[^\s,:;'\"()\[\]{}]+/([^\s/,:;'\"()\[\]{}]+)", r'\1', l)     # absolute paths -> base names
    l = re.sub(r'\b\d+(\.\d+)?s\b', 'Ns', l)                                               # timings
    l = re.sub(r'\(md5 [0-9a-f]{8}\)', '(md5 -)', l)
    return l.rstrip()


def load(fn):
    out = []
    for l in open(fn, errors='replace'):
        if l.startswith('hshim: ') or not l.strip(): continue
        out.append(norm(l))
    return out


FL = re.compile(r'[-+]?(?:\d+\.\d*|\.\d+|\d+(?=[eE]))(?:[eE][-+]?\d+)?')


def close(x, y):
    if x.startswith('UPPER-R2') or y.startswith('UPPER-R2'): return False
    sx, sy = FL.split(x), FL.split(y)
    if sx != sy: return False
    for u, v in zip(FL.findall(x), FL.findall(y)):
        u, v = float(u), float(v)
        if abs(u - v) > 2e-5 * max(abs(u), abs(v)) + 1e-12: return False
    return True


a, b = load(sys.argv[1]), load(sys.argv[2])
va = [l for l in a if l.startswith('UPPER-R2')]; vb = [l for l in b if l.startswith('UPPER-R2')]
print('reference verdict: %s' % (va[-1] if va else 'none')); print('this machine:      %s' % (vb[-1] if vb else 'none'))
real, near = [], []
for op, i1, i2, j1, j2 in difflib.SequenceMatcher(None, a, b, autojunk=False).get_opcodes():
    if op == 'equal': continue
    if op == 'replace' and i2 - i1 == j2 - j1 and all(close(a[i], b[j]) for i, j in zip(range(i1, i2), range(j1, j2))):
        near += list(zip(a[i1:i2], b[j1:j2])); continue
    real += ['-' + l for l in a[i1:i2]] + ['+' + l for l in b[j1:j2]]
for x, y in near: print('  close (numbers within 2e-5 relative):\n    -%s\n    +%s' % (x[:400], y[:400]))
for l in real: print('  ' + l[:400])
print('%d of %d reference lines differ after normalising (%d only within 2e-5 relative); verdict %s'
      % (sum(1 for l in real if l.startswith('-')) + len(near), len(a), len(near), 'SAME' if va and vb and va[-1] == vb[-1] else 'DIFFERENT'))
sys.exit(0 if not real and va and vb and va[-1] == vb[-1] else 1)
