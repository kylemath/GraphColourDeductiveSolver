#!/bin/bash
# maclane stop: bash stop.sh upper|lower|all   (default all).  Stops the lane's watchers first (no new checks start), then the repair
# ladder / tighten / upperR2 checks, then the K run.  Only processes of this pack are matched (tags k86MS1 / k86ML1, this pack's paths).
# Results already written stay: cand/, outbox/, runK_<tag>/K.log, eng*/rows_<tag>.txt (warm rows for a restart).
R=/tmp/maclane-k86
B=$R/fs/home/claude/GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp; N=$B/s86_f2b7
SD=$R/fs/tmp/claude-0/-home-claude/501dd3ae-0fa3-53a8-b24b-82020727c8dd/scratchpad/sD
W=${1:-all}; TU=${TAG_UPPER:-k86MS1}; TL=${TAG_LOWER:-k86ML1}
kill_tree() {   # children first (BSD / GNU pgrep -P)
  local c
  for c in $(pgrep -P $1 2>/dev/null); do kill_tree $c; done
  kill $1 2>/dev/null
}
stop_pat() {
  local p n=0
  for p in $(pgrep -f "$1" 2>/dev/null); do [ "$p" = "$$" ] && continue; kill_tree $p; n=$((n + 1)); done
  [ $n -gt 0 ] && echo "  stopped $n: $1"
  return 0
}
if [ "$W" = upper ] || [ "$W" = all ]; then
  echo "upper lane $TU:"
  stop_pat "watch86.sh $TU"; stop_pat "tightwatch.sh $TU"; stop_pat "outbox86.sh $TU"; stop_pat "repladder.py $TU"
  stop_pat "$N/tighten.sh"; stop_pat "$N/U86.sh"; stop_pat "work=$SD/wr86u_"
  stop_pat "runK86.sh [0-9]+ [0-9]+ $TU "; stop_pat "tag=$TU "
fi
if [ "$W" = lower ] || [ "$W" = all ]; then
  echo "lower lane $TL:"
  stop_pat "outbox86L.sh $TL"; stop_pat "runK86p.sh [0-9]+ [0-9]+ $TL "; stop_pat "tag=$TL "
fi
sleep 2
left=$(pgrep -f "$R/fs/" 2>/dev/null | wc -l | tr -d ' ')
echo "processes still naming this pack's paths: $left"
[ "$left" != 0 ] && pgrep -fl "$R/fs/" | cut -c1-200
exit 0
