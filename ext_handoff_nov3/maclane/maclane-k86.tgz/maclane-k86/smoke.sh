#!/bin/bash
# maclane smoke test (run after relocate.sh and build.sh; about 5-10 minutes).  Prints OK / FAIL per step and a summary.
#  1 the pack is relocated to this folder           5 the separator binaries are built
#  2 python3 / numpy / scipy versions; highspy?      6 upperR2 of the upper lane's start point cand/sol_k86GS4_in01.json on K3l (engine eng):
#  3 the highspy shim against 40 reference LPs          compared line by line with the container's log (ref/); must say FEASIBLE at
#    solved with the real highspy in the container      t = 0.030980300342.  It also writes logs/upper_F_k86GS4_in01.log, which
#  4 every engine module parses under this python       launch_upper.sh requires.
#                                                     7 the same point with the lower lane's engine eng_p1r / K3g / 240 keys / p1r
#                                                        (exercises bin/jsepf_gk_k192): must run to the end with a verdict, any verdict
#                                                        (compared line by line when ref/smoke_lower_in01_K3g.log exists).  SMOKE_LOWER=0 skips.
# env: SMOKE_THREADS (1: separator threads of the two upperR2 runs; the references were made with 1)
R=/tmp/maclane-k86
B=$R/fs/home/claude/GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp; N=$B/s86_f2b7
PATH=$R/macshim:$PATH; export PATH
TH=${SMOKE_THREADS:-1}; NF=0; LOG=$R/smoke.log
say() { echo "$*" | tee -a $LOG; }
ok() { say "   OK   $*"; }
bad() { say "   FAIL $*"; NF=$((NF + 1)); }
: > $LOG
say "maclane smoke $(date -u +%Y-%m-%dT%H:%M:%SZ) on $(uname -sm), $(sysctl -n hw.ncpu 2>/dev/null || getconf _NPROCESSORS_ONLN) cores"

say "1. relocation"
HERE=$(cd "$(dirname "$0")" && pwd -P)
if [ -d "$N" ] && [ "$(cd $R && pwd -P)" = "$HERE" ]; then ok "pack root $R"; else bad "the scripts point at $R but smoke.sh is in $HERE: run  bash $HERE/relocate.sh  first"; echo "smoke: stopping"; exit 1; fi

say "2. python"
V=$(python3 -c "import sys, numpy, scipy; print('python %s numpy %s scipy %s' % (sys.version.split()[0], numpy.__version__, scipy.__version__))" 2>&1)
if python3 -c "import sys, scipy; sys.exit(0 if sys.version_info >= (3, 9) and tuple(int(x) for x in scipy.__version__.split('.')[:2]) >= (1, 9) else 1)" 2>/dev/null; then ok "$V"; else bad "$V (need python >= 3.9, numpy, scipy >= 1.9)"; fi
if python3 -c "import highspy" 2>/dev/null; then say "   info highspy is installed: the engine uses it (HSHIM_FORCE=1 forces the shim)"; else say "   info no highspy: the engine uses the numpy / scipy shim hshim.py (expected)"; fi

say "3. highspy shim vs reference LPs"
if HSHIM_QUIET=1 python3 $R/tools/hshim_check.py $N/eng $R/tools/hshim_ref.json > $R/smoke_hshim.log 2>&1; then ok "$(grep -c '^\[' $R/smoke_hshim.log) methods: $(grep '^\[ipm\]' $R/smoke_hshim.log | cut -c1-150)"; else bad "see $R/smoke_hshim.log"; tail -5 $R/smoke_hshim.log | tee -a $LOG; fi

say "4. engine modules parse"
if python3 -c "
import ast, sys
for f in sys.argv[1:]: ast.parse(open(f).read(), f)
print(len(sys.argv) - 1)" $N/eng/*.py $N/eng_p1r/*.py > $R/smoke_parse.log 2>&1; then ok "$(cat $R/smoke_parse.log) files"; else bad "$(tail -3 $R/smoke_parse.log)"; fi

say "5. binaries"
MISS=""
for b in eng/bin/jsepf_gk eng/bin/jsep3 eng_p1r/bin/jsepf_gk_k192 eng_p1r/bin/jsepf_gk eng_p1r/bin/jsep3; do [ -x $N/$b ] || MISS="$MISS $b"; done
if [ -z "$MISS" ]; then ok "jsepf_gk jsep3 (eng), jsepf_gk_k192 jsepf_gk jsep3 (eng_p1r)"; else bad "missing:$MISS (run build.sh)"; fi

say "6. upper lane: upperR2 of sol_k86GS4_in01 on K3l, $TH thread(s)"
T0=$(date +%s)
bash $N/smokeU.sh upper $N/cand/sol_k86GS4_in01.json $N/logs/upper_F_k86GS4_in01.log $TH >> $LOG 2>&1
if python3 $R/tools/cmp_upper.py $R/ref/upper_F_k86GS4_in01_K3l.log $N/logs/upper_F_k86GS4_in01.log > $R/smoke_upper_cmp.log 2>&1; then
  ok "matches the container log ($(( $(date +%s) - T0 ))s; $(tail -1 $R/smoke_upper_cmp.log | cut -d';' -f1)): $(grep '^UPPER-R2' $N/logs/upper_F_k86GS4_in01.log)"
else
  bad "differs from the container log ($(( $(date +%s) - T0 ))s; $R/smoke_upper_cmp.log):"; head -20 $R/smoke_upper_cmp.log | tee -a $LOG
fi
grep -q "^UPPER-R2: FEASIBLE at t = 0.030980300342" $N/logs/upper_F_k86GS4_in01.log || bad "the start point is not FEASIBLE here: launch_upper.sh will refuse to start"

if [ "${SMOKE_LOWER:-1}" != 0 ]; then
  say "7. lower lane engine: upperR2 of sol_k86GS4_in01 on K3g with eng_p1r, 240 keys, p1r, $TH thread(s)"
  T0=$(date +%s)
  bash $N/smokeU.sh lower $N/cand/sol_k86GS4_in01.json $N/logs/smoke_lower_in01_K3g.log $TH >> $LOG 2>&1; RC=$?
  V=$(grep '^UPPER-R2' $N/logs/smoke_lower_in01_K3g.log | tail -1)
  if [ -f $R/ref/smoke_lower_in01_K3g.log ]; then
    if python3 $R/tools/cmp_upper.py $R/ref/smoke_lower_in01_K3g.log $N/logs/smoke_lower_in01_K3g.log > $R/smoke_lower_cmp.log 2>&1; then
      ok "matches the container log ($(( $(date +%s) - T0 ))s; $(tail -1 $R/smoke_lower_cmp.log | cut -d';' -f1)): $V"
    else
      bad "differs from the container log ($(( $(date +%s) - T0 ))s; $R/smoke_lower_cmp.log):"; head -20 $R/smoke_lower_cmp.log | tee -a $LOG
    fi
  else
    # no container reference for this family / engine pair (the container had no memory to spare for one): the run must finish cleanly
    # with a verdict; the verdict itself (FEASIBLE or not on K3g) is information, not a pass condition
    if [ $RC = 0 ] && [ -n "$V" ] && ! grep -q Traceback $N/logs/smoke_lower_in01_K3g.log; then
      ok "ran to the end ($(( $(date +%s) - T0 ))s; no container reference to compare with): $V"
    else
      bad "exit $RC, verdict '${V:-none}' ($(( $(date +%s) - T0 ))s): see $N/logs/smoke_lower_in01_K3g.log"; tail -5 $N/logs/smoke_lower_in01_K3g.log | tee -a $LOG
    fi
  fi
fi
say ""
if [ $NF = 0 ]; then say "SMOKE: PASS (log $LOG)"; else say "SMOKE: FAIL ($NF failed steps; log $LOG)"; fi
[ $NF = 0 ]
