#!/bin/bash
# maclane collect: one tarball of everything worth sending back (outbox, both K.logs, run.log, smoke and build logs, the lane
# rows files), written next to the pack folder.  usage: bash collect.sh     -> ../maclane-k86-out-<UTC time>.tgz and its md5
R=/tmp/maclane-k86
N=$R/fs/home/claude/GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp/s86_f2b7
PATH=$R/macshim:$PATH; export PATH
TU=${TAG_UPPER:-k86MS1}; TL=${TAG_LOWER:-k86ML1}
S=$(date -u +%Y%m%dT%H%MZ); T=$(dirname $R)/maclane-k86-out-$S.tgz; L=$R/collect_list.txt
cd $R
{ echo outbox
  for f in smoke.log smoke_hshim.log smoke_upper_cmp.log smoke_lower_cmp.log; do [ -f $f ] && echo $f; done
  for f in $N/run.log $N/runK_$TU/K.log $N/runK_$TL/K.log $N/eng/rows_$TU.txt $N/eng_p1r/rows_$TL.txt $N/eng/sol_${TU}_in.json \
           $N/logs/repladder_$TU.out $N/logs/tightwatch_$TU.out $N/logs/runK_$TU.out $N/logs/runK_$TL.out \
           $N/logs/upper_F_k86GS4_in01.log $N/logs/smoke_lower_in01_K3g.log $N/eng/bin/*.build.log $N/eng_p1r/bin/*.build.log; do [ -f $f ] && echo ${f#$R/}; done
} > $L
tar -czf $T -T $L && echo "wrote $T ($(du -k $T | cut -f1) KB, md5 $(md5sum $T | cut -c1-32)): $(wc -l < $L | tr -d ' ') entries"
