#!/bin/bash
# maclane: start the UPPER lane k86MS1 (see README.md).  Knobs (env): UPPER_THREADS=2  REPL_PAR=2  TIGHTWATCH=1  MAXIT=200  HSHIM_SOLVER=ipm
R=/tmp/maclane-k86
exec bash $R/fs/home/claude/GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp/s86_f2b7/launch_k86MS1.sh "$@"
