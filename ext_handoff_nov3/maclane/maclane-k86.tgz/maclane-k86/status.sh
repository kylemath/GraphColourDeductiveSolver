#!/bin/bash
# maclane status: what runs, the last iterations of each lane, the outbox, the end of run.log.   usage: bash status.sh [lines, default 6]
R=/tmp/maclane-k86
B=$R/fs/home/claude/GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp; N=$B/s86_f2b7
SD=$R/fs/tmp/claude-0/-home-claude/501dd3ae-0fa3-53a8-b24b-82020727c8dd/scratchpad/sD
. $N/maclib.sh
K=${1:-6}; TU=${TAG_UPPER:-k86MS1}; TL=${TAG_LOWER:-k86ML1}
up() { if pgrep -f "$1" > /dev/null 2>&1; then echo "running"; else echo "-"; fi; }
echo "== maclane $(date -u +%Y-%m-%dT%H:%M:%SZ)  load:$(uptime | sed 's/.*load average[s]*://')  available memory $(memavail_mb) MB"
echo
echo "== UPPER $TU   K run: $(up "tag=$TU ")  repladder: $(up "repladder.py $TU")  watch86: $(up "watch86.sh $TU")  tightwatch: $(up "tightwatch.sh $TU")  outbox: $(up "outbox86.sh $TU")  upperR2 checks now: $(pgrep -f "work=$SD/wr86u_" 2>/dev/null | wc -l | tr -d ' ')"
if [ -f $N/runK_$TU/K.log ]; then
  grep -E '^iter |in-point: t_in|^hshim: run|Traceback|Error' $N/runK_$TU/K.log | tail -n $K | cut -c1-220
else echo "  (no K.log yet)"; fi
echo "-- outbox/upper/POINTS.txt (FEASIBLE points: name  t  md5  family  log  filed-at), last $K of $( [ -f $R/outbox/upper/POINTS.txt ] && wc -l < $R/outbox/upper/POINTS.txt | tr -d ' ' || echo 0):"
[ -f $R/outbox/upper/POINTS.txt ] && tail -n $K $R/outbox/upper/POINTS.txt
echo
echo "== LOWER $TL   K run: $(up "tag=$TL ")  outbox: $(up "outbox86L.sh $TL")"
if [ -f $N/runK_$TL/K.log ]; then
  grep -E 'lext it [0-9]+: phase 1|^hshim: run|^iter |Traceback|Error' $N/runK_$TL/K.log | tail -n $K | cut -c1-220
else echo "  (no K.log yet)"; fi
echo "-- outbox/lower/P1.txt (phase-1 certs: NN  md5  t1  it  filed-at), last $K:"
[ -f $R/outbox/lower/P1.txt ] && tail -n $K $R/outbox/lower/P1.txt
echo
echo "== run.log (last $((K * 2)))"
[ -f $N/run.log ] && tail -n $((K * 2)) $N/run.log | cut -c1-260
