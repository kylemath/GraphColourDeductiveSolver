#!/bin/bash
# maclane relocate: point every script of the pack at this folder.  Every path in the pack's text files starts with the pack root, which
# is the literal /tmp/maclane-k86 as packed (stored in .root).  This rewrites that root to the folder relocate.sh sits in (or to $1) in
# every text file, and records the new root in .root.  Run it once after unpacking, and again after moving the folder.  The first run
# also checks every file against MANIFEST.md5 (packed state) and reports BAD files before rewriting anything.
NEW=${1:-$(cd "$(dirname "$0")" && pwd -P)}
case "$NEW" in *" "*) echo "relocate: the folder path must not contain spaces: $NEW" >&2; exit 2;; esac
exec python3 "$(dirname "$0")/tools/relocate.py" "$NEW"
