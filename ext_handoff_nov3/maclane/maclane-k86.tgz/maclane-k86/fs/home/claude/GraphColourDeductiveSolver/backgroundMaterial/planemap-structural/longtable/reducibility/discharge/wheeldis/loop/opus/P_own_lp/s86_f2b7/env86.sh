# s86_f2b7: s85 environment with the engine copy s86_f2b7/eng (f2bglue flag f2b7 + jsepf_gk JSEPF_F2B7); source after STACK/ARGS/FAM/KS
. /tmp/maclane-k86/fs/home/claude/GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp/s85_edge56/env85.sh
N86=$B/s86_f2b7; E85=$N86/eng; E86=$E85
PATH=/tmp/maclane-k86/macshim:$PATH; export PATH   # maclane: md5sum / timeout stand-ins for macOS (harmless on Linux)
