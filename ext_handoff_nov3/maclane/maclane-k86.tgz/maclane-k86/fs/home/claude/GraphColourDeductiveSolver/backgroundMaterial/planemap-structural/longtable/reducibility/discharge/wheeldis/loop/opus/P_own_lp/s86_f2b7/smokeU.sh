# maclane smoke check: one exhaustive upperR2 (gkwin gkleaf) of a point with a lane's engine, family, keys and flags.
# usage: bash smokeU.sh upper|lower <sol.json> <log> [threads, default 1]
#   upper: engine eng,     args K3l (args_A97_F_W13K3l.txt), keys s85_edge56/keys/cg_keys_r13w16.txt, flags c6le f2b7 f2b=<rules c67fa1d1> rpatN=<rpatN3>
#          (= the k86MS1 lane's family; the same command as chkfam.sh / U86.sh, which made logs/upper_F_k86GS4_in01_K3l.log in the container)
#   lower: engine eng_p1r, args K3g (args_A97_F_W13K3g.txt), keys p1r/cg_keys_r13w16_16fik.txt, flags + rpatN offc_K3g_2f4f0f02.txt + p1r
#          (= the k86ML1 lane's family; exercises eng_p1r/bin/jsepf_gk_k192 at d = 7)
# env: SMOKE_ENG (engine dir override), SMOKE_WORK (work dir, default $SD/wr86s_<pid>)
N=/tmp/maclane-k86/fs/home/claude/GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp/s86_f2b7; NN=$N; Z=$(dirname $N)/s85_edge56
LANE=$1; SOL=$2; LOG=$3; TH=${4:-1}
RU=$N/rules/A5final/rules_c67fa1d1_plus_A5_twins.json; RP=$N/rpat/rpatN3_rotation_justified.txt
if [ "$LANE" = upper ]; then
  E=$N/eng; export STACK=s77 ARGS=$N/args_A97_F_W13K3l.txt KEYS=$Z/keys/cg_keys_r13w16.txt; FX="c6le f2b7 f2b=$RU rpatN=$RP"
elif [ "$LANE" = lower ]; then
  E=$N/eng_p1r; export STACK=s77 ARGS=$N/args_A97_F_W13K3g.txt KEYS=$N/p1r/cg_keys_r13w16_16fik.txt; FX="c6le f2b7 f2b=$RU rpatN=$RP,$N/offc/offc_K3g_2f4f0f02.txt p1r"
else
  echo "usage: bash smokeU.sh upper|lower <sol.json> <log> [threads]" >&2; exit 2
fi
export FAM=full KS=0; unset EGK; . $NN/env86.sh; N=$NN
E=${SMOKE_ENG:-$E}; WK=${SMOKE_WORK:-$SD/wr86s_$$}; mkdir -p $WK $(dirname $LOG); cd $E
nice -n 12 python3 pcheck.py upperR2 $F $X nomax sol=$SOL $A threads=$TH work=$WK gkeys=$KEYS gkwin gkleaf $FX vK=1000000 vfile=${LOG%.log}_viol.txt > $LOG 2>&1
RC=$?; rm -rf $WK
echo "smokeU $LANE: exit $RC, $(grep -c Traceback $LOG) tracebacks: $(grep '^UPPER-R2' $LOG | tail -1)"
exit $RC
