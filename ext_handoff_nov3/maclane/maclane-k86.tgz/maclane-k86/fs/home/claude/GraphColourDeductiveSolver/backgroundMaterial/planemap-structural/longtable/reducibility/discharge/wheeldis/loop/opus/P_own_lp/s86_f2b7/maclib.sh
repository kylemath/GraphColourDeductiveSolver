# maclane (Mac Studio lane pack): shared helpers, bash 3.2 safe.  Source me.
#   memavail_mb   MB of available memory: Linux MemAvailable, macOS vm_stat (free + inactive + speculative + purgeable pages)
#   memgate MIN   wait until memavail_mb >= MIN MB; a no-op when MIN is 0 / empty (the default on the 128 GB Studio)
memavail_mb() {
  local v=""
  if [ -r /proc/meminfo ]; then v=$(awk '/MemAvailable/{print int($2/1024); exit}' /proc/meminfo)
  else v=$(vm_stat 2>/dev/null | awk 'NR==1{for(i=1;i<=NF;i++) if($i+0>0) ps=$i+0} /^Pages free/{f=$3+0} /^Pages inactive/{n=$3+0} /^Pages speculative/{s=$3+0} /^Pages purgeable/{p=$3+0} END{if(!ps)ps=4096; print int((f+n+s+p)*ps/1048576)}'); fi
  [ -n "$v" ] || v=999999
  echo $v
}
memgate() {
  local m=${1:-0}
  [ "$m" -gt 0 ] 2>/dev/null || return 0
  while [ "$(memavail_mb)" -lt "$m" ]; do sleep 20; done
}
