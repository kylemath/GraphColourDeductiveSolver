# maclane: file every upperR2-FEASIBLE upper point of the lane into the outbox (replaces file86.sh, which wrote to the swarm mount).
# usage: nohup bash outbox86.sh <tag> &      (started by launch_k86MS1.sh; runs until stop.sh)
# A point is cand/sol_X.json whose own check log says "UPPER-R2: FEASIBLE": logs/upper_sol_X.log (watch86 in-points) or logs/upper_F_X.log
# (repair ladder sol_repS1W_NN, tighten sol_X_tight, the smoke check of the start point).  Probe points (t lowered on purpose) are skipped.
# Each filed point: <outbox>/<name>.json + its upperR2 log, one line in POINTS.txt: name  t  md5  family  log  filed-at; MD5SUMS refreshed.
N=/tmp/maclane-k86/fs/home/claude/GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp/s86_f2b7
PATH=/tmp/maclane-k86/macshim:$PATH; export PATH
TAG=${1:-k86MS1}; O=${OUTBOX_UPPER:-/tmp/maclane-k86/outbox/upper}; mkdir -p $O; FAMN=$(basename ${ARGS:-$N/args_A97_F_W13K3l.txt} .txt); FAMN=${FAMN#args_A97_F_W13}
while true; do
  for f in $N/cand/sol_*.json; do
    [ -e "$f" ] || continue
    b=$(basename $f .json)
    case $b in *_probe) continue;; esac
    [ -e $O/$b.json ] && continue
    L=""
    for c in $N/logs/upper_$b.log $N/logs/upper_F_${b#sol_}.log; do if [ -e $c ]; then L=$c; break; fi; done
    [ -n "$L" ] || continue
    grep -q "^UPPER-R2: FEASIBLE" $L || continue
    t=$(grep "^UPPER-R2: FEASIBLE at t = " $L | tail -1 | awk '{print $NF}'); m=$(md5sum $f | awk '{print $1}')
    cp $f $L $O/
    echo "$b    $t    $m    $FAMN    $(basename $L)    $(date -u +%Y-%m-%dT%H:%M:%SZ)" >> $O/POINTS.txt
    (cd $O && md5sum $(ls | grep -v '^MD5SUMS$') > MD5SUMS)
    echo "$(date -u +%H:%M:%SZ) [maclane-outbox-$TAG] filed $b (t = $t, md5 $m, $FAMN)" >> $N/run.log
  done
  sleep ${OUTBOX_POLL:-120}
done
