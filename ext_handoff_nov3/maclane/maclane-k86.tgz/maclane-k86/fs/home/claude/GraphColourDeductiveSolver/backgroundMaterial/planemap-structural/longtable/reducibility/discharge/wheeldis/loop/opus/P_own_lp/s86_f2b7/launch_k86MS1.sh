# maclane UPPER lane k86MS1: the k86GS4 in-out upper solve (launch_k86GS4.sh flags) on family K3l (args_A97_F_W13K3l.txt, md5 2727d445 in
# the container; its paths are rewritten in this pack) from cand/sol_k86GS4_in01.json (UPPER-R2 FEASIBLE on K3l at 0.030980300342).
# Also starts: watch86 (upperR2 of every new in-point on K3l), outbox86 (files FEASIBLE points), tightwatch (tighten.sh on each new FEASIBLE
# ladder / in-point), repladder (OP-23 repair ladder, family K3l).  Knobs (env): UPPER_THREADS (2: separator threads of the K run),
# REPL_PAR (2: concurrent ladder checks, 1 thread each), TIGHTWATCH (1; 0 = no tightening), REPL_MINMEM / TIGHT_MINMEM (0: memory gates off), MAXIT (200), INPOINT
# (sol_k86GS4_in01), TAG (k86MS1), HSHIM_SOLVER (ipm: LP method when highspy is missing).
# Requires: build.sh done, smoke.sh passed (it writes logs/upper_F_k86GS4_in01.log = FEASIBLE on this machine).
N=/tmp/maclane-k86/fs/home/claude/GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp/s86_f2b7; B=$(dirname $N); Z=$B/s85_edge56
PATH=/tmp/maclane-k86/macshim:$PATH; export PATH
TAG=${TAG:-k86MS1}; TH=${UPPER_THREADS:-2}; MI=${MAXIT:-200}; IP=${INPOINT:-sol_k86GS4_in01}
for b in jsepf_gk jsep3; do [ -x $N/eng/bin/$b ] || { echo "launch_k86MS1: eng/bin/$b missing: run build.sh first" >&2; exit 2; }; done
export STACK=s77 ARGS=$N/args_A97_F_W13K3l.txt XF="c6le f2b7 f2b=$N/rules/A5final/rules_c67fa1d1_plus_A5_twins.json rpatN=$N/rpat/rpatN3_rotation_justified.txt" KEYS=$Z/keys/cg_keys_r13w16.txt FEAS=$N/cand/$IP.json
P1=${IP#sol_}; grep -q "^UPPER-R2: FEASIBLE" $N/logs/upper_F_$P1.log 2>/dev/null || { echo "launch_k86MS1: in-point $IP has no FEASIBLE upperR2 log on this machine (logs/upper_F_$P1.log): run smoke.sh first" >&2; exit 2; }
pgrep -f "tag=$TAG " > /dev/null && { echo "launch_k86MS1: a run with tag=$TAG is already going" >&2; exit 3; }
export WARM=$(cat $N/maclane_warm_upper.txt)
echo "$(date -u +%H:%M:%SZ) [maclane] launch $TAG: ARGS $(basename $ARGS) ($(md5sum < $ARGS | cut -c1-8) in this pack), keys $(basename $KEYS), in-point $IP ($(md5sum < $FEAS | cut -c1-8)), threads $TH, REPL_PAR ${REPL_PAR:-2}, $(echo $WARM | tr ',' '\n' | grep -c .) warm files" >> $N/run.log
mkdir -p $N/logs $N/cand
nohup bash $N/runK86.sh $MI $TH $TAG inout=0.4,0.8,0.1 inoutk=4 inoutmove inoutprobe=0.25 inoutnprobe=3 q7pen=1e-3 feascols feasall consk=20 consfrac=0.25 > $N/logs/runK_$TAG.out 2>&1 &
sleep 5
cd $N && nohup bash $N/watch86.sh $TAG > $N/logs/watch86_$TAG.out 2>&1 &
cd $N && nohup bash $N/outbox86.sh $TAG > $N/logs/outbox86_$TAG.out 2>&1 &
if [ "${TIGHTWATCH:-1}" != 0 ]; then cd $N && nohup bash $N/tightwatch.sh $TAG >> $N/logs/tightwatch_$TAG.out 2>&1 & fi
cd $N && REPL_FAM=MW REPL_ARGS=$ARGS REPL_KEYS=$KEYS REPL_PAR=${REPL_PAR:-2} REPL_MINMEM=${REPL_MINMEM:-0} nohup python3 $N/repladder.py $TAG $FEAS 60 >> $N/logs/repladder_$TAG.out 2>&1 &
sleep 2; echo "launched $TAG: K run log $N/runK_$TAG/K.log, outbox /tmp/maclane-k86/outbox/upper/POINTS.txt, status: bash /tmp/maclane-k86/status.sh"
