# maclane: the floor computation of tighten.sh, moved out of a here-document inside $( ) (bash 3.2 mis-parses those).
# usage: python3 tighten_floor.py <sol> <probe upperR2 log> <probe vfile>   -> "floor t_old {sources}"
import sys, re, json
t0 = json.load(open(sys.argv[1]))['t']; L = open(sys.argv[2]).read()
tp = float(re.search(r'at t = ([0-9.e-]+)', L).group(1))
sf = float(re.search(r'senders need t >= ([0-9.e+-]+)', L).group(1))
m = re.search(r'links with in - out > t \+ 1e-9: (\d+) \(worst excess ([0-9.e+-]+)\)', L); ce = float(m.group(2)) if m and int(m.group(1)) else None
rx = [float(l.split()[2]) for l in open(sys.argv[3]) if l.strip()]
fl = max([sf] + ([tp + max(rx)] if rx else []) + ([tp + ce] if ce is not None else []))
src = {'senders': sf, 'receivers': tp + max(rx) if rx else None, 'cons': tp + ce if ce is not None else None}
print('%.12f %.12f %s' % (fl, t0, json.dumps(src).replace(' ', '')))
