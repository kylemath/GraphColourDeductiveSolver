# maclane LOWER control lane k86ML1 = the container's k86GL6 lext run (launch_k86GL6.sh) WITHOUT kill B: args K3g (args_A97_F_W13K3g.txt,
# md5 bef43766 in the container) instead of K3gB; keys p1r/cg_keys_r13w16_16fik.txt (240 keys, 3d996dbb); XF with p1r and the offc rpatN
# file; engine eng_p1r (runner p1r/runK86p.sh; d = 7 leaf eng_p1r/bin/jsepf_gk_k192); warm = k86GL6's launch list (runK_k86GL6/warmlist.txt).
# Only the phase-1 values (K.log 'lext it N: phase 1 ... t1 = ...') and the phase-1 cert files are wanted: outbox86L.sh files each new
# eng_p1r/cert_k86ML1_p1.json with K.log into outbox/lower.  lowerR2 / exactbasis / the dual watchers do not run here.
# Knobs (env): LOWER_THREADS (2), MAXIT (200), TAG (k86ML1), HSHIM_SOLVER (ipm).
N=/tmp/maclane-k86/fs/home/claude/GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp/s86_f2b7; B=$(dirname $N); Z=$B/s85_edge56
PATH=/tmp/maclane-k86/macshim:$PATH; export PATH
TAG=${TAG:-k86ML1}; TH=${LOWER_THREADS:-2}; MI=${MAXIT:-200}
for b in jsepf_gk_k192 jsep3; do [ -x $N/eng_p1r/bin/$b ] || { echo "launch_k86ML1: eng_p1r/bin/$b missing: run build.sh first" >&2; exit 2; }; done
export STACK=s77 ARGS=$N/args_A97_F_W13K3g.txt XF="c6le f2b7 f2b=$N/rules/A5final/rules_c67fa1d1_plus_A5_twins.json rpatN=$N/rpat/rpatN3_rotation_justified.txt,$N/offc/offc_K3g_2f4f0f02.txt p1r" KEYS=$N/p1r/cg_keys_r13w16_16fik.txt FEAS=$N/cand/sol_k85C_in03.json
pgrep -f "tag=$TAG " > /dev/null && { echo "launch_k86ML1: a run with tag=$TAG is already going" >&2; exit 3; }
export WARM=$(cat $N/maclane_warm_lower.txt)
echo "$(date -u +%H:%M:%SZ) [maclane] launch $TAG: ARGS $(basename $ARGS) ($(md5sum < $ARGS | cut -c1-8) in this pack), keys $(basename $KEYS) ($(md5sum < $KEYS | cut -c1-8)), threads $TH, $(echo $WARM | tr ',' '\n' | grep -c .) warm files" >> $N/run.log
mkdir -p $N/logs
nohup bash $N/p1r/runK86p.sh $MI $TH $TAG lext lextcert q7pen=1e-3 consk=20 consfrac=0.25 > $N/logs/runK_$TAG.out 2>&1 &
sleep 5
cd $N && nohup bash $N/outbox86L.sh $TAG > $N/logs/outbox86L_$TAG.out 2>&1 &
sleep 2; echo "launched $TAG: K run log $N/runK_$TAG/K.log, outbox /tmp/maclane-k86/outbox/lower/P1.txt, status: bash /tmp/maclane-k86/status.sh"
