#!/bin/bash
# maclane build: compile the C++ separators both lanes run (about 1 min).  usage: bash build.sh   [env: CXX (default clang++, else c++ / g++),
# CXXFLAGS (default -std=c++17 -O3 -pthread -ffp-contract=off -include cstdint), ARCHFLAG (default -mcpu=native when the compiler accepts it, else none),
# ALL=1 also builds the separators the lanes do not run (jsepf, jsep6, jsep7, jsepf_kstar_only, jsepf_nc_base) as a compile check]
# Sources: standard C++17 + std::thread only (no OpenMP, no bits/stdc++.h, no __int128, no x86 intrinsics).
# -ffp-contract=off: no fused multiply-adds (clang's default fuses a*b+c within an expression; the container's GCC -O3 -march=native
# build of jsepf_gk has 3 fused ones), so results do not depend on compiler contraction choices; any such difference is ~1e-16
# relative, far below the 1e-9 slack the separators compare loads with.  -include cstdint: the sources use uint64_t etc. without
# including <cstdint> (libstdc++ and libc++ both bring it in through <atomic> / <string>; this makes it explicit).
R=/tmp/maclane-k86
N=$R/fs/home/claude/GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp/s86_f2b7
[ -d $N/eng ] || { echo "build.sh: $N/eng not found: run relocate.sh first (bash $(cd "$(dirname "$0")" && pwd -P)/relocate.sh)" >&2; exit 2; }
if [ -z "$CXX" ]; then for c in clang++ c++ g++; do command -v $c > /dev/null 2>&1 && { CXX=$c; break; }; done; fi
CXXFLAGS=${CXXFLAGS:--std=c++17 -O3 -pthread -ffp-contract=off -include cstdint}
if [ -z "${ARCHFLAG+x}" ]; then
  T=${TMPDIR:-/tmp}/maclane_arch_$$; echo 'int main(){return 0;}' > $T.cpp
  if $CXX -mcpu=native -o $T $T.cpp > /dev/null 2>&1; then ARCHFLAG=-mcpu=native; else ARCHFLAG=""; fi; rm -f $T $T.cpp
fi
echo "build: $($CXX --version 2>&1 | head -1); flags $CXXFLAGS $ARCHFLAG"
FAIL=0; T0=$(date +%s)
b() {   # b <engine dir> <source> <binary>
  mkdir -p $1/bin
  if $CXX $CXXFLAGS $ARCHFLAG -o $1/bin/$3 $1/$2 2> $1/bin/$3.build.log; then echo "  ok   $(basename $1)/bin/$3  <- $2 $( [ -s $1/bin/$3.build.log ] && echo "(warnings: $1/bin/$3.build.log)")"
  else echo "  FAIL $(basename $1)/bin/$3  <- $2: see $1/bin/$3.build.log"; FAIL=1; fi
  [ -s $1/bin/$3.build.log ] || rm -f $1/bin/$3.build.log
}
for E in $N/eng $N/eng_p1r; do
  b $E jsep3.cpp jsep3
  b $E jsepf_gk.cpp jsepf_gk
done
b $N/eng_p1r jsepf_gk_k192.cpp jsepf_gk_k192
if [ "${ALL:-0}" = 1 ]; then
  for E in $N/eng $N/eng_p1r; do for s in jsepf jsep6 jsep7 jsepf_kstar_only jsepf_nc_base; do b $E $s.cpp $s; done; done
fi
echo "build: $([ $FAIL = 0 ] && echo OK || echo FAILED) in $(( $(date +%s) - T0 )) s"
exit $FAIL
