#!/bin/bash
# maclane: start the LOWER control lane k86ML1 (see README.md).  Knobs (env): LOWER_THREADS=2  MAXIT=200  HSHIM_SOLVER=ipm
R=/tmp/maclane-k86
exec bash $R/fs/home/claude/GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp/s86_f2b7/launch_k86ML1.sh "$@"
