#!/bin/bash
# maclane k5d add-on install: copies the add-on's payload into a maclane-k86 pack folder that is relocated and has the v2 add-on installed.
# usage: bash install_k5d.sh [pack folder]   (default: the maclane-k86 folder next to this add-on folder)
# Same rules as install_v2.sh (install_k5d.py): every payload file checked against MANIFEST_k5d.md5; the folder must be the maclane-k86
# pack (its MANIFEST.md5), relocated (.root), with the v2 add-on in; the packed root /tmp/maclane-k86 in the payload's text files is
# rewritten to the pack's root; new files only (a file the pack already has with other content stops the install before anything is
# written; identical files are skipped; files of an earlier install of this add-on are replaced).  Nothing to compile: the K5d lanes run
# the binaries build.sh (eng_p1r) and install_v2.sh (eng_v2) made.  Never touches a running lane's files.  Safe to run again.
A=$(cd "$(dirname "$0")" && pwd -P)
P=${1:-$(dirname "$A")/maclane-k86}
[ -d "$P" ] || { echo "install_k5d: pack folder $P not found.  usage: bash install_k5d.sh <maclane-k86 folder>" >&2; exit 2; }
P=$(cd "$P" && pwd -P)
case "$P" in *" "*) echo "install_k5d: the pack folder path must not contain spaces: $P" >&2; exit 2;; esac
python3 "$A/install_k5d.py" "$A" "$P" || exit $?
N=$P/fs/home/claude/GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp/s86_f2b7
for b in eng_p1r/bin/jsepf_gk_k192 eng_v2/bin/jsepf_gk_k192; do [ -x $N/$b ] || echo "install_k5d: WARNING: $b is not built (main pack: bash build.sh; v2 add-on: bash build_v2.sh)"; done
echo "install_k5d: done.  Next:"
echo "  cd $P && bash smoke_k5d.sh        # about 10 min; must end with SMOKE-K5D: PASS"
echo "  bash stop_v2.sh; bash stop.sh lower; bash launch_v2d.sh      # k86GV1 on K3gB5d"
echo "  bash recheck_k5d.sh repS1MW_02    # an upper point on K3l5d + 240 keys (eng_p1r)"
