#!/bin/bash
# maclane k5d add-on: start the KEYSPEC v2 lower lane k86GV1 on family K3gB5d (= K3gB5b + K5c V1-V8 + K5d B1; args_A97_F_W13K3gB5d.txt,
# container md5 ec9d8dbb) instead of K3gB5b: fs/.../s86_f2b7/launch_k86GV1d.sh.  Same tag, flags, 240 keys and warm set as launch_v2.sh,
# plus the previous k86GV1 run's rows if there was one.  Stop a running k86GV1 first (bash stop_v2.sh) and the k86ML1 lane (bash stop.sh lower).
# Needs smoke_v2.ok or smoke_k5d.ok (FORCE=1 overrides).  Knobs as launch_v2.sh (V2_THREADS 2, V2INNER 4, MAXIT, TAG, V2_WARM_ML1,
# ALLOW_ML1) + V2_WARM_PREV (1: warm-start from the previous k86GV1 rows) + ARGSV (another args file).
exec bash /tmp/maclane-k86/fs/home/claude/GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp/s86_f2b7/launch_k86GV1d.sh
