"""cmp_v2b.py <reference log> <new log> <required line prefix> [first N lines] -- cmp_v2.py (maclane v2 add-on) plus: lines
'<string>:N: RuntimeWarning: divide by zero | overflow | invalid value encountered in matmul' are dropped from both logs before comparing
(numpy 2.0.2 with Apple Accelerate BLAS raises these spurious floating-point flags in v2r.py's 0/1-mask matmul, whose operands are finite;
seen on the Studio, ST-51), and the number dropped is printed.  Otherwise as cmp_v2.py: absolute paths -> base names, timings ('11.0s'),
'(md5 xxxxxxxx)' normalised, 'hshim: ' lines dropped; a line whose words all match except decimal numbers that agree to 2e-5 relative
counts as 'close'; the line starting with <required line prefix> must be present in both and identical; with N, only the first N
(remaining) lines of each log are compared.  Exit 0 = identical or close only, 1 = real differences or the required line missing / different."""
import sys, re, difflib


def norm(l):
    l = re.sub(r"(?<![\w.-])/[^\s,:;'\"()\[\]{}]+/([^\s/,:;'\"()\[\]{}]+)", r'\1', l)
    l = re.sub(r'\b\d+(\.\d+)?s\b', 'Ns', l)
    l = re.sub(r'\(md5 [0-9a-f]{8}\)', '(md5 -)', l)
    return l.rstrip()


WARN = re.compile(r'^<string>:\d+: RuntimeWarning: (divide by zero|overflow|invalid value) encountered in matmul$')
DROPPED = {}


def load(fn, n):
    out = []; nd = 0
    for l in open(fn, errors='replace'):
        if WARN.match(l.rstrip('\n')): nd += 1; continue
        if l.startswith('hshim: ') or not l.strip(): continue
        out.append(norm(l))
        if n and len(out) >= n: break
    DROPPED[fn] = nd
    return out


FL = re.compile(r'[-+]?(?:\d+\.\d*|\.\d+|\d+(?=[eE]))(?:[eE][-+]?\d+)?')


def close(x, y):
    if x.startswith(REQ) or y.startswith(REQ): return False
    sx, sy = FL.split(x), FL.split(y)
    if sx != sy: return False
    for u, v in zip(FL.findall(x), FL.findall(y)):
        u, v = float(u), float(v)
        if abs(u - v) > 2e-5 * max(abs(u), abs(v)) + 1e-12: return False
    return True


REQ = sys.argv[3]; NL = int(sys.argv[4]) if len(sys.argv) > 4 else 0
a, b = load(sys.argv[1], NL), load(sys.argv[2], NL)
print('matmul RuntimeWarning lines dropped: reference %d, this run %d' % (DROPPED[sys.argv[1]], DROPPED[sys.argv[2]]))
va = [l for l in a if l.startswith(REQ)]; vb = [l for l in b if l.startswith(REQ)]
print('reference: %s' % (va[-1][:200] if va else 'no line starting with %r' % REQ)); print('this run:  %s' % (vb[-1][:200] if vb else 'no line starting with %r' % REQ))
real, near = [], []
for op, i1, i2, j1, j2 in difflib.SequenceMatcher(None, a, b, autojunk=False).get_opcodes():
    if op == 'equal': continue
    if op == 'replace' and i2 - i1 == j2 - j1 and all(close(a[i], b[j]) for i, j in zip(range(i1, i2), range(j1, j2))):
        near += list(zip(a[i1:i2], b[j1:j2])); continue
    real += ['-' + l for l in a[i1:i2]] + ['+' + l for l in b[j1:j2]]
for x, y in near: print('  close (numbers within 2e-5 relative):\n    -%s\n    +%s' % (x[:400], y[:400]))
for l in real: print('  ' + l[:400])
ok = not real and va and vb and va[-1] == vb[-1]
print('%d of %d reference lines differ after normalising (%d only within 2e-5 relative), %d extra lines in this run; %s line %s'
      % (sum(1 for l in real if l.startswith('-')) + len(near), len(a), len(near), sum(1 for l in real if l.startswith('+')), REQ.strip(), 'SAME' if va and vb and va[-1] == vb[-1] else 'DIFFERENT'))
sys.exit(0 if ok else 1)
