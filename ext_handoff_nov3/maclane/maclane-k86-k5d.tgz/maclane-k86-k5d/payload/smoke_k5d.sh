#!/bin/bash
# maclane k5d add-on smoke test (run after install_k5d.sh; about 10 min, 1 thread, ~1.5 GB).  OK / FAIL per step; must end "SMOKE-K5D: PASS".
#  1 installed: the v2 add-on (eng_v2 + its binaries), this add-on's files, eng_p1r's separators (jsepf_gk_k192)
#  2 the two new families: args_A97_F_W13K3gB5d.txt and args_A97_F_W13K3l5d.txt are the container's (md5 ec9d8dbb / 399cfc4c once the
#    pack root is taken out) and every file they name is in the pack
#  3 the v2 smoke's step 4 again (pcheck.py v2rtest on the GL5 cert) compared with tools/cmp_v2b.py, which drops numpy / Accelerate's
#    spurious "RuntimeWarning: ... encountered in matmul" lines (ST-51) and prints how many
#  4 the upper recheck command: bash recheck_k5d.sh on the Mac's own point repS1MW_02 (ref/k5d/sol_S1MW02k240d.json, md5 356beaa0) on
#    K3l5d + 240 keys with eng_p1r: its whole log must match the container's logs/upper_F_S1MW02k240d.log (UPPER-R2: FEASIBLE at
#    t = 0.027086414643; patterns 310 files, by kind D 18142 C 703 RPAT 158 RPATN 2034: ref/k5d/EXPECT_K3l5d_k240.txt) except its
#    'sender rows: min value' line, a diagnostic the container's eng_p1r gained after the pack was made
#  5 the start of k86GV1 on K3gB5d (launch_v2d.sh's command, maxit 1, stopped once its patterns are loaded): the first 8 lines as the
#    container's GV1 smoke (ref/v2/smoke_GV1.log) and the patterns line as expected (309 files; D 18232, C 772 as the container's k86GS7
#    on K3gB5d; RPATN 2284 = 2034 + the 250 of GV1's offc rpatN file).  SMOKE_K5D_HEAD=0 skips.
# Writes smoke_k5d.ok on PASS (launch_v2d.sh accepts it, or smoke_v2.ok).  Logs: smoke_k5d.log, smoke_k5d_*.log.
R=/tmp/maclane-k86
B=$R/fs/home/claude/GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp; N=$B/s86_f2b7; NN=$N
CERT=$R/fs/mnt/project-files/swarm/round6/W12-studio-K/from_opus/s86_k86GL5/cert_p1_00_def2afcc.json
PATH=$R/macshim:$PATH; export PATH
NF=0; LOG=$R/smoke_k5d.log; E=$N/eng_v2; CMP=$R/tools/cmp_v2b.py
PAT_GV1D="patterns: 309 files read, 2 missing ['out/job28/r_3.cfast', 'out/job28/r_4.cfast']; distinct by d {7: 9455, 8: 5966, 9: 3430, 10: 1439, 11: 626, 12: 105, 13: 85, 14: 85, 15: 85, 16: 85, 17: 85}; by kind {'D': 18232, 'C': 772, 'RPAT': 158, 'RPATN': 2284}"
say() { echo "$*" | tee -a $LOG; }
ok() { say "   OK   $*"; }
bad() { say "   FAIL $*"; NF=$((NF + 1)); }
cmd5() { python3 -c "import sys, hashlib; print(hashlib.md5(open(sys.argv[1], 'rb').read().replace(sys.argv[2].encode() + b'/fs/', b'/')).hexdigest()[:8])" "$1" "$R"; }
: > $LOG; rm -f $R/smoke_k5d.ok
say "maclane k5d add-on smoke $(date -u +%Y-%m-%dT%H:%M:%SZ) on $(uname -sm)"

say "1. installed"
HERE=$(cd "$(dirname "$0")" && pwd -P); MISS=""
for b in eng_v2/bin/jsepf_gk_k192 eng_v2/bin/jsepf_gk eng_v2/bin/jsep3 eng_p1r/bin/jsepf_gk_k192 eng_p1r/bin/jsepf_gk eng_p1r/bin/jsep3; do [ -x $N/$b ] || MISS="$MISS $b"; done
for f in $E/v2r.py $N/launch_k86GV1.sh $N/launch_k86GV1d.sh $N/U86e.sh $N/args_A97_F_W13K3gB5d.txt $N/args_A97_F_W13K3l5d.txt $N/w13/pat_K5c_D.out \
         $N/w13/pat_K5c_C.cfast $N/w13/pat_K5d_D.out $N/w13/pat_K5b_D.out $R/ref/v2/smoke_GV1.log $R/ref/k5d/upper_F_S1MW02k240d.log $R/ref/k5d/sol_S1MW02k240d.json $CMP; do
  [ -s $f ] || MISS="$MISS $(basename $f)"; done
if [ "$(cd $R 2>/dev/null && pwd -P)" != "$HERE" ]; then bad "the scripts point at $R but smoke_k5d.sh is in $HERE: run relocate.sh / install_k5d.sh"; echo "smoke_k5d: stopping"; exit 1
elif [ -n "$MISS" ]; then bad "missing:$MISS (install the v2 add-on, then this one; build.sh / install_v2.sh build the binaries)"; echo "smoke_k5d: stopping"; exit 1
else ok "v2 add-on, k5d files, eng_v2 and eng_p1r separators"; fi

say "2. families K3gB5d and K3l5d"
M1=$(cmd5 $N/args_A97_F_W13K3gB5d.txt); M2=$(cmd5 $N/args_A97_F_W13K3l5d.txt); MS=""
for a in $N/args_A97_F_W13K3gB5d.txt $N/args_A97_F_W13K3l5d.txt; do
  for f in $(tr ' ,=:' '\n\n\n\n' < $a | grep "^$R/fs/" | sort -u); do [ -e $f ] || MS="$MS $(basename $f)"; done; done
MS2=$(for x in $MS; do echo $x; done | grep -v '^r_[34]\.cfast$' | tr '\n' ' ')
if [ "$M1" = ec9d8dbb ] && [ "$M2" = 399cfc4c ] && [ -z "$MS2" ]; then ok "K3gB5d $M1, K3l5d $M2 (container md5s); every file they name is in the pack${MS:+ (missing as in the container:$MS)}"
else bad "K3gB5d $M1 (want ec9d8dbb), K3l5d $M2 (want 399cfc4c), missing files: ${MS2:-none}"; fi

say "3. v2rtest on the GL5 cert (the v2 smoke's step 4, with cmp_v2b; about 2 min)"
T0=$(date +%s)
(
  export STACK=s77 ARGS=$N/args_A97_F_W13K3g.txt KEYS=$N/p1r/cg_keys_r13w16_16fi.txt FAM=full KS=0; unset EGK; . $NN/env86.sh; N=$NN
  XFT="c6le f2b7 f2b=$N/rules/A5final/rules_c67fa1d1_plus_A5_twins.json rpatN=$N/rpat/rpatN3_rotation_justified.txt,$N/offc/offc_K3g_2f4f0f02.txt"
  WK=$SD/k5dsmoke_$$; mkdir -p $WK; cd $E
  nice -n 12 python3 pcheck.py v2rtest $F $X $A threads=1 work=$WK gkeys=$KEYS gkwin gkleaf $XFT v2r cert=$CERT > $R/smoke_k5d_v2test.log 2>&1
  rm -rf $WK
)
if python3 $CMP $R/ref/v2/v2rtest_b2_GL5.log $R/smoke_k5d_v2test.log "V2R-TEST: " > $R/smoke_k5d_v2test_cmp.log 2>&1; then
  ok "identical to the container's log ($(( $(date +%s) - T0 ))s; $(grep '^matmul RuntimeWarning' $R/smoke_k5d_v2test_cmp.log)): $(grep '^V2R-TEST: ' $R/smoke_k5d_v2test.log)"
else bad "differs ($(( $(date +%s) - T0 ))s; $R/smoke_k5d_v2test_cmp.log):"; head -20 $R/smoke_k5d_v2test_cmp.log | tee -a $LOG; fi

say "4. upper recheck on K3l5d + 240 keys (bash recheck_k5d.sh, eng_p1r; about 5 min)"
T0=$(date +%s)
bash $R/recheck_k5d.sh $R/ref/k5d/sol_S1MW02k240d.json 1 > $R/smoke_k5d_upper.out 2>&1
UL=$N/logs/upper_F_S1MW02k240d_K3l5d.log
# the container's eng_p1r gained one diagnostic line at 06:39Z 8 Nov (prelay2.py: "sender rows: min value ... -> senders need t >= ...",
# s86 tighten), after the pack's eng_p1r copy was taken; the pack's engine does not print it, so it is left out of the reference
grep -v '^sender rows: min value ' $R/ref/k5d/upper_F_S1MW02k240d.log > $R/smoke_k5d_upper_ref.log
if [ -f $UL ] && python3 $CMP $R/smoke_k5d_upper_ref.log $UL "UPPER-R2: " > $R/smoke_k5d_upper_cmp.log 2>&1 && grep -q "^UPPER-R2: FEASIBLE at t = 0.027086414643$" $UL; then
  ok "matches the container's log ($(( $(date +%s) - T0 ))s; $(tail -1 $R/smoke_k5d_upper_cmp.log | cut -d';' -f1)): $(grep '^UPPER-R2' $UL); $(grep '^patterns:' $UL | sed 's/.*\(by kind.*\)/\1/')"
else bad "differs from the container's log or not FEASIBLE ($(( $(date +%s) - T0 ))s; $R/smoke_k5d_upper_cmp.log, $UL):"; head -20 $R/smoke_k5d_upper_cmp.log 2>/dev/null | tee -a $LOG; tail -3 $R/smoke_k5d_upper.out | tee -a $LOG; fi

if [ "${SMOKE_K5D_HEAD:-1}" != 0 ]; then
  say "5. start of k86GV1 on K3gB5d (launch_v2d.sh's command, stopped after its patterns are loaded)"
  T0=$(date +%s)
  (
    export STACK=s77 ARGS=$N/args_A97_F_W13K3gB5d.txt KEYS=$N/p1r/cg_keys_r13w16_16fik.txt FAM=full KS=0; unset EGK; . $NN/env86.sh; N=$NN
    XF="c6le f2b7 f2b=$N/rules/A5final/rules_c67fa1d1_plus_A5_twins.json rpatN=$N/rpat/rpatN3_rotation_justified.txt,$N/offc/offc_K3g_2f4f0f02.txt p1r v2r v2seed=$N/v2r/seed_sol_k86GL5_p1.json v2rescan=1 v2inner=4"
    WK=$SD/k5dhead_$$; mkdir -p $WK; cd $N/eng_v2
    PYTHONUNBUFFERED=1 nice -n 12 python3 pcheck.py solveR2 $F $X keeppen tag=k5dsmokehead $A $CB warm=$(cat $N/maclane_warm_v2.txt) feas=$N/cand/sol_k85C_in03.json xcap=3 xpen=1e-3 lpmax=45 \
      threads=1 maxit=1 work=$WK gkeys=$KEYS gkwin gkleaf $XF lext lextcert q7pen=1e-3 consk=20 consfrac=0.25 > $R/smoke_k5d_head.log 2>&1 &
    P=$!; S=0
    while kill -0 $P 2>/dev/null && [ $S -lt 900 ]; do grep -q '^patterns:' $R/smoke_k5d_head.log && break; sleep 1; S=$((S + 1)); done
    kill $P 2>/dev/null; sleep 1; kill -9 $P 2>/dev/null; wait $P 2>/dev/null
    rm -rf $WK; rm -f $N/eng_v2/rows_k5dsmokehead.txt $N/eng_v2/sol_k5dsmokehead*.json $N/eng_v2/cert_k5dsmokehead*.json $N/eng_v2/inject_k5dsmokehead.*
  )
  PL=$(grep '^patterns:' $R/smoke_k5d_head.log | head -1)
  if python3 $CMP $R/ref/v2/smoke_GV1.log $R/smoke_k5d_head.log "exname:" 8 > $R/smoke_k5d_head_cmp.log 2>&1 && [ "$PL" = "$PAT_GV1D" ]; then
    ok "first 8 lines as the container's GV1 smoke, patterns line as expected ($(( $(date +%s) - T0 ))s): $(echo "$PL" | cut -c1-28) ... $(echo "$PL" | sed 's/.*\(by kind.*\)/\1/')"
  else bad "($(( $(date +%s) - T0 ))s; $R/smoke_k5d_head_cmp.log) patterns line: ${PL:-none}"; say "        want: $PAT_GV1D"; head -12 $R/smoke_k5d_head_cmp.log | tee -a $LOG; fi
fi
say ""
if [ $NF = 0 ]; then say "SMOKE-K5D: PASS (log $LOG)"; date -u +%Y-%m-%dT%H:%M:%SZ > $R/smoke_k5d.ok; else say "SMOKE-K5D: FAIL ($NF failed steps; log $LOG)"; fi
[ $NF = 0 ]
