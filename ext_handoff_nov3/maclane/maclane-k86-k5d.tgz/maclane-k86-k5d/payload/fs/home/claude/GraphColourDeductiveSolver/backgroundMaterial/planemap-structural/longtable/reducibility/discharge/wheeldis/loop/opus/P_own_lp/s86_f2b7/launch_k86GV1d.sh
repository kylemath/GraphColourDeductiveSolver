# maclane k5d add-on: the KEYSPEC v2 lower lane k86GV1 on family K3gB5d (args_A97_F_W13K3gB5d.txt, container md5 ec9d8dbb = K3gB5b +
# w13/pat_K5c_D.out 7da1cacd + w13/pat_K5c_C.cfast e7a63953 (K5c V1-V8, [E2] Studio K3CHK10) + w13/pat_K5d_D.out c5c4c210 (K5d B1, [E2]
# ST-49 + K3CHK main d8950ae17)).  Otherwise exactly the v2 add-on's launch_k86GV1.sh: same tag, keys p1r/cg_keys_r13w16_16fik.txt (240;
# 89 payer-7 -> eng_v2/bin/jsepf_gk_k192), flags GL6 + p1r v2r v2seed v2rescan=1 v2inner=$V2INNER, warm maclane_warm_v2.txt + k86ML1 rows.
# New here: (1) if an earlier k86GV1 run left rows (eng_v2/rows_<tag>.txt), their complete lines are snapshotted to
# v2r/rows_<tag>_snap_<UTC>.txt and added to the warm list (V2_WARM_PREV=0 skips; the family only adds kills, rows it no longer admits
# are dropped on admission); (2) the earlier run's K.log is kept as runK_<tag>/K_prev_<UTC>.log and outbox/v2lower/K_<tag>_prev_<UTC>.log
# (runK86v.sh truncates K.log); (3) outbox/v2lower/FAMILY.txt gets a line saying from which cert number on the certs are K3gB5d.
# (4) It accepts smoke_v2.ok or smoke_k5d.ok (FORCE=1 overrides).
# Knobs (env): V2_THREADS (2), V2INNER (4), MAXIT (200), TAG (k86GV1), V2_WARM_ML1 (1), V2_WARM_PREV (1), ALLOW_ML1, FORCE, ARGSV, HSHIM_SOLVER.
R=/tmp/maclane-k86
N=/tmp/maclane-k86/fs/home/claude/GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp/s86_f2b7; B=$(dirname $N)
PATH=$R/macshim:$PATH; export PATH
TAG=${TAG:-k86GV1}; TH=${V2_THREADS:-2}; MI=${MAXIT:-200}; V2I=${V2INNER:-4}; S=$(date -u +%Y%m%dT%H%MZ)
cmd5() { python3 -c "import sys, hashlib; print(hashlib.md5(open(sys.argv[1], 'rb').read().replace(sys.argv[2].encode() + b'/fs/', b'/')).hexdigest()[:8])" "$1" "$R"; }   # md5 with the pack root taken out (= the container's)
for b in jsepf_gk_k192 jsepf_gk jsep3; do [ -x $N/eng_v2/bin/$b ] || { echo "launch_k86GV1d: eng_v2/bin/$b missing: run the v2 add-on's install_v2.sh first" >&2; exit 2; }; done
for f in $N/args_A97_F_W13K3gB5d.txt $N/w13/pat_K5c_D.out $N/w13/pat_K5c_C.cfast $N/w13/pat_K5d_D.out $N/w13/pat_K5b_D.out $N/maclane_warm_v2.txt; do
  [ -f $f ] || { echo "launch_k86GV1d: $f missing: install the v2 add-on and then the k5d add-on" >&2; exit 2; }; done
if [ ! -f $R/smoke_v2.ok ] && [ ! -f $R/smoke_k5d.ok ] && [ "${FORCE:-0}" != 1 ]; then
  echo "launch_k86GV1d: neither smoke_v2.ok nor smoke_k5d.ok in $R (run bash smoke_k5d.sh); FORCE=1 overrides" >&2; exit 2; fi
pgrep -f "tag=$TAG " > /dev/null && { echo "launch_k86GV1d: a run with tag=$TAG is still going: bash $R/stop_v2.sh first" >&2; exit 3; }
if pgrep -f "tag=k86ML1 " > /dev/null && [ "${ALLOW_ML1:-0}" != 1 ]; then
  echo "launch_k86GV1d: the k86ML1 control lane is still running; GV1 replaces it on this Mac (core budget): bash $R/stop.sh lower first (ALLOW_ML1=1 overrides)" >&2; exit 3
fi
export STACK=s77 ARGS=${ARGSV:-$N/args_A97_F_W13K3gB5d.txt} KEYS=${KEYSV:-$N/p1r/cg_keys_r13w16_16fik.txt} FEAS=$N/cand/sol_k85C_in03.json
export XF="c6le f2b7 f2b=$N/rules/A5final/rules_c67fa1d1_plus_A5_twins.json rpatN=$N/rpat/rpatN3_rotation_justified.txt,$N/offc/offc_K3g_2f4f0f02.txt p1r v2r v2seed=$N/v2r/seed_sol_k86GL5_p1.json v2rescan=1 v2inner=$V2I"
WARM=$(cat $N/maclane_warm_v2.txt)
if [ "${V2_WARM_ML1:-1}" != 0 ] && [ -s $N/eng_p1r/rows_k86ML1.txt ]; then
  python3 -c "import sys; b = open(sys.argv[1], 'rb').read(); open(sys.argv[2], 'wb').write(b[:b.rfind(b'\n') + 1])" $N/eng_p1r/rows_k86ML1.txt $N/v2r/rows_k86ML1_snap_$TAG.txt   # complete lines only
  WARM=$WARM,$N/v2r/rows_k86ML1_snap_$TAG.txt
fi
if [ "${V2_WARM_PREV:-1}" != 0 ] && [ -s $N/eng_v2/rows_$TAG.txt ]; then
  python3 -c "import sys; b = open(sys.argv[1], 'rb').read(); open(sys.argv[2], 'wb').write(b[:b.rfind(b'\n') + 1])" $N/eng_v2/rows_$TAG.txt $N/v2r/rows_${TAG}_snap_$S.txt
  WARM=$WARM,$N/v2r/rows_${TAG}_snap_$S.txt
fi
export WARM
O=$R/outbox/v2lower; mkdir -p $O $N/logs $N/runK_$TAG
if [ -s $N/runK_$TAG/K.log ]; then cp $N/runK_$TAG/K.log $O/K_${TAG}_prev_$S.log; mv $N/runK_$TAG/K.log $N/runK_$TAG/K_prev_$S.log; fi
NX=$(ls $O | grep -c "^cert_${TAG}_p1_[0-9]*_.*\.json$"); NX=$(printf '%02d' $((NX + 1)))
echo "$(date -u +%Y-%m-%dT%H:%M:%SZ)  $TAG started on $(basename $ARGS) (container md5 $(cmd5 $ARGS)): certs from number $NX on are this family" >> $O/FAMILY.txt
echo "$(date -u +%H:%M:%SZ) [maclane] launch $TAG (v2, k5d): ARGS $(basename $ARGS) (container md5 $(cmd5 $ARGS)), keys $(basename $KEYS) ($(md5sum < $KEYS | cut -c1-8)), threads $TH, v2inner $V2I, $(echo $WARM | tr ',' '\n' | grep -c .) warm files" >> $N/run.log
nohup bash $N/v2r/runK86v.sh $MI $TH $TAG lext lextcert q7pen=1e-3 consk=20 consfrac=0.25 > $N/logs/runK_$TAG.out 2>&1 &
sleep 5
cd $N && nohup bash $N/v2r/outbox86V.sh $TAG > $N/logs/outbox86V_$TAG.out 2>&1 &
sleep 2; echo "launched $TAG on $(basename $ARGS): K run log $N/runK_$TAG/K.log, outbox $O/P1.txt (FAMILY.txt), status: bash $R/status_v2.sh"
