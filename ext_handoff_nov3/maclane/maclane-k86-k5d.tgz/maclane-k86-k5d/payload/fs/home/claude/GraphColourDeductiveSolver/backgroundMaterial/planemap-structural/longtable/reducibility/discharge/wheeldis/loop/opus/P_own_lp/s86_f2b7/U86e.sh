# maclane k5d add-on: U86.sh with the container's s86 GS5 engine override (env86.sh: E86=${E86OVR:-eng}), so an upperR2 check can run on
# eng_p1r (jsepf_gk_k192 for the 89 payer-7 keys of the 240-key file).  The pack's own env86.sh / U86.sh predate that line and stay as
# they are; this copy sets E86 itself after sourcing env86.sh.  Work dir wr86r_<tag> (stop.sh upper does not match it).
# usage: [STACK ARGS KEYS E86OVR] bash U86e.sh <tag> <sol> <threads> [extra flags]   -> logs/upper_<tag>.log, one run.log line
B=/tmp/maclane-k86/fs/home/claude/GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp; N=$B/s86_f2b7
export FAM=full KS=0; unset EGK; . $N/env86.sh; N=$N86; E86=${E86OVR:-$E86}
TAG=$1; SOL=$2; TH=${3:-1}; shift 3; WK=$SD/wr86r_$TAG; mkdir -p $WK $N/logs; cd $E86
nice -n 12 python3 pcheck.py upperR2 $F $X nomax sol=$SOL $A threads=$TH work=$WK gkeys=$KEYS gkwin gkleaf "$@" > $N/logs/upper_$TAG.log 2>&1
echo "$(date -u +%H:%M:%SZ) [s86U-$TAG] ENGINE $(basename $E86) STACK=$STACK ARGS=$(basename $ARGS) gkeys $(basename $KEYS) $SOL (md5 $(md5sum < $SOL | cut -c1-8)) extra: $*: $(grep 'UPPER-R2' $N/logs/upper_$TAG.log | tail -1) $(grep -c Traceback $N/logs/upper_$TAG.log) tracebacks" >> $N/run.log
rm -rf $WK
