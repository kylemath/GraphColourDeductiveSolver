#!/bin/bash
# maclane k5d add-on: recheck an upper point on family K3l5d + the 240-key file with the eng_p1r engine: the exhaustive upperR2 (gkwin
# gkleaf) the container's ladder runs for its rechecks (repladder_e.py REPL_ARGS2 -> U86.sh with E86OVR=eng_p1r; flags c6le f2b7
# f2b=<rules c67fa1d1> rpatN=<rpatN3 rotation-justified>).  About 5 min and ~1.5 GB on 1 thread.
# usage: bash recheck_k5d.sh <point> [threads, default 1]
#   point: a name in cand/ (repS1MW_02 or sol_repS1MW_02) or the path of a sol json
# env: RECHECK_ARGS (default args_A97_F_W13K3l5d.txt), RECHECK_TAG (default F_<name>_K3l5d)
# Result: logs/upper_<tag>.log, a run.log line, and in outbox/k5d/: the log and one line in RECHECK.txt:
#   name  md5 (8)  family  verdict  log  checked-at
R=/tmp/maclane-k86
N=$R/fs/home/claude/GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp/s86_f2b7
PATH=$R/macshim:$PATH; export PATH
P=$1; TH=${2:-1}
[ -n "$P" ] || { echo "usage: bash recheck_k5d.sh <cand name or sol json> [threads]" >&2; exit 2; }
if [ -f "$P" ]; then SOL=$(cd "$(dirname "$P")" && pwd -P)/$(basename "$P")
elif [ -f $N/cand/$P.json ]; then SOL=$N/cand/$P.json
elif [ -f $N/cand/sol_$P.json ]; then SOL=$N/cand/sol_$P.json
else echo "recheck_k5d: no point $P (looked for it as a file, cand/$P.json and cand/sol_$P.json)" >&2; exit 2; fi
NAME=$(basename $SOL .json); NAME=${NAME#sol_}
ARG=${RECHECK_ARGS:-$N/args_A97_F_W13K3l5d.txt}; FAMN=$(basename $ARG .txt); FAMN=${FAMN#args_A97_F_W13}
TAG=${RECHECK_TAG:-F_${NAME}_$FAMN}
for f in $N/eng_p1r/bin/jsepf_gk_k192 $N/eng_p1r/bin/jsepf_gk $N/eng_p1r/bin/jsep3; do [ -x $f ] || { echo "recheck_k5d: $f missing (bash build.sh)" >&2; exit 2; }; done
[ -f $ARG ] || { echo "recheck_k5d: $ARG missing (install_k5d.sh)" >&2; exit 2; }
echo "recheck_k5d: $NAME on $(basename $ARG) + cg_keys_r13w16_16fik.txt, engine eng_p1r, $TH thread(s): log $N/logs/upper_$TAG.log"
E86OVR=$N/eng_p1r STACK=s77 ARGS=$ARG KEYS=$N/p1r/cg_keys_r13w16_16fik.txt bash $N/U86e.sh $TAG $SOL $TH \
  c6le f2b7 f2b=$N/rules/A5final/rules_c67fa1d1_plus_A5_twins.json rpatN=$N/rpat/rpatN3_rotation_justified.txt
V=$(grep '^UPPER-R2' $N/logs/upper_$TAG.log | tail -1); [ -n "$V" ] || V="no verdict ($(grep -c Traceback $N/logs/upper_$TAG.log) tracebacks)"
O=$R/outbox/k5d; mkdir -p $O; cp $N/logs/upper_$TAG.log $O/
echo "$NAME    $(md5sum < $SOL | cut -c1-8)    $FAMN    $V    upper_$TAG.log    $(date -u +%Y-%m-%dT%H:%M:%SZ)" >> $O/RECHECK.txt
echo "recheck_k5d: $NAME: $V"
case "$V" in "UPPER-R2: FEASIBLE"*) exit 0;; *) exit 1;; esac
