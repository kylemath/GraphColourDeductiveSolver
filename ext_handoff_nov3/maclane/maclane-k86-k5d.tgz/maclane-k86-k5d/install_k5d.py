"""maclane k5d add-on installer (install_k5d.sh runs it).  usage: python3 install_k5d.py <add-on folder> <pack folder>
Same rules as the v2 add-on's install_v2.py; it also requires the v2 add-on to be installed in the pack."""
import os, sys, hashlib, time
A = os.path.abspath(sys.argv[1]); P = os.path.abspath(sys.argv[2]); PL = os.path.join(A, 'payload')
PACKED = '/tmp/' + 'maclane-k86'   # the root as packed, split so that a relocation never rewrites this line
MAIN_MANIFEST = 'e43670b926218d611be82a4db7c75dbb'   # md5 of MANIFEST.md5 of maclane-k86.tgz (2fa853ec), the pack this add-on extends
N = 'fs/home/claude/GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp/s86_f2b7'


def md5b(b): return hashlib.md5(b).hexdigest()
def die(msg, rc): print('install_k5d: ' + msg); sys.exit(rc)


# 1. the add-on itself
files = []; bad = 0
for l in open(os.path.join(A, 'MANIFEST_k5d.md5')):
    h, f = l.rstrip('\n').split('  ', 1); p = os.path.join(PL, f)
    if not os.path.isfile(p) or md5b(open(p, 'rb').read()) != h: bad += 1; print('BAD %s' % f)
    files.append(f)
print('add-on manifest: %d files, %d bad' % (len(files), bad))
if bad: die('the add-on is damaged; unpack maclane-k86-k5d.tgz again (check its md5 first)', 3)
# 2. the pack
for need in ('.root', 'MANIFEST.md5', 'tools/relocate.py', 'tools/hshim_check.py', N + '/eng_p1r/pcheck.py', N + '/env86.sh'):
    if not os.path.exists(os.path.join(P, need)): die('%s is not a maclane-k86 pack folder (no %s)' % (P, need), 2)
mm = md5b(open(os.path.join(P, 'MANIFEST.md5'), 'rb').read())
if mm != MAIN_MANIFEST and os.environ.get('MACLANE_K5D_ANYPACK') != '1':
    die('%s is not the maclane-k86 pack this add-on extends (MANIFEST.md5 md5 %s, want %s; MACLANE_K5D_ANYPACK=1 overrides)' % (P, mm, MAIN_MANIFEST), 2)
# the v2 add-on (eng_v2, the GV1 lane scripts, the K5h01 / K5b pattern files) must be in first
for need in ('v2addon/INSTALLED_v2.tsv', N + '/eng_v2/v2r.py', N + '/launch_k86GV1.sh', N + '/w13/pat_K5b_D.out', N + '/w13/pat_K5h01_C.cfast', 'tools/cmp_v2.py'):
    if not os.path.exists(os.path.join(P, need)): die('the v2 add-on is not installed in %s (no %s): install maclane-k86-v2addon.tgz first (bash install_v2.sh)' % (P, need), 2)
ROOT = open(os.path.join(P, '.root')).read().strip()
if os.path.realpath(ROOT) != os.path.realpath(P):
    die('the pack at %s is not relocated to its folder (its .root says %s): run  bash %s/relocate.sh  first' % (P, ROOT, P), 2)
if ' ' in ROOT: die('the pack root must not contain spaces: %s' % ROOT, 2)
# 3. plan: rewrite the packed root, compare with what the pack has
prev = {}
ip = os.path.join(P, 'k5d', 'INSTALLED_k5d.tsv')
if os.path.exists(ip):
    for l in open(ip):
        if l.startswith('#') or not l.strip(): continue
        f, h = l.rstrip('\n').split('\t')[:2]; prev[f] = h
plan = []; same = 0; upd = 0; conflicts = []; nrw = 0; nfrw = 0; inst = []
for f in files:
    src = os.path.join(PL, f); data = open(src, 'rb').read()
    if PACKED.encode() in data and b'\x00' not in data[:65536] and ROOT != PACKED:
        nrw += data.count(PACKED.encode()); nfrw += 1; data = data.replace(PACKED.encode(), ROOT.encode())
    mode = 0o755 if (os.stat(src).st_mode & 0o111 or f.endswith('.sh')) else 0o644
    d = os.path.join(P, f); inst.append((f, md5b(data)))
    if os.path.lexists(d):
        if not os.path.isfile(d) or os.path.islink(d): conflicts.append('%s (exists and is not a plain file)' % f); continue
        cur = open(d, 'rb').read()
        if cur == data: same += 1; continue
        if prev.get(f) == md5b(cur): upd += 1   # a file of an earlier install of this add-on, unchanged since: replace it
        else: conflicts.append('%s (the pack already has this file with other content)' % f); continue
    plan.append((f, data, mode))
if conflicts:
    for c in conflicts: print('CONFLICT %s' % c)
    die('%d conflicts: nothing written.  Move those files aside (or unpack the pack again) and rerun.' % len(conflicts), 4)
# 4. write (each file atomically: temp file + rename)
for f, data, mode in plan:
    d = os.path.join(P, f); os.makedirs(os.path.dirname(d), exist_ok=True)
    t = d + '.k5dtmp'
    with open(t, 'wb') as fh: fh.write(data)
    os.chmod(t, mode); os.replace(t, d)
# 5. records in <pack>/k5d/
VD = os.path.join(P, 'k5d'); os.makedirs(VD, exist_ok=True)
for fn in ('MANIFEST_k5d.md5', 'ORIGMD5_k5d.tsv', 'README_k5d.md', 'EXPECT_K3l5d_k240.txt'):
    with open(os.path.join(VD, fn), 'wb') as fh: fh.write(open(os.path.join(A, fn), 'rb').read())
with open(ip + '.tmp', 'w') as fh:
    fh.write('# file (pack relpath)\tmd5 as installed (root %s)\n' % ROOT)
    for f, h in inst: fh.write('%s\t%s\n' % (f, h))
os.replace(ip + '.tmp', ip)
with open(os.path.join(VD, 'INSTALLED.txt'), 'a') as fh:
    fh.write('%s  add-on %s -> pack %s: %d written (%d replaced), %d identical\n' % (time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), A, P, len(plan), upd, same))
print('install_k5d: %d files written (%d of them replacing an earlier install), %d already identical; root %s -> %s in %d files (%d occurrences)'
      % (len(plan), upd, same, PACKED, ROOT, nfrw, nrw))
