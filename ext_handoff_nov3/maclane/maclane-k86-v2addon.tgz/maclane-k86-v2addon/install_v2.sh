#!/bin/bash
# maclane v2 add-on install: copies the add-on's payload into an existing, relocated maclane-k86 pack folder and builds the eng_v2
# separators.  usage: bash install_v2.sh [pack folder]   (default: the maclane-k86 folder next to this add-on folder)
# Steps (install_v2.py): check every payload file against MANIFEST_v2.md5; check that the folder is the maclane-k86 pack this add-on was
# made for (its MANIFEST.md5) and that relocate.sh has pointed it at its folder (.root); rewrite the packed root /tmp/maclane-k86 in the
# payload's text files to the pack's root; copy (new files only: a file the pack already has with other content stops the install before
# anything is written; identical files are skipped; files of an earlier install of this add-on are replaced); then build_v2.sh.
# It never touches the running lanes' files (eng/, eng_p1r/, the upper / lower lane scripts).  Safe to run again.
A=$(cd "$(dirname "$0")" && pwd -P)
P=${1:-$(dirname "$A")/maclane-k86}
[ -d "$P" ] || { echo "install_v2: pack folder $P not found.  usage: bash install_v2.sh <maclane-k86 folder>" >&2; exit 2; }
P=$(cd "$P" && pwd -P)
case "$P" in *" "*) echo "install_v2: the pack folder path must not contain spaces: $P" >&2; exit 2;; esac
python3 "$A/install_v2.py" "$A" "$P" || exit $?
echo "install_v2: building the eng_v2 separators (bash $P/build_v2.sh; log $P/build_v2.log)"
bash "$P/build_v2.sh" > "$P/build_v2.log" 2>&1; rc=$?
cat "$P/build_v2.log"
[ $rc = 0 ] || { echo "install_v2: build FAILED (see $P/build_v2.log)" >&2; exit 4; }
echo "install_v2: done.  Next:"
echo "  cd $P && bash smoke_v2.sh        # about 10 min; must end with SMOKE-V2: PASS"
echo "  bash stop.sh lower && bash launch_v2.sh      # GV1 replaces the k86ML1 control lane"
