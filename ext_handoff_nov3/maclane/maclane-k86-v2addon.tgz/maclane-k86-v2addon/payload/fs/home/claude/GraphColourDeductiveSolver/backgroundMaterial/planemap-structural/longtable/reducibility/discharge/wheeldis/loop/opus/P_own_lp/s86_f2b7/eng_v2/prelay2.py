# prelay2.py (Opus P_own_lp, stage 12): 6-centred relay R6x2 (spec in FINDINGS.md stage 12).  exec'd in pcheck.py.
AP = 'noapex' not in FLAGS          # validation V1: noapex = s10's class
AC = 'apexcls' in FLAGS             # reduced s12: apex letters read only as small (5) / big (7) witnesses
def ap(x): return (7 if x >= 7 else 5) if AC else x
FY = 'fy' in FLAGS                   # s35f-fyq (port of s25c, RELAY_SPEC_s20 level 1): face-aware five -> big split; z key = fykey
FY2 = 'fy2' in FLAGS                 # s43 (RELAY_SPEC_s43): fy cluster level 2, h2 = c2(face apex private t) unmasked at faces
ZH = 'zh' in FLAGS or FY             # stage 13 (R7h): big-centred split, z[five link from the big, hat classes on both sides]
ZV = {}
ZR = 'zr' in FLAGS                   # stage 33 (RELAY_SPEC_s22): zr[K] >= 0, big -> adjacent five, same key as z; z, zr, rr capped at zcap
assert not ZR or ZH, 'zr needs zh'
assert not FY or ('hat5' in FLAGS and not ZR and 'zh' not in FLAGS), 'fy port: needs hat5, excludes zh/zr'
assert not FY2 or FY, 'fy2 needs fy'
ZRV = {}; ZCAP = float(OPT.get('zcap', '3'))
Q7 = 'q7' in FLAGS                   # stage 14 (R77): big -> adjacent 7 inflow q[the 7's whole link, read from the sender]
Q7FLIP = 'q7flip' in FLAGS             # s67 orientation control ONLY: sign of the q coefficient flipped (key-holder as payee)
Q7M = 'q7m' in FLAGS                 # s67: masked q7 (needs q7 + f2b): payer Q sigs carry the private-letter masks (L3T & ~extra7) of the two sides
Q7CAP = float(OPT['q7cap']) if 'q7cap' in OPT else None   # s67: optional upper bound on q columns (default none)
QV = {}
V6 = 'v6' in FLAGS                   # stage 15: a 6 next to a 7 passes v[its link at u + 3-class apexes] on to the 7
VV = {}
def cv(x): return x if x < 7 else 7
W19 = 'w19' in FLAGS                 # stage 19 oracle: W (7, 5-5-5 face, face-adjacent 6 with private 5) forbidden by assumption
F16 = 'filt16' in FLAGS              # stage 16 A': allowed-private sets from the 3-ball containment filter (s16_filter.local)
KT = {}
def kt_load():
    if F16 and not KT:
        for U in (7, 8, 9): KT[U] = np.load(OPT['killtab'] + '_U%d.npy' % U)
def amask(U, a, b, e, f, s0, s1, s2, s3):
    """allowed-letter bitmask (bit i = LET[i]) for the private of a 6 at w_j: a,b,e,f = w_{j-2},w_{j-1},w_{j+1},w_{j+2};
    s0..s3 = s_{j-2..j+1}; letters 5..9"""
    kt_load(); m = 31 & ~int(KT[U][a - 5, b - 5, e - 5, f - 5, s0 - 5, s1 - 5, s2 - 5, s3 - 5])
    if W19 and U == 7 and ((e == 5 and f == 5 and s3 == 5) or (b == 5 and a == 5 and s0 == 5)): m &= ~1   # stage 19 oracle W
    if PCAM: m &= ~int(PCAM[U][a - 5, b - 5, e - 5, f - 5, s0 - 5, s1 - 5, s2 - 5, s3 - 5])   # s36g PRIVCELL_SPEC 2.3: absorbed private-cell names
    return m
# s36g (PRIVCELL_SPEC.md): private-cell names, option pcell=FILE (one q-name per line).  Absorbed as filt16 amask bits
# (PCAM), l3q mask bits (PCL3) and receiver f-patterns (PATS); every other name is logged with its reason.  No file: no change.
PCAM = {}; PCL3 = {}
if OPT.get('pcell'):
    exec(open(os.path.join(HERE, 'privcell.py')).read().split("if __name__ == '__main__':")[0], globals())
    _pcn = [l.split()[0] for l in open(OPT['pcell']) if l.strip() and not l.startswith('#')]
    PCAM, PCL3, _pcp = pc_build(_pcn, dmax=DMAX)
    if not F16: PCAM = {}
    _pnew = 0
    for _d, _ps in _pcp.items():
        for _P in _ps:
            if _P not in PATS[_d]: PATS[_d].add(_P); PSRC['PCELL'] += 1; _pnew += 1
    log('pcell: %d names from %s; amask bits set U7/U8/U9 = %s; l3q keys hit %d; f-patterns added %d' % (len(_pcn), OPT['pcell'],
        [int((PCAM[U] != 0).sum()) if PCAM else 0 for U in (7, 8, 9)], len(PCL3), _pnew))
    for _nm, _cn, _k, _st, _why in PC_LOG: log('  pcell %s = %s : %s %s' % (_nm, _cn, _st if _st else 'not absorbed', _why))
def cmd_pcellcheck():
    """amask with pcell vs the s25c g7 flag formula (flag g7ref: KT & ~bit 0 under the g7 condition) or vs the plain KT, over every (U, a, b, e, f, s0..s3)"""
    kt_load(); bad = 0; n = 0; nk = 0
    for U in (7, 8, 9):
        for a, b, e, f, s0, s1, s2, s3 in itertools.product(LET, repeat=8):
            m = amask(U, a, b, e, f, s0, s1, s2, s3); n += 1
            g = 31 & ~int(KT[U][a - 5, b - 5, e - 5, f - 5, s0 - 5, s1 - 5, s2 - 5, s3 - 5])
            if 'g7ref' in FLAGS and ((e == 5 and f == 5 and s2 == 6 and s3 == 5) or (b == 5 and a == 5 and s1 == 6 and s0 == 5)): g &= ~1
            if m != g: bad += 1
            if m != 31 & ~int(KT[U][a - 5, b - 5, e - 5, f - 5, s0 - 5, s1 - 5, s2 - 5, s3 - 5]): nk += 1
    log('pcellcheck: %d amask entries; differ from the %s reference: %d; differ from the plain kill table: %d' % (n, 'g7 flag' if 'g7ref' in FLAGS else 'plain', bad, nk))
def pallow(sig): return [p for i, p in enumerate(LET) if not F16 or (sig[-1] >> i) & 1]
# ---- s51 (RELAY_SPEC_s51): x-outer.  xo[tauo] = refined L2 key (sides (c, a, b, ea, eb)); receiver credit XQ[q] per big link
# position, q = (U, V, A, B), A/B = visible side tuples (c, a, b, o, mask of the unseen outer letter); mrowX rows bound XQ.
XO = 'xo' in FLAGS
assert not XO or 'xon' in FLAGS, 'xo needs xon'
XOB = OPT.get('xobroken', '')        # controls only: 'end' = in-key outer letters read at the wrong end; 'sign' = receiver gets -XQ
assert XOB in ('', 'end', 'sign')
XOV = {}                             # tauo -> value (solution / LP)
XNOMASK = [False]                    # xoselftest only
def sidex(c, a, b, ea, eb): return (((LI[c] * 5 + LI[a]) * 5 + LI[b]) * 5 + LI[ea]) * 5 + LI[eb]
def tauo(fl, tl, s1, s2):
    lo, hi = min(s1, s2), max(s1, s2); return (((LI[fl] - 2) * 3 + (LI[tl] - 2)) * 3125 + lo) * 3125 + hi
def tauo_dec(t):
    hi = t % 3125; lo = (t // 3125) % 3125; fi, ti = divmod(t // 3125 ** 2, 3)
    dg = lambda S: tuple(5 + (S // 5 ** k) % 5 for k in (4, 3, 2, 1, 0))
    return (7 + fi, 7 + ti, dg(lo), dg(hi))
_XAU = {}
def xo_au(U, sg, k1, k2, k3, k4, k5, k6):
    """51.3: OR of the 6's amask over the two letters outside u's window. sg = +1 (6 at i+1): k = (w_{i-1}, w_i, w_{i+2},
    s_{i-1}, s_i, s_{i+1}), outside w_{i+3}, s_{i+2}; sg = -1 (6 at i-1): k = (w_{i-2}, w_i, w_{i+1}, s_{i-2}, s_{i-1}, s_i),
    outside w_{i-3}, s_{i-3}.  31 without filt16."""
    if not F16: return 31
    kk = (U, sg, k1, k2, k3, k4, k5, k6)
    if kk not in _XAU:
        m = 0
        for x_, y_ in itertools.product(LET, repeat=2):
            m |= amask(U, k1, k2, k3, x_, k4, k5, k6, y_) if sg > 0 else amask(U, x_, k1, k2, k3, y_, k4, k5, k6)
        _XAU[kk] = m
    return _XAU[kk]
_XNR = {}
def xo_nr6(U, x1, x2, x4, x5):
    """bitmask of p with the 6-wheel (U, x1, x2, p, x4, x5) not R6"""
    kk = (U, x1, x2, x4, x5)
    if kk not in _XNR: _XNR[kk] = sum(1 << k for k, p in enumerate(LET) if not isR6([U, x1, x2, p, x4, x5]))
    return _XNR[kk]
def xo_vis(U, V, W_, S_):
    """51.3: credit key q of the big link vertex w_i (letter V); W_(k) = w_{i+k}, S_(k) = s_{i+k} (letters)"""
    out = []
    for sg in (1, -1):
        if sg > 0: c, a, b, o = W_(1), S_(0), W_(2), S_(1)
        else: c, a, b, o = W_(-1), S_(-1), W_(-2), S_(-2)
        if c == 5: m = 1 << LI[o]
        elif c == 6 and XNOMASK[0]: m = 31
        elif c == 6:
            if sg > 0: m = xo_au(U, 1, W_(-1), W_(0), W_(2), S_(-1), S_(0), S_(1)) & xo_nr6(U, W_(2), S_(1), S_(0), W_(0))
            else: m = xo_au(U, -1, W_(-2), W_(0), W_(1), S_(-2), S_(-1), S_(0)) & xo_nr6(U, W_(0), S_(-1), S_(-2), W_(-2))
        else: m = 31
        out.append((c, a, b, o, m))
    return (U, V, min(out), max(out))
_XC = {}
def xo_cands(q):
    """51.3: [(eA, eB, in key, out key)] over the masks of q"""
    if q not in _XC:
        U, V, A, B = q; res = []
        for eA in LET:
            if not (A[4] >> LI[eA]) & 1: continue
            for eB in LET:
                if not (B[4] >> LI[eB]) & 1: continue
                if XOB == 'end':   # broken control: the in-key's outer letters read at the wrong end (out-key correct), so the
                    # receiver's inflow no longer matches the sender's outflow (a one-sided bug; swapping both is a relabelling)
                    ti = tauo(V, U, sidex(A[0], A[1], A[2], A[3], eA), sidex(B[0], B[1], B[2], B[3], eB))
                    to = tauo(U, V, sidex(A[0], A[2], A[1], A[3], eA), sidex(B[0], B[2], B[1], B[3], eB))
                else:
                    ti = tauo(V, U, sidex(A[0], A[1], A[2], eA, A[3]), sidex(B[0], B[1], B[2], eB, B[3]))
                    to = tauo(U, V, sidex(A[0], A[2], A[1], A[3], eA), sidex(B[0], B[2], B[1], B[3], eB))
                res.append((eA, eB, ti, to))
        _XC[q] = res
    return _XC[q]
def xo_term(q): return q[2][4] != 0 and q[3][4] != 0 and any(ti != to for _, _, ti, to in xo_cands(q))
def xo_eff(q):
    """XQeff(q) = max over the candidates of xo[in] - xo[out] (the smallest XQ the mrowX rows allow)"""
    return max((XOV.get(ti, 0.0) - XOV.get(to, 0.0)) if ti != to else 0.0 for _, _, ti, to in xo_cands(q))
def xo_recv_terms(d, w, s):
    cf = collections.Counter(); U = min(d, 9)
    for i in range(d):
        if w[i] < 7: continue
        q = xo_vis(U, w[i], lambda k, i=i: w[(i + k) % d], lambda k, i=i: s[(i + k) % d])
        if xo_term(q): cf[('XQ', q)] += -1 if XOB == 'sign' else 1
    return cf
def xo_mrows(q):
    """the mrowX rows of q: (coefficients, [eA, eB])"""
    for eA, eB, ti, to in xo_cands(q):
        cf = collections.Counter({('XQ', q): -1})
        if ti != to: cf[('xo', ti)] += 1; cf[('xo', to)] -= 1
        yield dict(cf), [eA, eB]
def xo_win(W, U):
    """51.5(4): + XQeff at every big-centred window touched by a positive xo key (all other windows: XQeff = 0)"""
    if not XO: return
    touched = set()
    for t_, v in XOV.items():
        if not v > 0: continue
        fl, tl, S1, S2 = tauo_dec(t_)
        for SP, SM in ((S1, S2), (S2, S1)):
            if tl == U:   # in key at V = fl: + side (c, s_i, w_{i+2}, e+, s_{i+1}), - side (c, s_{i-1}, w_{i-2}, e-, s_{i-2})
                o = 3 if XOB == 'end' else 4
                touched.add((fl, SM[2], SM[0], SP[0], SP[2], SM[o], SM[1], SP[1], SP[o]))
            if fl == U:   # out key at V = tl: + side (c, w_{i+2}, s_i, s_{i+1}, e+)
                o = 3
                touched.add((tl, SM[1], SM[0], SP[0], SP[1], SM[o], SM[2], SP[2], SP[o]))
    for V, a, b, e, f, p, q_, r, s_ in touched:
        Wl = {-2: a, -1: b, 0: V, 1: e, 2: f}; Sl = {-2: p, -1: q_, 0: r, 1: s_}
        q = xo_vis(U, V, Wl.__getitem__, Sl.__getitem__)
        if xo_term(q): W[LI[a], LI[b], LI[V], LI[e], LI[f], LI[p], LI[q_], LI[r], LI[s_]] += (-1 if XOB == 'sign' else 1) * xo_eff(q)
def cmd_xoselftest():
    """s51: physical consistency of the xo key from both ends of an edge u - v (independent link-list construction)."""
    rng = np.random.default_rng(int(OPT.get('seed', '1'))); N = int(OPT.get('N', '20000')); bad = 0; n = 0
    XNOMASK[0] = True; _XC.clear()   # key reading only: 6-private masks = 31 here (domains are filt16 / R6 soundness, not tested)
    def L(): return int(rng.choice(LET))
    def nb(link, x, y):   # in the cyclic list link, the neighbour of x other than y
        k = link.index(x); m = len(link); a_, b_ = link[(k - 1) % m], link[(k + 1) % m]
        assert y in (a_, b_); return b_ if a_ == y else a_
    def phys(deg, links, fl, tl, cs):
        sides = []
        for c in cs:
            lk = links[c]; a_ = nb(lk, fl, tl); b_ = nb(lk, tl, fl); ea = nb(lk, a_, fl); eb = nb(lk, b_, tl)
            sides.append(sidex(deg[c], deg[a_], deg[b_], deg[ea], deg[eb]))
        return tauo(min(deg[fl], 9), min(deg[tl], 9), sides[0], sides[1])
    for it in range(N):
        du = int(rng.integers(7, 12)); dv = int(rng.integers(7, 12)); U = min(du, 9); V = min(dv, 9)
        deg = {'u': du, 'v': dv}
        for nm in ('cp', 'cm', 'si', 'sim', 'wp2', 'wm2', 'sp1', 'sm2'): deg[nm] = L()
        links = {}
        for c, si_, w2, s1 in (('cp', 'si', 'wp2', 'sp1'), ('cm', 'sim', 'wm2', 'sm2')):
            if deg[c] == 5: links[c] = ['u', 'v', si_, s1, w2]
            else:
                mid = ['%s_x%d' % (c, k) for k in range(deg[c] - 5)]
                for x_ in mid: deg[x_] = L()
                links[c] = ['u', 'v', si_] + mid + [s1, w2]
        e_p = nb(links['cp'], 'si', 'v'); e_m = nb(links['cm'], 'sim', 'v')
        # u's arrangement: position 0 = v; w_1 = c+, w_2 = w_{+2}, s_0 = s_i, s_1 = s_{i+1}; mirror on the - side; rest random
        wu = [None] * du; su = [None] * du
        wu[0] = dv; wu[1] = deg['cp']; wu[2] = deg['wp2']; wu[-1] = deg['cm']; wu[-2] = deg['wm2']
        su[0] = deg['si']; su[1] = deg['sp1']; su[-1] = deg['sim']; su[-2] = deg['sm2']
        for k in range(du):
            if wu[k] is None: wu[k] = L()
            if su[k] is None: su[k] = L()
        wu[0] = V
        # v's arrangement: position 0 = u; w'_1 = c+, w'_2 = s_i, w'_{-1} = c-, w'_{-2} = s_{i-1}; s'_0 = w_{+2}, s'_1 = e+, s'_{-1} = w_{-2}, s'_{-2} = e-
        wv = [None] * dv; sv_ = [None] * dv
        wv[0] = U; wv[1] = deg['cp']; wv[2] = deg['si']; wv[-1] = deg['cm']; wv[-2] = deg['sim']
        sv_[0] = deg['wp2']; sv_[1] = deg[e_p]; sv_[-1] = deg['wm2']; sv_[-2] = deg[e_m]
        for k in range(dv):
            if wv[k] is None: wv[k] = L()
            if sv_[k] is None: sv_[k] = L()
        t_vu = phys(deg, links, 'v', 'u', ('cp', 'cm')); t_uv = phys(deg, links, 'u', 'v', ('cp', 'cm'))
        qu = xo_vis(U, V, lambda k: wu[k % du], lambda k: su[k % du]); qv = xo_vis(V, U, lambda k: wv[k % dv], lambda k: sv_[k % dv])
        cu = xo_cands(qu); cv = xo_cands(qv)
        okm_u = any(ti == t_vu and to == t_uv for _, _, ti, to in cu); okm_v = any(ti == t_uv and to == t_vu for _, _, ti, to in cv)
        n += 1
        if not okm_u or not okm_v:
            bad += 1
            if bad <= 3: log('  xoselftest mismatch: u %s/%s v %s/%s true v->u %s u->v %s' % (wu, su, wv, sv_, tauo_dec(t_vu), tauo_dec(t_uv)))
    XNOMASK[0] = False; _XC.clear()
    log('xoselftest%s: %d edges (both ends), %d key mismatches' % (' (BROKEN %s)' % XOB if XOB else '', n, bad))
def v_of(m, ar, al):
    a = tuple(m) + (cv(ar), cv(al)); b = (m[0],) + tuple(reversed(m[1:])) + (cv(al), cv(ar)); return min(a, b)
def sigv_of(U, wr, sr, sl, wl, wrr, wll):
    a = (U, wr, sr, sl, wl, cv(wrr), cv(wll)); b = (U, wl, sl, sr, wr, cv(wll), cv(wrr)); return min(a, b)
def sigv_keys(sg):
    U, wr, sr, sl, wl, wrr, wll = sg[:7]
    return sorted({v_of((U, wr, sr, p, sl, wl), wrr, wll) for p in pallow(sg) if not isR6((U, wr, sr, p, sl, wl))})
def qkey(m):
    m = tuple(m); return min(m, (m[0],) + tuple(reversed(m[1:])))
def q7sig(U, a, b, c, e, m1=None, m2=None):
    # s67: optional masks m1 (letters allowed for p1, the private next to b) and m2 (p2, next to c); both 31 = unmasked = the old 5-tuple signature
    x = (U, a, b, c, e)
    if m1 is None or (m1 == 31 and m2 == 31): return min(x, (U, e, c, b, a))
    return min(x + (m1, m2), (U, e, c, b, a, m2, m1))
def q7keys(sg):
    U, a, b, c, e = sg[:5]
    P1 = LET if len(sg) < 7 else [l for k, l in enumerate(LET) if (sg[5] >> k) & 1]; P2 = LET if len(sg) < 7 else [l for k, l in enumerate(LET) if (sg[6] >> k) & 1]
    return sorted({qkey((U, a, b, p1, p2, c, e)) for p1 in P1 for p2 in P2 if ''.join(map(str, canon((U, a, b, p1, p2, c, e)))) not in RBIG})
def q7_inflow(w):
    """coefficient dict of q keys flowing into a 7 with link w (d = 7)"""
    cf = collections.Counter()
    for j in range(7):
        if w[j] >= 7: cf[qkey(tuple(w[(j + i) % 7] for i in range(7)))] += 1
    return cf
_L7 = []
def write_bonus():
    if not _L7:
        seen = set()
        for w in itertools.product(LET, repeat=7):
            c = canon(w)
            if c not in seen: seen.add(c); _L7.append(c)
    fn = os.path.join(WORK, 'bonus7.txt'); n = 0
    with open(fn, 'w') as f:
        for c in _L7:
            v = sum(m * QV.get(k, 0.0) for k, m in q7_inflow(c).items())
            if v > 0: f.write('%s %.15f\n' % (''.join(map(str, c)), v)); n += 1
    BONUSF[0] = fn if n else None
    return n
def zkey(n, hr, hl):
    """n = (U, n1, n2, n3, n4) the five's link read from the big U (n1 = next spoke); hr = class of the hat between U and n1,
    hl = class of the hat between U and n4 (0 small / 1 big)"""
    a = tuple(n) + (hr, hl); b = (n[0], n[4], n[3], n[2], n[1], hl, hr); return min(a, b)
FYMASK = 2   # ---- fy (verbatim from s25c/prelay2.py)
def fy_vis(n): return (True, n[1] == 5, FY2 and ((n[1] == 5 and n[2] == 5) or (n[4] == 5 and n[3] == 5)), n[4] == 5, True)   # s43: level 2 at faces
def fykey(n, h):
    v = fy_vis(n); hm = tuple(h[k] if v[k] else FYMASK for k in range(5))
    a = tuple(n) + hm; b = (n[0], n[4], n[3], n[2], n[1]) + tuple(reversed(hm)); return min(a, b)
def fy_sender_key(w, H, j): return fykey(tuple(w[(j + i) % 5] for i in range(5)), tuple(H[(j + i) % 5] for i in range(5)))
def fy_recv_key(U, a, b, e, f, p, q, r, s_, tau=None):
    n = (U, e, r, q, b)
    if fy_vis(n)[2]: assert tau in (0, 1), 'fy2: a face five needs its cell class'
    return fykey(n, (c2(f), c2(s_) if e == 5 else FYMASK, tau if tau is not None else FYMASK, c2(p) if b == 5 else FYMASK, c2(a)))
def fy2_allowed(sn, sp):   # s43 43.1: classes of t leaving the apex five's link (5, 5, sn, t, sp) non-R5; empty -> both
    A = tuple(c for c in (0, 1) if any(not isR5((5, 5, sn, x, sp)) for x in CLS2[c])); return A or (0, 1)
def fy2_cells(d, w, s):
    """faces i (w_i = w_{i+1} = s_i = 5) and the cells [(label, {face: class})] of a receiver row (s43 43.3)"""
    if not FY2: return [('', {})]
    F = [i for i in range(d) if w[i] == 5 and w[(i + 1) % d] == 5 and s[i] == 5]
    for i in F: assert (i + 1) % d not in F, 'fy2: five in two faces (its link (U,5,5,5,5) is R5: row not admissible)'
    As = [fy2_allowed(s[(i + 1) % d], s[(i - 1) % d]) for i in F]
    return [(','.join('%d:%d' % (i, c) for i, c in zip(F, cb)), dict(zip(F, cb))) for cb in itertools.product(*As)]
ZTF = {}
def g2_of(n1, n2, n3, n4, n5, ar, al):
    ar, al = ap(ar), ap(al)
    a = (n1, c2(n2), c2(n3), c2(n4), n5) + ((ar, al) if AP else ())
    b = (n5, c2(n4), c2(n3), c2(n2), n1) + ((al, ar) if AP else ())
    return min(a, b)
def h2_of(m, ar, al):
    """m = the 6's link rotated to start at the big; ar = apex beyond (m0, m1), al = apex beyond (m5, m0)"""
    ar, al = ap(ar), ap(al)
    a = tuple(m) + ((ar, al) if AP else ()); b = (m[0],) + tuple(reversed(m[1:])) + ((al, ar) if AP else ())
    return min(a, b)
def sig2_of(U, wr, sr, sl, wl, wrr, wll):
    wrr, wll = ap(wrr), ap(wll)
    a = (U, wr, sr, sl, wl) + ((wrr, wll) if AP else ()); b = (U, wl, sl, sr, wr) + ((wll, wrr) if AP else ())
    return min(a, b)
def sig2_keys(sig):
    U, wr, sr, sl, wl = sig[:5]; wrr, wll = (sig[5], sig[6]) if AP else (0, 0)
    return sorted({h2_of((U, wr, sr, p, sl, wl), wrr, wll) for p in pallow(sig) if not isR6((U, wr, sr, p, sl, wl))})
F5 = 'face5' in FLAGS                # stage 17: five -> five transfer f across a 5-5-5 face (FINDINGS stage 17)
FV = {}
_m5 = {}
def mate_ok(e, hb1, hb2, o):
    """face-mate five with link (5, e, hat1, hat2, o): some completion of the two hat classes is non-R5"""
    k_ = (e, hb1, hb2, o)
    if k_ not in _m5: _m5[k_] = any(not isR5((5, e, x_, y_, o)) for x_ in CLS2[hb1] for y_ in CLS2[hb2])
    return _m5[k_]
def face_one(w, H, k, cf):
    """f terms of five v (word w, hat classes H; H[k] = class of the hat between w_k and w_{k+1}) on the 5-5-5 face
    (v, b = w_k, c = w_{k+1}).  K(x->y) = (e_xy, c k_x, c e_xz, c k_y, c e_yz, c k_z).  False if a mate is R5."""
    n = 5
    em, ka, ec = w[(k - 1) % n], w[(k - 2) % n], w[(k + 2) % n]     # e_ab, k_a, e_ca (exact)
    kb, ebc, kc = H[(k - 1) % n], H[k], H[(k + 1) % n]             # k_b, e_bc, k_c (classes)
    if not mate_ok(em, kb, ebc, 5) or not mate_ok(5, ebc, kc, ec): return False
    cf[('f', (em, c2(ka), c2(ec), kb, ebc, kc))] -= 1              # v -> b
    cf[('f', (ec, c2(ka), c2(em), kc, ebc, kb))] -= 1              # v -> c
    cf[('f', (em, kb, ebc, c2(ka), c2(ec), kc))] += 1              # b -> v
    cf[('f', (ec, kc, ebc, c2(ka), c2(em), kb))] += 1              # c -> v
    return True
def face_terms(w, H):
    cf = collections.Counter()
    for k in range(5):
        if w[k] == 5 and w[(k + 1) % 5] == 5 and not face_one(w, H, k, cf): return None
    return cf
def face_selftest(N=200000):
    """physical test: on one 5-5-5 face (v, b, c) built from v's 2-ball letters, the f terms of the three fives' own views sum to 0"""
    rng = np.random.default_rng(7); bad = 0; n_ = 0
    for _ in range(N):
        w = [int(x_) for x_ in rng.choice(LET, 5)]; k = int(rng.integers(5)); w[k] = w[(k + 1) % 5] = 5
        h = [int(x_) for x_ in rng.choice(LET, 5)]; r = [int(x_) for x_ in rng.integers(0, 2, 4)]
        W = lambda i: w[i % 5]; Hh = lambda i: h[i % 5]
        tot = collections.Counter(); ok = []
        ok.append(face_one(w, [c2(x_) for x_ in h], k, tot))                                        # v
        wb = [5, W(k - 1), Hh(k - 1), Hh(k), 5]; Hb = [c2(W(k - 2)), r[0], r[1], c2(Hh(k + 1)), c2(W(k + 2))]
        ok.append(face_one(wb, Hb, 4, tot))                                                           # b: face (c, v) at 4, 0
        wc = [5, 5, Hh(k), Hh(k + 1), W(k + 2)]; Hc = [c2(W(k - 1)), c2(Hh(k - 1)), r[2], r[3], c2(W(k - 2))]
        ok.append(face_one(wc, Hc, 0, tot))                                                           # c: face (v, b) at 0, 1
        if not all(ok): continue
        n_ += 1
        if any(tot.values()): bad += 1
    return n_, bad
H5 = 'hat5' in FLAGS                 # stage 18 (RELAY_SPEC 15): a big b sends r[K] to a five v of which it is a hat
RV = {}
HRR = 'hatrr' in FLAGS               # stage 23 (RELAY_SPEC 15r): reverse hat channel, the big hat b sends rr[K] >= 0 to the five v
assert not HRR or H5, 'hatrr needs hat5'
RRV = {}
C6LE = 'c6le' in FLAGS             # s83: cons2 as 'the 6 ends <= t' (cf - t <= 0, the receiver row at d = 6) instead of the equation cf = 0
CONSK = int(OPT.get('consk', '1')); CONSFRAC = float(OPT.get('consfrac', '0.25'))   # s86: c6le cons separation adds up to CONSK violated apex words per link (excess >= CONSFRAC x the link's worst), not only the argmax; rows logged as 'C <L> <s>'
CONSALL = 'consall' in FLAGS         # stage 24 (RELAY_SPEC 19.5): separate conservation over all 1,424 non-R6 6-words, not only five-containing ones
DD = 'big2' in FLAGS                 # stage 24 (RELAY_SPEC 19): D[K] >= 0, big -> big apex across a diamond (both directions)
DV = {}
DCAP = float(OPT.get('dcap', '3'))   # stage 24 re-run: 0 <= D <= dcap (default 3, like x); dpen = penalty like xpen
DPEN = [float(OPT.get('dpen', '0'))]
L3Q = 'l3q' in FLAGS                 # stage 28 (RELAY_SPEC_s21): l3q, a 7 u -> adjacent 7 v, q[(c, a, a2)] keyed on u's link out
LQV = {}; LQQ = {}                   # to distance 3; v credits Q[(c, a, mask)]. V = 7 subfamily: d = 7 rows only.
LQCAP = float(OPT.get('lqcap', '3')); L3T = {}; L3FILE = [None]
LQVS = tuple(sorted({int(x) for x in OPT.get('l3qV', '7').split(',')}))   # s45 (RELAY_SPEC_s45): payee letters; default 7 = s44
assert 7 in LQVS and set(LQVS) <= {7, 8, 9}, LQVS
LQVX = tuple(V for V in LQVS if V >= 8) if L3Q else ()                    # the new payee letters (empty by default)
L3TV = {}
def l3q_loadV(V):
    if V not in L3TV:
        T = {}
        for fn in OPT['l3qtab%d' % V].split(','):
            for k, v in json.load(open(fn)).items():
                sg, wd, ao = k.split(); T[(int(sg),) + tuple(int(ch) for ch in wd) + tuple(int(ch) for ch in ao)] = v[0]
        if 'l3qpartial' not in FLAGS: assert len(T) == 2 * 2500, (V, len(T))
        L3TV[V] = T; log('l3qV: V = %d table %d masks (%s)' % (V, len(T), 'partial' if len(T) != 5000 else 'full'))
    return L3TV[V]
if 9 in LQVX and CMD in ('solveR2', 'upperR2'):   # s47 (RELAY_SPEC_s47): V = 8 built, V = 9 still not
    log('l3qV=%s: separation / upper check for V = 9 not built (RELAY_SPEC_s47 47.6); refusing %s' % (OPT['l3qV'], CMD)); sys.exit(7)
def l3q_load():
    if L3Q and not L3T:
        for fn in OPT['l3qtab'].split(','):
            for k, v in json.load(open(fn)).items():
                sg, wd, ao = k.split(); L3T[(int(sg),) + tuple(int(ch) for ch in wd) + tuple(int(ch) for ch in ao)] = v[0]
        if PCL3:   # s36g PRIVCELL_SPEC 2.4: absorbed private-cell names clear a2 letters
            _n0 = sum(1 for k in L3T if L3T[k] & PCL3.get(k, 0))
            for k in L3T: L3T[k] &= ~PCL3.get(k, 0)
            log('pcell: l3q masks changed %d of %d' % (_n0, len(L3T)))
        assert len(L3T) == 2 * 2500, len(L3T)
def l3q_terms(d, w, s):
    """RELAY_SPEC_s21 21.3: payer -1 on lq (c, a, a2) and payee +1 on lQ (c, a', mask) at every link 7, both sides; d = 7 only"""
    cf = collections.Counter()
    if not L3Q or d != 7: return cf
    l3q_load(); n = 7
    for i in range(n):
        if w[i] != 7: continue
        for sg in (1, -1):
            c, a, a2 = w[(i + sg) % n], w[(i + 2 * sg) % n], w[(i + 3 * sg) % n]
            if c <= 6 and a <= 6: cf[('lq', (c, a, a2))] -= 1
            ap, o = (s[i], s[(i - 1) % n]) if sg == 1 else (s[(i - 1) % n], s[i])
            if c <= 6 and ap <= 6:
                m = L3T[(sg, c, a, a2, w[(i + 4 * sg) % n], ap, o)]
                cf[('lQ', (c, ap, m))] += 1
    if LQVX:   # s45: the d = 7 centre also pays its link 8s / 9s, key (V, c, a, a2)
        for i in range(n):
            if w[i] not in LQVX: continue
            for sg in (1, -1):
                c, a, a2 = w[(i + sg) % n], w[(i + 2 * sg) % n], w[(i + 3 * sg) % n]
                if c <= 6 and a <= 6: cf[('lq', (w[i], c, a, a2))] -= 1
    return cf
def l3q_terms_payeeV(d, w, s):
    """RELAY_SPEC_s45 45.2: a centre with V = min(d, 9) in l3qV, V >= 8, credits +1 lQ (V, c, a', mask) at every link 7, both sides"""
    cf = collections.Counter(); V = min(d, 9)
    if V not in LQVX: return cf
    T = l3q_loadV(V); n = d
    for i in range(n):
        if w[i] != 7: continue
        for sg in (1, -1):
            c, w2, w3, w4 = (w[(i + k * sg) % n] for k in (1, 2, 3, 4))
            ap, o = (s[i], s[(i - 1) % n]) if sg == 1 else (s[(i - 1) % n], s[i])
            if c <= 6 and ap <= 6: cf[('lQ', (V, c, ap, T[(sg, c, w2, w3, w4, ap, o)]))] += 1
    return cf
def l3q_mask_letters(m): return [l for k, l in enumerate(LET) if (m >> k) & 1]
def l3q_Qeff(c, a, m):
    """value of Q[(c, a, m)] in the extended solution: max(LP value, max q over the mask) (mrowL rows hold for every mask)"""
    return max([LQQ.get((c, a, m), 0.0)] + [LQV.get((c, a, a2), 0.0) for a2 in l3q_mask_letters(m)])
def l3q_UB(c, a):
    if c > 6 or a > 6: return 0.0
    l3q_load(); return max(l3q_Qeff(c, a, m) for k, m in L3T.items() if k[1] == c and k[5] == a)
def write_l3q():
    l3q_load()
    QX = np.zeros(31250); PQ = np.zeros(125); MK = -np.ones(31250)
    for k, m in L3T.items():
        sg, c, w2, w3, w4, a, o = k
        i = (((((0 if sg == 1 else 1) * 5 + LI[c]) * 5 + LI[w2]) * 5 + LI[w3]) * 5 + LI[w4]) * 25 + LI[a] * 5 + LI[o]
        QX[i] = l3q_Qeff(c, a, m) - l3q_UB(c, a); MK[i] = m
    for (c, a, a2), v in ((k_, v_) for k_, v_ in LQV.items() if len(k_) == 3): PQ[(LI[c] * 5 + LI[a]) * 5 + LI[a2]] = v   # s47: V = 7 keys only
    if QX.max() > 1e-15 or PQ.min() < -1e-15:   # s33z: LP noise (seen at A66 keeppen iter 10); clip |noise| <= 1e-9, else fail as before
        log('  write_l3q: noise QX.max %.3g PQ.min %.3g (clipped)' % (QX.max(), PQ.min()))
        assert QX.max() <= 1e-9 and PQ.min() >= -1e-9
        QX = np.minimum(QX, 0.0); PQ = np.maximum(PQ, 0.0)
    fn = os.path.join(WORK, 'l3q.bin')
    with open(fn, 'wb') as f: f.write(QX.astype(np.float64).tobytes()); f.write(PQ.astype(np.float64).tobytes()); f.write(MK.astype(np.float64).tobytes())
    L3FILE[0] = fn
    if 8 in LQVX: write_l3qV(8)   # s47
    return fn
L3VFILE = [None]; LQBROKEN = 'brokensignV' in FLAGS   # s47: brokensignV = control (c) only, the d = 7 payer term at a link 8 mis-signed
def l3q_QeffV(V, c, a, m):
    """RELAY_SPEC_s45 45.2 / s47 47.2: Q[(V, c, a, m)] in the extended solution = max(LP value, max q[(V, c, a, a2)] over a2 in m)"""
    return max([LQQ.get((V, c, a, m), 0.0)] + [LQV.get((V, c, a, a2), 0.0) for a2 in l3q_mask_letters(m)])
def l3q_UBV(V):
    """{(c, a): max over the V-table keys with that (c, a) of Qeff}; (c, a) outside {5, 6}^2 -> 0 (as l3q_UB)"""
    T = l3q_loadV(V); ub = {}
    for k, m in T.items():
        c, a = k[1], k[5]; ub[(c, a)] = max(ub.get((c, a), 0.0), l3q_QeffV(V, c, a, m))
    return ub
def write_l3qV(V):
    """s47 47.3: the V = 8 leaf file for jsep7, same layout as write_l3q: QX[2*5^6] (Qeff - UB, <= 0), PQ[125] (payer q, >= 0), MK[2*5^6]"""
    T = l3q_loadV(V); ub = l3q_UBV(V)
    QX = np.zeros(31250); PQ = np.zeros(125); MK = -np.ones(31250)
    for k, m in T.items():
        sg, c, w2, w3, w4, a, o = k
        i = (((((0 if sg == 1 else 1) * 5 + LI[c]) * 5 + LI[w2]) * 5 + LI[w3]) * 5 + LI[w4]) * 25 + LI[a] * 5 + LI[o]
        QX[i] = l3q_QeffV(V, c, a, m) - ub.get((c, a), 0.0); MK[i] = m
    for k_, v in LQV.items():
        if len(k_) == 4 and k_[0] == V and not LQBROKEN: PQ[(LI[k_[1]] * 5 + LI[k_[2]]) * 5 + LI[k_[3]]] = v
    if QX.max() > 1e-15 or PQ.min() < -1e-15:
        log('  write_l3qV: noise QX.max %.3g PQ.min %.3g (clipped)' % (QX.max(), PQ.min()))
        assert QX.max() <= 1e-9 and PQ.min() >= -1e-9
        QX = np.minimum(QX, 0.0); PQ = np.maximum(PQ, 0.0)
    fn = os.path.join(WORK, 'l3q%d.bin' % V)
    with open(fn, 'wb') as f: f.write(QX.astype(np.float64).tobytes()); f.write(PQ.astype(np.float64).tobytes()); f.write(MK.astype(np.float64).tobytes())
    L3VFILE[0] = fn; return fn
def l3q_winV(W, U):
    """s47 47.3: U = 8 window at a link 7 (c = index 2): + UB8 of the payee credit on both sides, read as l3q_win
    (+ side c = e, a = r ; - side c = b, a = q); jsep7's leaf corrects it exactly.  The d = 7 payer term at a link 8 is <= 0
    and is applied in the leaf only (as V = 7).  brokensignV (control): U = 7 window at a link 8 (c = index 3) gets
    + max_a2 q[(8, c, a, a2)] per side (c = e, a = f ; c = b, a = a), the payer term with the wrong sign, and the leaf drops it."""
    if 8 not in LQVX: return
    if U == 8:
        ub = l3q_UBV(8)
        for b, e, q, r in itertools.product(range(5), repeat=4):
            W[:, b, 2, e, :, :, q, r, :] += ub.get((LET[e], LET[r]), 0.0) + ub.get((LET[b], LET[q]), 0.0)
    if U == 7 and LQBROKEN:
        mx = collections.defaultdict(float)
        for k_, v in LQV.items():
            if len(k_) == 4 and k_[0] == 8: mx[(k_[1], k_[2])] = max(mx[(k_[1], k_[2])], v)
        for a, b, e, f in itertools.product(range(5), repeat=4):
            W[a, b, 3, e, f, :, :, :, :] += mx.get((LET[e], LET[f]), 0.0) + mx.get((LET[b], LET[a]), 0.0)
def l3q_win(W, U):
    """window term at a link 7 (c = index 2): UB of the payee credit on both sides, sides read in the window:
    + side c = w_{i+1} = e, a = s_i = r ; - side c = w_{i-1} = b, a = s_{i-1} = q.  The leaf corrects it exactly (jsep5)."""
    if not L3Q or U != 7: return
    for b, e, q, r in itertools.product(range(5), repeat=4):
        W[:, b, 2, e, :, :, q, r, :] += l3q_UB(LET[e], LET[r]) + l3q_UB(LET[b], LET[q])
def d_canon2(a, b): return min(a + b, b + a)
def d_side(z, link_nb, apex_nb, out):
    """RELAY_SPEC 19.2/19.3 side of a shared spoke z read at a receiver centre T: link_nb = z's other T-adjacent link nbr,
    apex_nb = the apex across (link_nb, z); out = T is the paying tip"""
    if z == 5: return ((5, link_nb, apex_nb),) if out else ((5, apex_nb, link_nb),)
    if z == 6: return ((6, apex_nb),)
    return ((z,),)
def d_keys(U, wm1, wi, wi1, wi2, sm1, si, sp1):
    """(out key U -> s_i, in key s_i -> U) at a position with s_i big"""
    ko = (U, si, d_canon2(d_side(wi, wm1, sm1, True), d_side(wi1, wi2, sp1, True)))
    ki = (si, U, d_canon2(d_side(wi, wm1, sm1, False), d_side(wi1, wi2, sp1, False)))
    return ko, ki
def hat_sender_terms(w, H, Fn, k):
    """coefficients the five v's senderR2 row gets from its big hat H[k]: r (v -> b) +1; rr (b -> v) -1"""
    K = h5_sender(w, H, Fn, k); out = {('r', K): 1}
    if HRR: out[('rr', K)] = -1
    return out
def hat_recv_terms(K, broken_sign=False):
    """coefficients the big b's receiverR2 row (load = inflow) gets at a hat position: r +1; rr -1 (b pays out)"""
    out = {('r', K): 1}
    if HRR: out[('rr', K)] = 1 if broken_sign else -1
    return out
def h5side_v(x, X1, X2):
    """one shared spoke x of the diamond (v, x, b, y), read from the five v: X1 = x's nbr adjacent to b (class),
    X2 = x=5: x's nbr adjacent to v (exact letter); x=6: x's nbr opposite y (class)"""
    if x == 5: return (5, X1, X2)
    if x == 6: return (6, X1, X2)
    return (x,)
def h5key(sa, sb): return min(sa + sb, sb + sa)
def h5_sender(w, H, Fn, k):
    """inflow key at five v (word w) from the big hat H[k] between w_k and w_{k+1}; H, Fn = class bits"""
    n = 5; x, y = w[k], w[(k + 1) % n]
    sx = (5, H[(k - 1) % n], w[(k - 1) % n]) if x == 5 else (6, Fn[k], H[(k - 1) % n]) if x == 6 else (x,)
    sy = (5, H[(k + 1) % n], w[(k + 2) % n]) if y == 5 else (6, Fn[(k + 1) % n], H[(k + 1) % n]) if y == 6 else (y,)
    return h5key(sx, sy)
def h5_recv(wm1, wi, wi1, wi2, sm1, sp1):
    """outflow key at a big centre whose apex s_i = 5 sits between w_i and w_{i+1}; wm1 = w_{i-1}, wi2 = w_{i+2},
    sm1 = s_{i-1}, sp1 = s_{i+1} (exact letters)"""
    sx = (5, c2(wm1), sm1) if wi == 5 else (6, c2(wm1), c2(sm1)) if wi == 6 else (wi,)
    sy = (5, c2(wi2), sp1) if wi1 == 5 else (6, c2(wi2), c2(sp1)) if wi1 == 6 else (wi1,)
    return h5key(sx, sy)
def hat5_selftest(N=100000, broken=False):
    """physical test on random local triangulations around a diamond (v five; x, y consecutive spokes of v; b the other
    apex of edge xy, big).  Each vertex gets a random letter; x and y get explicit rotations (cyclic neighbour lists),
    and every hat / apex / fan is read off them by the generic rule apex(c; p, q) = the common neighbour of p and q
    other than c.  The sender reads v's 2-ball, the receiver reads b's 2-ball; both keys must agree, in both
    orientations of b's link.  broken = the receiver reads s_{i-1} from the wrong side (control)."""
    rng = np.random.default_rng(18); bad = 0
    for _ in range(N):
        deg = {}; rot = {}
        L = lambda: int(rng.choice(LET))
        dx, dy = int(rng.choice((5, 6, 7))), int(rng.choice((5, 6, 7)))
        names = ['v', 'x', 'y', 'b', 'w2', 'w3', 'wm1']
        # x's rotation starting at v towards y: v, y, b, then its free nbrs, ending at wm1 (v's other link nbr of x)
        rot['x'] = ['v', 'y', 'b'] + ['x%d' % i for i in range(dx - 4)] + ['wm1']
        rot['y'] = ['v', 'x', 'b'] + ['y%d' % i for i in range(dy - 4)] + ['w2']
        rot['v'] = ['x', 'y', 'w2', 'w3', 'wm1']
        for nm in names + rot['x'] + rot['y']: deg.setdefault(nm, L())
        deg['v'] = 5; deg['x'] = dx; deg['y'] = dy; deg['b'] = int(rng.choice(BIGL))
        def nb_after(c, p, other):   # in c's rotation, the neighbour of p that is not `other`
            r = rot[c]; i = r.index(p); a1, a2 = r[(i - 1) % len(r)], r[(i + 1) % len(r)]
            return a2 if a1 == other else a1
        # v's view: link (x, y, w2, w3, wm1); hats H[k] between link k, k+1
        hk_m1 = nb_after('x', 'wm1', 'v')      # common nbr of wm1 and x other than v
        hk_p1 = nb_after('y', 'w2', 'v')
        wv = [deg['x'], deg['y'], deg['w2'], deg['w3'], deg['wm1']]
        H = {4: c2(deg[hk_m1]), 0: c2(deg['b']), 1: c2(deg[hk_p1]), 2: 0, 3: 0}
        fan = lambda c: rot[c][len(rot[c]) // 2] if len(rot[c]) == 6 else None   # a 6's private = opposite v
        Fn = {0: c2(deg[fan('x')]) if dx == 6 else 0, 1: c2(deg[fan('y')]) if dy == 6 else 0}
        ks = h5_sender(wv, H, Fn, 0)
        # b's view: b's link contains X1, x, y, Y1 consecutively (X1 = x's nbr after b, Y1 = y's nbr after b)
        X1 = nb_after('x', 'b', 'y'); Y1 = nb_after('y', 'b', 'x')
        sm1 = nb_after('x', X1, 'b') if not broken else nb_after('x', 'v', 'y')   # apex of (X1, x) other than b
        sp1 = nb_after('y', Y1, 'b')
        assert nb_after('x', 'y', 'b') == 'v'                                       # apex of (x, y) other than b is v
        kr = h5_recv(deg[X1], dx, dy, deg[Y1], deg[sm1], deg[sp1])
        kr2 = h5_recv(deg[Y1], dy, dx, deg[X1], deg[sp1], deg[sm1])
        if not (ks == kr == kr2): bad += 1; continue
        if HRR:   # stage 23: the rr terms the two rows actually get must conserve charge and point b -> v
            ts = hat_sender_terms(wv, H, Fn, 0); tr = hat_recv_terms(kr, 'brokensign' in FLAGS)
            # v's charge changes by -cs * value (cs = coefficient in v's 'sends' row); b's by +cr * value (load = inflow)
            for fam_ in ('r', 'rr'):
                cs = ts.get((fam_, ks)); cr = tr.get((fam_, kr))
                if cs is None or cr is None or cs != cr: bad += 1; break
            else:
                if ts[('rr', ks)] != -1 or ts[('r', ks)] != 1: bad += 1   # rr: v gains (b -> v); r: v loses (v -> b)
    return N, bad
HX = 'hatx' in FLAGS
assert not HX or 'hat5' in FLAGS, 'hatx needs hat5 (all hats enumerated)'
HX = HX                 # stage 20 (RELAY_SPEC 16): exact hat letters in sender admissibility (joint over shared hats)
_r6c = {}
def isR6c(w):
    if w not in _r6c: _r6c[w] = isR6(w)
    return _r6c[w]
def hx_ok(w, H, Fn):
    """some exact letter per hat (in its class) makes every 6-spoke wheel non-R6 (fan letter in its class) and every
    five-spoke link non-R5, with each hat's single letter shared by the two spokes it touches"""
    n = 5; sixes = [k for k in range(n) if w[k] == 6]; fives = [k for k in range(n) if w[k] == 5]
    for h in itertools.product(*[CLS2[H[k]] for k in range(n)]):
        if any(isR5((5, w[(k - 1) % n], h[(k - 1) % n], h[k], w[(k + 1) % n])) for k in fives): continue
        if all(any(not isR6c((5, w[(k + 1) % n], h[k], q, h[(k - 1) % n], w[(k - 1) % n])) for q in CLS2[Fn[k]]) for k in sixes): return True
    return False
def hatx_selftest(N=100000, broken=False):
    """physical test around a five v: random letters on v's link w, its hats h (h_k = common nbr of w_k, w_{k+1} other than v)
    and the 6-spokes' privates; each spoke gets an explicit rotation list and its OWN wheel is read from that list.
    Checks: (a) a five-spoke's own link = the sender's reading (5, w_{k-1}, h_{k-1}, h_k, w_{k+1}) (canonical);
    (b) a 6-spoke's own wheel = the sender's reading (5, w_{k+1}, h_k, F_k, h_{k-1}, w_{k-1}) (canonical);
    (c) the g2 key the 6-spoke computes from its own arrangement (link from v, apexes from v's rotation) = the sender's g2.
    broken = the sender reads the five-spoke link with h_{k+1} in place of h_{k-1} (control)."""
    rng = np.random.default_rng(20); bad = 0; n_ = 0
    for _ in range(N):
        L = lambda: int(rng.choice(LET))
        w = [L() for _ in range(5)]; h = [L() for _ in range(5)]; f = [L() for _ in range(5)]
        vrot = list(range(5))                     # v's rotation: spokes 0..4
        for k in range(5):
            if w[k] not in (5, 6): continue
            # spoke k's rotation, starting at v towards w_{k+1}: v, w_{k+1}, h_k, [f_k if 6], h_{k-1}, w_{k-1}
            rot = [('v', 5), ('w', w[(k + 1) % 5]), ('h', h[k])] + ([('f', f[k])] if w[k] == 6 else []) + [('h', h[(k - 1) % 5]), ('w', w[(k - 1) % 5])]
            own = tuple(x[1] for x in rot)
            n_ += 1
            if w[k] == 5:
                rd = (5, w[(k - 1) % 5], h[(k + 1) % 5] if broken else h[(k - 1) % 5], h[k], w[(k + 1) % 5])
                if canon(own) != canon(rd): bad += 1
            else:
                rd = (5, w[(k + 1) % 5], h[k], f[k], h[(k - 1) % 5], w[(k - 1) % 5])
                if canon(own) != canon(rd): bad += 1
                # g2 from the 6's arrangement: L = own (L_i = v first); apex beyond (v, w_{k+1}) = v's next spoke w_{k+2};
                # apex beyond (w_{k-1}, v) = w_{k-2}
                k6 = g2_of(own[1], own[2], own[3], own[4], own[5], w[(vrot[(k + 2) % 5])], w[vrot[(k - 2) % 5]])
                L5 = lambda c: 7 if c else 5
                ks = g2_of(w[(k + 1) % 5], L5(c2(h[k])), L5(c2(f[k])), L5(c2(h[(k - 1) % 5])), w[(k - 1) % 5], w[(k + 2) % 5], w[(k - 2) % 5])
                if k6 != ks: bad += 1
    return n_, bad
WF19 = set()
if 'wf19' in FLAGS:   # stage 19b oracle: forbidden sender contexts (word, bits), FINDINGS stage 19b
    for line in open(OPT['wf']):
        if line.strip() and not line.startswith('#'):
            wd_, bt = line.split(); h_, f_ = bt.split('|')
            WF19.add((wd_, tuple(int(c) for c in h_.split(',')) + ('|',) + tuple(int(c) for c in f_.split(',') if c != '')))
def R2_sender_rows():
    out = []; nwf = [0]; nhx = [0]
    for w in SENDERS:
        n = 5; sixes = [k for k in range(n) if w[k] == 6]
        allow = {k: {(a_, q, b_) for a_ in LET for q in LET for b_ in LET if not isR6((5, w[(k + 1) % n], a_, q, b_, w[(k - 1) % n]))} for k in sixes}
        bigs = [j for j in range(n) if w[j] >= 7] if ZH else []
        faces = [k for k in range(n) if F5 and w[k] == 5 and w[(k + 1) % n] == 5]
        hats = sorted({h for k in sixes + bigs for h in (k, (k - 1) % n)} | {h for k in faces for h in ((k - 1) % n, k, (k + 1) % n)} | (set(range(n)) if H5 else set())); seen = set()
        base = collections.Counter()
        for j in range(n):
            if w[j] >= 7: base[('y', root(list(w), j))] += 1
        for hb in itertools.product((0, 1), repeat=len(hats)):
            H = dict(zip(hats, hb))
            for fb in itertools.product((0, 1), repeat=len(sixes)):
                Fn = dict(zip(sixes, fb)); okc = True
                for k in sixes:
                    if not any((a_, q, b_) in allow[k] for a_ in CLS2[H[k]] for q in CLS2[Fn[k]] for b_ in CLS2[H[(k - 1) % n]]): okc = False; break
                if not okc: continue
                if HX and not hx_ok(w, H, Fn): nhx[0] += 1; continue
                if WF19 and (''.join(map(str, w)), tuple(hb) + ('|',) + tuple(fb)) in WF19: nwf[0] += 1; continue
                cf = collections.Counter(base)
                if H5:
                    for k in range(n):
                        if H[k]:
                            for k2, c2v in hat_sender_terms(w, H, Fn, k).items(): cf[k2] += c2v
                if faces:
                    ft = face_terms(w, H)
                    if ft is None: continue
                    for k_, c_ in ft.items():
                        if c_: cf[k_] += c_
                for j in bigs:
                    zk_ = fy_sender_key(w, H, j) if FY else zkey(tuple(w[(j + i) % n] for i in range(5)), H[j], H[(j - 1) % n]); cf[('z', zk_)] += 1
                    if ZR: cf[('zr', zk_)] -= 1   # s22.1: the five gains
                for k in sixes:   # classes H, Fn are already 0/1 = c2 values; pass letters 5 / 7 as class witnesses
                    L5 = lambda c: 7 if c else 5
                    cf[('g', g2_of(w[(k + 1) % n], L5(H[k]), L5(Fn[k]), L5(H[(k - 1) % n]), w[(k - 1) % n], w[(k + 2) % n], w[(k - 2) % n]))] += 1
                if GKON: cf.update(gk_sender_terms(w, H, Fn)); cf = collections.Counter({k2_: v2_ for k2_, v2_ in cf.items() if v2_})   # s85: generic keys, before the de-duplication
                k_ = tuple(sorted(cf.items()))
                if k_ not in seen: seen.add(k_); out.append((''.join(map(str, w)), dict(cf), list(hb) + ['|'] + list(fb)))
    if WF19: log('wf19: %d of %d forbidden sender contexts skipped' % (nwf[0], len(WF19)))
    if HX: log('hatx: %d sender contexts have no jointly admissible exact hat letters (dropped)' % nhx[0])
    return out
L6R = 'l6r' in FLAGS                 # stage 33 (RELAY_SPEC_s23, s34b): z6[K] in [0, z6cap], a 6 x -> adjacent 6 y (payer L has a five);
Z6V = {}; Z6W = {}; Z6CAP = float(OPT.get('z6cap', '3'))   # payee credit Z6[sigma] >= 0 uncapped; mrowZ: z6[K] - Z6[sigma(K)] <= 0
def z6_refl7(a): return (a[4], a[3], a[2], a[1], a[0], a[6], a[5])
def z6_refl6(g): return (g[3], g[2], g[1], g[0], g[5], g[4])
def zkey6_ab(L, j, sj, sjm):
    a = (L[(j + 1) % 6], ap(L[(j + 2) % 6]), L[(j + 3) % 6], ap(L[(j + 4) % 6]), L[(j + 5) % 6], ap(sj), ap(sjm)); return min(a, z6_refl7(a))
def zsig6_of_key(K):
    g = (K[0], K[1], K[3], K[4], K[5], K[6]); return min(g, z6_refl6(g))
def zsig6_ab(L, k, sk, skm):
    g = (L[(k + 1) % 6], ap(sk), ap(skm), L[(k - 1) % 6], ap(L[(k + 2) % 6]), ap(L[(k - 2) % 6])); return min(g, z6_refl6(g))
_Z6F = []
def z6_first():
    """first-family z6 keys: canonical non-R6 6-words with a five, positions with L_j = 6, apex classes (s_j, s_{j-1}) in {5,7}^2"""
    if not _Z6F:
        ks = set()
        for L in all6_words():
            if 5 not in L: continue
            for j in range(6):
                if L[j] == 6:
                    for a_, b_ in itertools.product((5, 7), repeat=2): ks.add(zkey6_ab(L, j, a_, b_))
        _Z6F.append(sorted(ks))
    return _Z6F[0]
FB = 'fb' in FLAGS                   # s44 (RELAY_SPEC_s44): face big u -> its k-vertex X (6: via cons2; big: via receiver), exact key
FBDIR = OPT.get('fbdir', '67'); FBV = {}; FBCAP = float(OPT['fbcap']) if 'fbcap' in OPT else None
def fb_face(T): return T[0] == 5 and T[2] == 5 and T[3] == 5
def fb_key(U, X, Tp, Tm):
    """44.2: sigma = (U, X, min(T+, T-), max(T+, T-)); None unless a face side, X >= 6 and the direction is on"""
    if X < 6 or not (fb_face(Tp) or fb_face(Tm)): return None
    if ('6' if X == 6 else '7') not in FBDIR: return None
    a, b = min(Tp, Tm), max(Tp, Tm); return (U, X) + a + b
def fb_payer_keys(d, w, s):   # centre pays its link vertex X = w_j: T+ = (w_{j+1}, s_j, w_{j+2}, e+), T- mirrored
    out = []; U = min(d, 9)
    if not FB: return out
    for j in range(d):
        if w[j] < 6: continue
        e1, e2 = w[(j + 1) % d], w[(j - 1) % d]
        Tp = (e1, s[j], w[(j + 2) % d], s[(j + 1) % d] if e1 == 5 else 0); Tm = (e2, s[(j - 1) % d], w[(j - 2) % d], s[(j - 2) % d] if e2 == 5 else 0)
        k = fb_key(U, w[j], Tp, Tm)
        if k: out.append((j, k))
    return out
def fb_payee_keys(n, L, t, X):   # centre X (letter X) receives from its link vertex u = L_k >= 7: T+ = (L_{k+1}, L_{k+2}, t_k, e+)
    out = []
    if not FB or X < 6: return out
    for k in range(n):
        kk = fb_payee_at(n, L, t, X, k)
        if kk: out.append((k, kk))
    return out
def fb_payee_at(n, L, t, X, k):
    if not FB or X < 6 or L[k] < 7: return None
    e1, e2 = L[(k + 1) % n], L[(k - 1) % n]
    Tp = (e1, L[(k + 2) % n], t[k], t[(k + 1) % n] if e1 == 5 else 0); Tm = (e2, L[(k - 2) % n], t[(k - 1) % n], t[(k - 2) % n] if e2 == 5 else 0)
    return fb_key(L[k], X, Tp, Tm)
def fb_win(W, U):
    """44.3 window terms: payer at c >= 6 (slots T+ = (e, r, f, s*), T- = (b, q, a, p*)); payee if U >= 7 at c >= 7 (T+ = (e, f, r, s*), T- = (b, a, q, p*))"""
    if not FB or not any(v for v in FBV.values()): return
    seen = set()
    for side in (0, 1):
        for t6 in itertools.product(range(5), repeat=6):
            for c in range(1, 5):
                for role in ('pay', 'get'):
                    if role == 'get' and (U < 7 or c < 2): continue
                    # place a face on the chosen side for this role, the 6 free slots fill the rest
                    if role == 'pay':   # + face: e = f = s = 0 ; - face: b = a = p = 0
                        if side == 0: e, f, s_ = 0, 0, 0; a, b, p, q, r, _x = t6
                        else: b, a, p = 0, 0, 0; e, f, s_, q, r, _x = t6
                    else:                # + face: e = r = s = 0 ; - face: b = q = p = 0
                        if side == 0: e, r, s_ = 0, 0, 0; a, b, p, q, f, _x = t6
                        else: b, q, p = 0, 0, 0; e, r, s_, a, f, _x = t6
                    if _x: continue
                    ix = (role, a, b, c, e, f, p, q, r, s_)
                    if ix in seen: continue
                    seen.add(ix)
                    A_, B_, C_, E_, F_, P_, Q_, R_, S_ = (LET[v] for v in (a, b, c, e, f, p, q, r, s_))
                    if role == 'pay': k = fb_key(U, C_, (E_, R_, F_, S_ if E_ == 5 else 0), (B_, Q_, A_, P_ if B_ == 5 else 0)); sg = -1
                    else: k = fb_key(C_, U, (E_, F_, R_, S_ if E_ == 5 else 0), (B_, A_, Q_, P_ if B_ == 5 else 0)); sg = 1
                    if k and FBV.get(k): W[a, b, c, e, f, p, q, r, s_] += sg * FBV[k]
def z6_terms(L, s):
    cf = collections.Counter()
    if not L6R: return cf
    for j in range(6):
        if L[j] == 6:
            if 5 in L: cf[('z6', zkey6_ab(L, j, s[j], s[(j - 1) % 6]))] -= 1     # x pays out
            cf[('Z6', zsig6_ab(L, j, s[j], s[(j - 1) % 6]))] += 1                  # x is the payee of its 6-neighbour L_j
    return cf
def cons2_coef(L, s):
    cf = collections.Counter()
    for i in range(6):
        if L[i] == 5: cf[('g', g2_of(L[(i + 1) % 6], L[(i + 2) % 6], L[(i + 3) % 6], L[(i + 4) % 6], L[(i + 5) % 6], s[i], s[(i - 1) % 6]))] += 1
    for j in range(6):
        if L[j] >= 7: cf[('h', h2_of(tuple(L[(j + i) % 6] for i in range(6)), s[j], s[(j - 1) % 6]))] -= 1
        if V6 and L[j] == 7: cf[('v', v_of(tuple(L[(j + i) % 6] for i in range(6)), s[j], s[(j - 1) % 6]))] += 1
    if L6R: cf.update(z6_terms(L, s))
    for _, k in fb_payee_keys(6, L, s, 6): cf[('fb', k)] += 1   # s44: the 6 is an fb payee (inflow)
    return cf
SALL = np.array(list(itertools.product(range(5), repeat=6)), dtype=np.int64)   # apex words (letter indices)
def cons2_delta(L, GV, HV2):
    """Delta(s) = sum g - sum h over all 5^6 apex words for link L (vectorised); returns array"""
    D = np.zeros(len(SALL))
    for i in range(6):
        if L[i] == 5:
            T = np.array([[GV.get(g2_of(L[(i + 1) % 6], L[(i + 2) % 6], L[(i + 3) % 6], L[(i + 4) % 6], L[(i + 5) % 6], LET[a], LET[b]), 0.0) for b in range(5)] for a in range(5)])
            D += T[SALL[:, i], SALL[:, (i - 1) % 6]]
    for j in range(6):
        if L[j] >= 7:
            m = tuple(L[(j + i) % 6] for i in range(6))
            T = np.array([[HV2.get(h2_of(m, LET[a], LET[b]), 0.0) for b in range(5)] for a in range(5)])
            D -= T[SALL[:, j], SALL[:, (j - 1) % 6]]
        if V6 and L[j] == 7:
            m = tuple(L[(j + i) % 6] for i in range(6))
            T = np.array([[VV.get(v_of(m, LET[a], LET[b]), 0.0) for b in range(5)] for a in range(5)])
            D += T[SALL[:, j], SALL[:, (j - 1) % 6]]
        if FB and L[j] >= 7 and any(FBV.values()):   # s44: fb inflow at the 6 from u = L_j
            T4 = np.zeros((5, 5, 5, 5))
            for a4, b4, c4, e4 in itertools.product(range(5), repeat=4):
                kk = fb_payee_at(6, L, {j: LET[a4], (j - 1) % 6: LET[b4], (j + 1) % 6: LET[c4], (j - 2) % 6: LET[e4]}, 6, j)
                if kk: T4[a4, b4, c4, e4] = FBV.get(kk, 0.0)
            D += T4[SALL[:, j], SALL[:, (j - 1) % 6], SALL[:, (j + 1) % 6], SALL[:, (j - 2) % 6]]
        if L6R and L[j] == 6:   # RELAY_SPEC_s23.4
            if 5 in L:
                T = np.array([[Z6V.get(zkey6_ab(L, j, LET[a], LET[b]), 0.0) for b in range(5)] for a in range(5)])
                D -= T[SALL[:, j], SALL[:, (j - 1) % 6]]
            T = np.array([[Z6W.get(zsig6_ab(L, j, LET[a], LET[b]), 0.0) for b in range(5)] for a in range(5)])
            D += T[SALL[:, j], SALL[:, (j - 1) % 6]]
    return D
def window_table_R2(U, y, x, MV2):
    W = window_table(U, y, x)
    if FY:
        ZT = np.full(2 * 5 ** 9, -1e300) if FY2 else None
        for a, b, e, f, p_, q, r, s_ in itertools.product(range(5), repeat=8):
            wd = (U, LET[e], LET[r], LET[q], LET[b])
            if isR5(list(wd)): continue
            if FY2 and fy_vis(wd)[2]:   # s43: UB over the face's allowed classes here; exact coupling in jsep6's leaf (ZT)
                A_ = fy2_allowed(LET[s_], LET[q]) if (e == 0 and r == 0) else fy2_allowed(LET[r], LET[p_])
                zz = [ZV.get(fy_recv_key(U, LET[a], LET[b], LET[e], LET[f], LET[p_], LET[q], LET[r], LET[s_], tc), 0.0) if tc in A_ else None for tc in (0, 1)]
                ix = (((((((a * 5 + b) * 5 + 0) * 5 + e) * 5 + f) * 5 + p_) * 5 + q) * 5 + r) * 5 + s_
                for tc in (0, 1):
                    if zz[tc] is not None: ZT[2 * ix + tc] = zz[tc]
                W[a, b, 0, e, f, p_, q, r, s_] += max(v_ for v_ in zz if v_ is not None); continue
            W[a, b, 0, e, f, p_, q, r, s_] += ZV.get(fy_recv_key(U, LET[a], LET[b], LET[e], LET[f], LET[p_], LET[q], LET[r], LET[s_]), 0.0)
        if FY2:
            ZTF[U] = os.path.join(WORK, 'fy2zt_U%d.bin' % U); ZT.astype(np.float64).tofile(ZTF[U])
    elif ZH:
        for a, b, e, f, q, r in itertools.product(range(5), repeat=6):
            wd = (U, LET[e], LET[r], LET[q], LET[b])
            if isR5(list(wd)): continue
            zk_ = zkey(wd, c2(LET[f]), c2(LET[a]))
            W[a, b, 0, e, f, :, q, r, :] += ZV.get(zk_, 0.0) - ZRV.get(zk_, 0.0)
    if V6 and U == 7:
        for a, b, e, f, q, r in itertools.product(range(5), repeat=6):
            sv0 = sigv_of(U, LET[e], LET[r], LET[q], LET[b], LET[f], LET[a])
            if not F16:
                ks = sigv_keys(sv0)
                if ks: W[a, b, 1, e, f, :, q, r, :] -= min(VV.get(k, 0.0) for k in ks)
                continue
            for p_, s_ in itertools.product(range(5), repeat=2):
                ks = sigv_keys(sv0 + (amask(U, LET[a], LET[b], LET[e], LET[f], LET[p_], LET[q], LET[r], LET[s_]),))
                if ks: W[a, b, 1, e, f, p_, q, r, s_] -= min(VV.get(k, 0.0) for k in ks)
    if Q7:
        for b, e, q, r in itertools.product(range(5), repeat=4):
            sg = q7sig(U, LET[e], LET[r], LET[q], LET[b]); ks = q7keys(sg)
            if ks: W[:, b, 2, e, :, :, q, r, :] += max(QV.get(k, 0.0) for k in ks)
    if H5:
        for b, c, e, f, q, s_ in itertools.product(range(5), repeat=6):
            K_ = h5_recv(LET[b], LET[c], LET[e], LET[f], LET[q], LET[s_])
            W[:, b, c, e, f, :, q, 0, s_] += RV.get(K_, 0.0) - RRV.get(K_, 0.0)
    if DD:
        for b, c, e, f, q, r, s_ in itertools.product(range(5), range(5), range(5), range(5), range(5), (2, 3, 4), range(5)):
            ko, ki = d_keys(U, LET[b], LET[c], LET[e], LET[f], LET[q], LET[r], LET[s_])
            v = DV.get(ki, 0.0) - DV.get(ko, 0.0)
            if v: W[:, b, c, e, f, :, q, r, s_] += v
    for a, b, e, f, q, r in itertools.product(range(5), repeat=6):
        if not AP and (a or f): continue
        sg = sig2_of(U, LET[e], LET[r], LET[q], LET[b], LET[f], LET[a])
        if F16:
            for p_, s_ in itertools.product(range(5), repeat=2):
                v = MV2(sg + (amask(U, LET[a], LET[b], LET[e], LET[f], LET[p_], LET[q], LET[r], LET[s_]),))
                if v is not None: W[a, b, 1, e, f, p_, q, r, s_] += v
            continue
        v = MV2(sg)
        if v is None: continue
        if AP: W[a, b, 1, e, f, :, q, r, :] += v
        else: W[:, b, 1, e, :, :, q, r, :] += v
    l3q_win(W, U)
    l3q_winV(W, U)   # s47
    fb_win(W, U)
    xo_win(W, U)   # s51
    return W
def class_table_R2(xon):
    g = np.indices((5,) * 9, dtype=np.int64)
    a, b, c, e, f, p, q, r, s_ = g
    C = np.where(c == 0, 1 + ((b * 5 + e) * 5 + q) * 5 + r, 0)
    if FY:   # s25c: the five's class = y root slots (b, e, q, r) + c2(a), c2(f), c2(p) if b = 5, c2(s) if e = 5
        bits = (a >= 2) * 8 + (f >= 2) * 4 + ((b == 0) & (p >= 2)) * 2 + ((e == 0) & (s_ >= 2))
        C = np.where(c == 0, 470000 + ((b * 5 + e) * 5 + q) * 5 * 16 + r * 16 + bits, C)
    elif ZH: C = np.where(c == 0, (1 + 470000 if H5 else 1 + 100000000) + (((((a * 5 + b) * 5 + e) * 5 + f) * 5 + q) * 5 + r), C)   # s33: below the hat5 500000 stride
    C = np.where(c == 1, 1 + 625 + (((((a * 5 + b) * 5 + e) * 5 + f) * 5 + q) * 5 + r), C)
    if F16: C = np.where(c == 1, 1 + 625 + (((((((a * 5 + b) * 5 + e) * 5 + f) * 5 + q) * 5 + r) * 5 + p) * 5 + s_), C)
    o16 = 390625 - 15625 if F16 else 0
    if xon: C = np.where(c >= 2, 1 + 625 + 15625 + o16 + c * 15625 + (((((a * 5 + b) * 5 + e) * 5 + f) * 5 + q) * 5 + r), C)
    if XO: C = np.where(c >= 2, 1 + 625 + 390625 + (c - 2) * 390625 + (((((((a * 5 + b) * 5 + e) * 5 + f) * 5 + p) * 5 + q) * 5 + r) * 5 + s_), C)   # s51 51.7
    HS = 2000000 if XO else 500000   # s51: fold stride above the xo classes
    if H5:   # the hat-channel outflow at a position with s_i = 5 depends on (b, c, e, f, q, s): fold its key id into the class
        assert int(C.max()) < HS
        ids = {}; T = np.zeros((5,) * 6, dtype=np.int64)
        for b_, c_, e_, f_, q_, s2 in itertools.product(range(5), repeat=6):
            T[b_, c_, e_, f_, q_, s2] = ids.setdefault(h5_recv(LET[b_], LET[c_], LET[e_], LET[f_], LET[q_], LET[s2]), len(ids)) + 1
        C = np.where(r == 0, C + HS * T[b, c, e, f, q, s_], C)
        assert int(C.max()) < 2 ** 31 - 1
    if DD:   # D term at a position with s_i big depends on (b, c, e, f, q, r, s): fold a U-independent id into the class
        ids = {}; T7 = np.zeros((5,) * 7, dtype=np.int64)
        for b_, c_, e_, f_, q_, r_, s2 in itertools.product(range(5), repeat=7):
            if r_ < 2: continue
            ko, ki = d_keys(0, LET[b_], LET[c_], LET[e_], LET[f_], LET[q_], LET[r_], LET[s2])
            T7[b_, c_, e_, f_, q_, r_, s2] = ids.setdefault((ko, ki), len(ids)) + 1
        C = np.where(r >= 2, C + HS * T7[b, c, e, f, q, r, s_], C)
        assert int(C.max()) < 2 ** 31 - 1, 'class overflow'
    return C.astype(np.int32)
def recv_coef_R2(d, lk, sv, xon, tau=None):
    cy, cx = recv_coef(d, lk, sv, xon and not XO); cf = collections.Counter()   # s51: no old x under xo
    if FY2 and tau is None: tau = fy2_cells(d, [int(ch) for ch in lk], [int(ch) for ch in sv])[0][1]   # s43: reporting callers get the first cell
    for r_, c in cy.items(): cf[('y', r_)] += c
    for r_, c in cx.items():
        if c: cf[('x', r_)] += c
    U = min(d, 9); w = [int(ch) for ch in lk]; s = [int(ch) for ch in sv]
    for j in range(d):
        if w[j] == 6:
            sg = sig2_of(U, w[(j + 1) % d], s[j], s[(j - 1) % d], w[(j - 1) % d], w[(j + 2) % d], w[(j - 2) % d])
            if F16: am = amask(U, w[(j - 2) % d], w[(j - 1) % d], w[(j + 1) % d], w[(j + 2) % d], s[(j - 2) % d], s[(j - 1) % d], s[j], s[(j + 1) % d]); sg = sg + (am,)
            if sig2_keys(sg): cf[('M', sg)] += 1
        if w[j] == 6 and V6 and U == 7 and d == 7:
            sv_ = sigv_of(U, w[(j + 1) % d], s[j], s[(j - 1) % d], w[(j - 1) % d], w[(j + 2) % d], w[(j - 2) % d])
            if F16: sv_ = sv_ + (am,)
            if sigv_keys(sv_): cf[('V', sv_)] -= 1
        if w[j] == 7 and Q7:
            sg = q7sig(U, w[(j + 1) % d], s[j], s[(j - 1) % d], w[(j - 1) % d])
            if q7keys(sg): cf[('Q', sg)] += 1
        if w[j] == 5 and ZH:
            fc_ = j if (w[(j + 1) % d] == 5 and s[j] == 5) else (j - 1) % d if (w[(j - 1) % d] == 5 and s[(j - 1) % d] == 5) else None
            zk_ = fy_recv_key(U, w[(j - 2) % d], w[(j - 1) % d], w[(j + 1) % d], w[(j + 2) % d], s[(j - 2) % d], s[(j - 1) % d], s[j], s[(j + 1) % d], tau[fc_] if (FY2 and fc_ is not None) else None) if FY else zkey((U, w[(j + 1) % d], s[j], s[(j - 1) % d], w[(j - 1) % d]), c2(w[(j + 2) % d]), c2(w[(j - 2) % d])); cf[('z', zk_)] += 1
            if ZR: cf[('zr', zk_)] -= 1   # s22.1: the big pays out
    if H5:
        for i in range(d):
            if s[i] == 5:
                for k2, c2v in hat_recv_terms(h5_recv(w[(i - 1) % d], w[i], w[(i + 1) % d], w[(i + 2) % d], s[(i - 1) % d], s[(i + 1) % d])).items(): cf[k2] += c2v
    if Q7 and d == 7:
        for k, m in q7_inflow(w).items(): cf[('q', k)] += m if Q7FLIP else -m
    if DD:
        for i in range(d):
            if s[i] >= 7:
                ko, ki = d_keys(U, w[(i - 1) % d], w[i], w[(i + 1) % d], w[(i + 2) % d], s[(i - 1) % d], s[i], s[(i + 1) % d])
                cf[('D', ko)] -= 1; cf[('D', ki)] += 1
    if L3Q: cf.update(l3q_terms(d, w, s))
    if LQVX: cf.update(l3q_terms_payeeV(d, w, s))
    if FB:   # s44: the centre pays its face k-vertices; a big centre also receives from its face-big neighbours
        for _, k in fb_payer_keys(d, w, s): cf[('fb', k)] -= 1
        for _, k in fb_payee_keys(d, w, s, min(d, 9)) if min(d, 9) >= 7 else []: cf[('fb', k)] += 1
    if XO: cf.update(xo_recv_terms(d, w, s))   # s51
    return cf
def cmd_orientR2():
    bad = 0; n = 0
    for a in itertools.product(LET, repeat=7):
        n += 1
        if g2_of(*a) != g2_of(a[4], a[3], a[2], a[1], a[0], a[6], a[5]): bad += 1
        if sig2_of(*a) != sig2_of(a[0], a[4], a[3], a[2], a[1], a[6], a[5]): bad += 1
    for n_ in itertools.product(LET, repeat=5):
        for hr, hl in ((0, 1), (1, 0), (1, 1), (0, 0)):
            n += 1
            if zkey(n_, hr, hl) != zkey((n_[0], n_[4], n_[3], n_[2], n_[1]), hl, hr): bad += 1
    for L in itertools.product(LET, repeat=6):
        for ar, al in ((5, 7), (8, 6), (9, 9)):
            if h2_of(L, ar, al) != h2_of((L[0],) + tuple(reversed(L[1:])), al, ar): bad += 1
    # physical: conservation coefficients invariant under rotating / reflecting the whole 6-centred arrangement
    rng = np.random.default_rng(1)
    for _ in range(20000):
        L = tuple(int(v) for v in rng.choice(LET, 6)); s = tuple(int(v) for v in rng.choice(LET, 6)); k = int(rng.integers(6))
        Lr = L[k:] + L[:k]; sr = s[k:] + s[:k]
        Lf = tuple(L[(-i) % 6] for i in range(6)); sf = tuple(s[(-i - 1) % 6] for i in range(6))
        if cons2_coef(L, s) != cons2_coef(Lr, sr) or cons2_coef(L, s) != cons2_coef(Lf, sf): bad += 1
    if V6:
        for a in itertools.product(LET, repeat=7):
            n += 1
            if sigv_of(*a) != sigv_of(a[0], a[4], a[3], a[2], a[1], a[6], a[5]): bad += 1
        for L in itertools.product(LET, repeat=6):
            for ar, al in ((5, 6), (6, 9), (8, 5)):
                if v_of(L, ar, al) != v_of((L[0],) + tuple(reversed(L[1:])), al, ar): bad += 1
    if Q7:
        for _ in range(20000):
            w = tuple(int(v) for v in rng.choice(LET, 7)); j = int(rng.integers(7))
            if w[j] < 7 or ''.join(map(str, canon(w))) in RBIG: continue
            n += 1; kin = qkey(tuple(w[(j + i) % 7] for i in range(7)))
            W_ = lambda k: w[k % 7]
            for sg in (q7sig(w[j], W_(j + 1), W_(j + 2), W_(j - 2), W_(j - 1)), q7sig(w[j], W_(j - 1), W_(j - 2), W_(j + 2), W_(j + 1))):
                if kin not in q7keys(sg): bad += 1
            if q7_inflow(w) != q7_inflow(canon(w)): bad += 1
    if HX:
        nx_, bx_ = hatx_selftest(int(OPT.get('ntest', '100000')), 'brokenkey' in FLAGS); log('hatx physical test: %d spoke readings, %d mismatches%s' % (nx_, bx_, ' (BROKEN-KEY CONTROL)' if 'brokenkey' in FLAGS else '')); bad += bx_
    if H5:
        nh_, bh_ = hat5_selftest(int(OPT.get('ntest', '100000')), 'brokenkey' in FLAGS); log('hat5 physical test: %d random diamonds, %d with sender key != receiver key%s%s' % (nh_, bh_, ' or r/rr coefficients not conserving / rr not b -> v' if HRR else '', ''.join(t_ for f_, t_ in (('brokenkey', ' (BROKEN-KEY CONTROL)'), ('brokensign', ' (BROKEN-SIGN CONTROL)')) if f_ in FLAGS))); bad += bh_
    if F5:
        nf_, bf_ = face_selftest(); log('face5 physical test: %d faces, %d with nonzero net f' % (nf_, bf_)); bad += bf_
    log('orientation test R6x2 (apex %s): %d + %d + 20000 cases, %d mismatches' % (AP, n, 3 * 5 ** 6, bad))
def cmd_solveR2():
    try:   # maclane: highspy when installed, else the numpy / scipy shim hshim.py next to pcheck.py (HSHIM_FORCE=1 forces the shim)
        if __import__('os').environ.get('HSHIM_FORCE', '0') not in ('', '0'): raise ImportError('HSHIM_FORCE')
        import highspy
    except ImportError:
        import sys as _hs_sys
        if HERE not in _hs_sys.path: _hs_sys.path.insert(0, HERE)
        import hshim as highspy
    load_patterns()
    xon = 'xon' in FLAGS; XCAP = float(OPT.get('xcap', '3')); XPEN = [float(OPT.get('xpen', '0'))]; LEXT = []   # s85: lext phase-1 values
    HPEN = [float(OPT.get('hpen', '0'))]   # s86 (k86L binding analysis 21:00Z): optional cost on the 6-spoke h columns, so a lext phase-2 vertex does not park free h mass at large values (phase 1 is unaffected: its costs are t alone)
    p = os.path.join(WORK, 'clsR2_%d%s%s%s%s%s%s.bin' % (int(xon), 'z' if ZH else '', 'y' if FY else '', 'f' if F16 else '', 'h' if H5 else '', 'D' if DD else '', 'o' if XO else '') + (('g' + GKMD5) if GKON else ''))
    if not os.path.exists(p): class_table_R2(xon).tofile(p)
    CLSFILE[0] = p
    K = int(OPT.get('K', '300')); MAXIT = int(OPT.get('maxit', '300')); TOL = float(OPT.get('tol', '1e-9'))
    global FEAS
    if INOUT or 'inoutctl' in OPT: FEAS = load_feas_cols(OPT['feas']) if 'feasall' in FLAGS else inout_feas(OPT['feas']); log('inout: feasible point %s: %d columns (t = %.6f), lam %s, raw check every %d, min cuts %d' % (OPT['feas'], len(FEAS), FEAS[('t',)], INOUT, INOUTK, INOUTMIN))
    h = highspy.Highs(); h.setOptionValue('output_flag', False); inf = highspy.kHighsInf
    cols = {}; names = []
    def col(key):
        if key not in cols:
            cols[key] = len(names); names.append(key)
            h.addVar(-inf if key[0] == 't' else -XCAP if key[0] == 'XQ' else 0.0, XCAP if key[0] in ('x', 'xo', 'XQ') else DCAP if key[0] == 'D' else LQCAP if key[0] == 'lq' else (FBCAP if FBCAP is not None else inf) if key[0] == 'fb' else ZCAP if (ZR and key[0] in ('z', 'zr', 'rr')) else Z6CAP if key[0] == 'z6' else Q7CAP if (Q7CAP is not None and key[0] == 'q') else KSCAP if key[0] == 'ks' else inf)   # s78: ks capped at kscap
            if key[0] == 'z6' and XPEN[0]: h.changeColCost(cols[key], XPEN[0])   # RELAY_SPEC_s23: z6 carries the x penalty
            if ZR and key[0] in ('z', 'zr', 'rr') and XPEN[0]: h.changeColCost(cols[key], XPEN[0])   # stage 33: z, zr, rr carry the x penalty
            if key[0] in ('x', 'xo') and XPEN[0]: h.changeColCost(cols[key], XPEN[0])   # s51: xo carries the x penalty
            if key[0] == 'D' and DPEN[0]: h.changeColCost(cols[key], DPEN[0])
            if key[0] == 'fb' and XPEN[0]: h.changeColCost(cols[key], XPEN[0])   # s44: fb carries the x penalty (keeppen)
            if key[0] == 'lq' and XPEN[0]: h.changeColCost(cols[key], XPEN[0])   # stage 28: q carries the x penalty (keeppen)
            if key[0] == 'q' and Q7PEN[0]: h.changeColCost(cols[key], Q7PEN[0])   # s75: q7 columns carry their own penalty (q7pen=)
            if key[0] == 'ks' and XPEN[0]: h.changeColCost(cols[key], XPEN[0])   # s78: K* carries the x penalty (keeppen), removed with x's
            if key[0] == 'h' and HPEN[0]: h.changeColCost(cols[key], HPEN[0])   # s86: hpen=
        return cols[key]
    jt = col(('t',)); h.changeColCost(jt, 1.0)
    for r_ in ROOTS: col(('y', r_))
    if KSTAR: col(('ks', 'K1'))   # s78
    for nm_ in EGNAMES: col(('ks', nm_))   # s78 generic EDGE keys (same column namespace and cap)
    for nm_ in GKNAMES: col(('ks', nm_))   # s85 generic 2-ball keys
    if FEAS is not None and 'feascols' in FLAGS:   # s75: every column of the in-point exists in the LP (else the blend silently drops its value)
        for k_ in FEAS: col(k_)
        log('feascols: %d in-point columns created up front (%d LP columns now)' % (len(FEAS), len(names)))
    info = []; have = set(); msig = set(); conset = set(); qsig = set(); vsig = set(); lsig = set(); xqsig = set()
    def addrow(cf, lo, hi, inf_):
        idx = np.array([col(k) for k in cf], dtype=np.int32); val = np.array([float(v) for v in cf.values()])
        h.addRow(lo, hi, len(idx), idx, val); info.append(inf_)
    SR = R2_sender_rows()
    for wd, cf, bits in SR:
        c2_ = dict(cf); c2_[('t',)] = 1.0; addrow(c2_, 1.0, inf, ('senderR2', wd, bits))
    RW = all6_words() if (V6 or CONSALL) else relay_words()   # v6: no-five 6-types must conserve too (v out = h in)
    def addsig(sg):
        if sg in msig: return
        msig.add(sg)
        for k in sig2_keys(sg): addrow({('h', k): 1.0, ('M', sg): -1.0}, -inf, 0.0, ('mrowR2', list(sg), list(k)))
    # s86 v2r (v2r.py): d = 7 / 8 receivers enter only as KEYSPEC v2 realisation rows ('receiverV2', d, link, apex, rho); V2REC = the known
    # receivers (canonical label -> realisation rows in the LP), re-scanned by the DP each round; V2PT = the DP point (column values, key amounts)
    V2REC = collections.OrderedDict(); V2EMPTY = set(); V2PT = [None, None]; V2C = collections.Counter(); V2ROUND = [0]
    V2RESCAN = int(OPT.get('v2rescan', '1')); V2INNER = int(OPT.get('v2inner', '0')); V2INNERCOLD = OPT.get('v2innercold', '1') == '1'; V2T = collections.Counter()
    def v2pt_set(colval, xk): V2PT[0] = colval; V2PT[1] = xk
    def v2addrow(d, lk, sv, rho, cf):
        key = (d, tuple(sorted(cf.items(), key=str)))
        if key in have: return False
        have.add(key); c2_ = dict(cf); c2_[('t',)] = -1.0
        addrow(c2_, -inf, d - 6.0, ('receiverV2', d, lk, sv, rho)); V2REC[(d, lk, sv)] = V2REC.get((d, lk, sv), 0) + 1; V2C['realisation rows'] += 1
        return True
    def v2recv(d, lk, sv, t=None, dry=False, canon=True):
        """DP at V2PT for receiver (d, lk, sv): (v2-violated, row added, excess, rho, lk, sv); t None = seeding (argmax row added whatever its value)"""
        if canon: lk, sv = _canon_row(d, lk, sv)
        if (d, lk, sv) in V2EMPTY: return False, False, None, None, lk, sv
        t_ = time.time(); st = v2r_struct(d, lk, sv)
        if st is None: V2EMPTY.add((d, lk, sv)); V2C['empty domain (no realisation, dropped)'] += 1; return False, False, None, None, lk, sv
        if (d, lk, sv) not in V2REC: V2REC[(d, lk, sv)] = 0
        val, rho, cf = v2r_best(st, V2PT[0], V2PT[1]); V2T['dp'] += time.time() - t_; V2T['n'] += 1
        ex = None if t is None else val - (d - 6) - t
        if t is not None and ex <= V2TOL: return False, False, ex, rho, lk, sv
        if dry: return True, False, ex, rho, lk, sv
        return True, v2addrow(d, lk, sv, rho, cf), ex, rho, lk, sv
    def recv(d, lk, sv):
        if V2R and d in (7, 8): return v2recv(d, lk, sv)[1]   # s86 v2r: seeding at the current DP point
        if FY2:   # s43: every cell of the row
            got = False
            for cl, tau in fy2_cells(d, [int(ch) for ch in lk], [int(ch) for ch in sv]): got = recv1(d, lk, sv, cl, tau) or got
            return got
        return recv1(d, lk, sv, None, None)
    def recv1(d, lk, sv, cl, tau):
        cf = recv_coef_R2(d, lk, sv, xon, tau)
        key = (d, tuple(sorted(cf.items(), key=str)))
        if key in have: return False
        have.add(key)
        for k in cf:
            if k[0] == 'M': addsig(k[1])
            if k[0] == 'V' and k[1] not in vsig:
                vsig.add(k[1])
                for kk in sigv_keys(k[1]): addrow({('V', k[1]): 1.0, ('v', kk): -1.0}, -inf, 0.0, ('mrowV', list(k[1]), list(kk)))
            if k[0] == 'lQ' and k[1] not in lsig:
                lsig.add(k[1]); c_, a_, m_ = k[1][-3:]; V_ = k[1][:-3]
                for a2 in l3q_mask_letters(m_): addrow({('lq', V_ + (c_, a_, a2)): 1.0, ('lQ', k[1]): -1.0}, -inf, 0.0, ('mrowL', list(k[1]), list(V_ + (c_, a_, a2))))
            if k[0] == 'XQ' and k[1] not in xqsig:   # s51: all mrowX rows of q at first use
                xqsig.add(k[1])
                for cfx, ee in xo_mrows(k[1]): addrow(cfx, -inf, 0.0, ('mrowX', [k[1][0], k[1][1], list(k[1][2]), list(k[1][3])], ee))
            if k[0] == 'Q' and k[1] not in qsig:
                qsig.add(k[1])
                for kk in q7keys(k[1]): addrow({('q', kk): 1.0, ('Q', k[1]): -1.0}, -inf, 0.0, ('mrowQ', list(k[1]), list(kk)))
        c2_ = dict(cf); c2_[('t',)] = -1.0
        addrow(c2_, -inf, d - 6.0, ('receiverR2', d, lk, sv) + ((cl,) if FY2 else ())); return True
    def addcons(L, s):
        cf = {k: v for k, v in cons2_coef(L, s).items() if v}
        kk = tuple(sorted(cf.items()))
        if not cf or kk in conset: return False
        conset.add(kk)
        if C6LE: c6_ = dict(cf); c6_[('t',)] = -1.0; addrow(c6_, -inf, 0.0, ('cons2', list(L), list(s)))   # s83
        else: addrow(cf, 0.0, 0.0, ('cons2', list(L), list(s)))
        return True
    # initial conservation rows: one apex word per L (all apexes 5) -- the rest by separation
    if L6R:   # RELAY_SPEC_s23.4: all mrowZ rows and both column sets up front
        for Kz in z6_first(): addrow({("z6", Kz): 1.0, ("Z6", zsig6_of_key(Kz)): -1.0}, -inf, 0.0, ("mrowZ", list(Kz)))
        log('l6r: %d mrowZ rows, %d Z6 signatures' % (len(z6_first()), len({zsig6_of_key(K) for K in z6_first()})))
    for L in RW: addcons(L, (5,) * 6)
    if 'consbasis' in OPT:
        nb = sum(addcons(tuple(L), tuple(s_)) for L, s_ in json.load(open(OPT['consbasis'])))
        log('conservation basis rows added: %d' % nb)
    if V2R:   # s86 v2r: seed point for the warm d = 7 / 8 receivers (any point is valid; it only decides which realisation row enters first)
        SD_ = load_feas_cols(OPT['v2seed']) if 'v2seed' in OPT else {}
        v2pt_set(v2r_colval_dict(SD_), v2r_xk_dict(SD_)); del SD_
        log('v2r: seed point %s; rescan of the known receivers every %d round(s) (and before the loop would stop); v2tol %g; v2inner %d (phase-1 cutting-plane rounds per lext iteration, %s re-solves)' % (OPT.get('v2seed', 'x = 0 (no v2seed=)'), V2RESCAN, V2TOL, V2INNER, 'cold' if V2INNERCOLD else 'warm'))
    if 'warm' in OPT:
        nw = 0; tw_ = time.time()
        for fn in OPT['warm'].split(','):
            for line in open(fn):
                m = re.match(r'^R (\d+) (\d+) (\d+)', line)
                if m and admissible(int(m.group(1)), m.group(2), m.group(3)) is None: nw += recv(int(m.group(1)), m.group(2), m.group(3))
                mc_ = re.match(r'^C ([5-9]{6}) ([5-9]{6})\s*$', line)   # s86 consk: logged cons rows
                if mc_: nw += addcons(tuple(map(int, mc_.group(1))), tuple(map(int, mc_.group(2))))
                mv_ = re.match(r'^V2 ([78]) ([5-9]+) ([5-9]+) ([5-9]+)\s*$', line) if V2R else None   # s86 v2r: a realisation row logged by a v2r run
                if mv_ and admissible(int(mv_.group(1)), mv_.group(2), mv_.group(3)) is None:
                    d_, lk_, sv_, rho_ = int(mv_.group(1)), mv_.group(2), mv_.group(3), mv_.group(4)
                    nw += v2addrow(d_, lk_, sv_, rho_, v2r_row(d_, lk_, sv_, rho_)); V2C['warm V2 lines'] += 1
        log('warm rows admitted: %d' % nw)
        if V2R: log('v2r: warm d = 7 / 8 receivers %d (canonical), realisation rows %d; %s; DP %.0fs for %d calls (%.2f ms each); warm total %.0fs' % (
            len(V2REC), sum(V2REC.values()), dict(V2C), V2T['dp'], V2T['n'], 1000 * V2T['dp'] / max(1, V2T['n']), time.time() - tw_))
    ng = sum(1 for k in cols if k[0] == 'g')
    log('R6x2 (apex %s): %d sender rows, %d g keys in senders, %d six-words, %d initial cons rows, %d M sigs' % (AP, len(SR), ng, len(RW), len(conset), len(msig)))
    if 'structonly' in FLAGS: return h, cols, info, conset, RW, SR
    T0 = time.time(); rowlog = open(os.path.join(HERE, 'rows_%s.txt' % OPT.get('tag', 'run')), 'w')
    def sepround(xv, t, tail, dry=False):
        y = np.array([xv[cols[('y', r_)]] for r_ in ROOTS])
        GV = {k[1]: xv[i] for k, i in cols.items() if k[0] == 'g'}; HV2 = {k[1]: xv[i] for k, i in cols.items() if k[0] == 'h'}
        ZV.clear(); ZV.update({k[1]: xv[i] for k, i in cols.items() if k[0] == 'z'})
        ZRV.clear(); ZRV.update({k[1]: xv[i] for k, i in cols.items() if k[0] == 'zr'})
        Z6V.clear(); Z6V.update({k[1]: xv[i] for k, i in cols.items() if k[0] == 'z6'}); Z6W.clear(); Z6W.update({k[1]: xv[i] for k, i in cols.items() if k[0] == 'Z6'})
        QV.clear(); QV.update({k[1]: xv[i] for k, i in cols.items() if k[0] == 'q'})
        VV.clear(); VV.update({k[1]: xv[i] for k, i in cols.items() if k[0] == 'v'})
        RV.clear(); RV.update({k[1]: xv[i] for k, i in cols.items() if k[0] == 'r'})
        RRV.clear(); RRV.update({k[1]: xv[i] for k, i in cols.items() if k[0] == 'rr'})
        DV.clear(); DV.update({k[1]: xv[i] for k, i in cols.items() if k[0] == 'D'})
        if Q7: write_bonus()
        LQV.clear(); LQV.update({k[1]: xv[i] for k, i in cols.items() if k[0] == 'lq'})
        KSV.clear(); KSV.update({k[1]: float(xv[i]) for k, i in cols.items() if k[0] == 'ks' and i < len(xv)})   # s78
        FBV.clear(); FBV.update({k[1]: xv[i] for k, i in cols.items() if k[0] == 'fb'})
        LQQ.clear(); LQQ.update({k[1]: xv[i] for k, i in cols.items() if k[0] == 'lQ'})
        if L3Q: write_l3q()
        xd = {k[1]: xv[i] for k, i in cols.items() if k[0] == 'x' and xv[i] > 1e-12}
        XOV.clear(); XOV.update({k[1]: xv[i] for k, i in cols.items() if k[0] == 'xo' and xv[i] > 0})   # s51
        mcache = {}
        def MV2(sg):
            if sg not in mcache:
                ks = sig2_keys(sg); mcache[sg] = max(HV2.get(k, 0.0) for k in ks) if ks else None
            return mcache[sg]
        F2B_MV2[0] = MV2
        added = 0; per = {}; NVIOL[0] = 0   # s75: NVIOL = every violated row found (new or already in the LP); 'added' counts new rows only
        nc = 0; worst = 0.0
        for L in RW:   # conservation separation
            D = cons2_delta(L, GV, HV2)
            if C6LE and CONSK > 1:   # s86 consk
                ex = D - t; mx_ = float(ex.max())
                if mx_ <= 1e-9: continue
                NVIOL[0] += 1; worst = max(worst, abs(float(D.max()))); k_ = 0
                vi = np.nonzero(ex >= max(1e-9, CONSFRAC * mx_))[0]
                for idx in vi[np.argsort(-ex[vi], kind='stable')]:
                    s_ = tuple(LET[v] for v in SALL[idx])
                    if dry or addcons(L, s_):
                        nc += 1; k_ += 1
                        if not dry or 'ctlrows' in FLAGS: rowlog.write('C %s %s\n' % (''.join(map(str, L)), ''.join(map(str, s_))))
                        if k_ >= CONSK: break
                continue
            for idx in ((int(np.argmax(D)),) if C6LE else (int(np.argmax(D)), int(np.argmin(D)))):   # s83: under c6le only in - out > t is a violation
                if ((D[idx] - t) > 1e-9) if C6LE else (abs(D[idx]) > 1e-9):
                    NVIOL[0] += 1
                    worst = max(worst, abs(D[idx]))
                    if (True if dry else addcons(L, tuple(LET[v] for v in SALL[idx]))): nc += 1
        added += nc; per['cons'] = (nc, round(worst, 6))
        Wc = {}
        if V2R:   # s86 v2r: the DP point = this separation point (columns created after xv was taken are 0)
            _nx = len(xv); v2pt_set(lambda k_: float(xv[cols[k_]]) if (k_ in cols and cols[k_] < _nx) else 0.0,
                                   np.array([float(xv[cols[('ks', nm_)]]) if (('ks', nm_) in cols and cols[('ks', nm_)] < _nx) else 0.0 for nm_ in GKNAMES]))
            V2ROUND[0] += 1; v2seen = set(); V2T.clear()
        for d in range(7, DMAX + 1):
            U = min(d, 9)
            if U not in Wc: Wc[U] = window_table_R2(U, y, xd, MV2)
            rr, dt, ni = run_sep(d, Wc[U], d - 6 + t + TOL, K, 2)
            n = 0; mx = None
            if V2R and d in (7, 8):   # s86 v2r: the masked separator's list (a superset of the v2-violated receivers up to its top-K cap) -> DP each
                nl_ = nv_ = 0; tv_ = time.time()
                for r_ in rr:
                    if r_[0] != 'V': continue
                    nl_ += 1; vio, add_, ex, rho, lk_, sv_ = v2recv(d, r_[2], r_[3], t, dry); v2seen.add((d, lk_, sv_))
                    if not vio: continue
                    NVIOL[0] += 1; nv_ += 1; mx = max(mx or -1e9, ex)
                    if add_ or dry:
                        n += 1
                        if not dry or 'ctlrows' in FLAGS: rowlog.write('R %d %s %s\nV2 %d %s %s %s\n' % (d, lk_, sv_, d, lk_, sv_, rho))
                added += n; per[d] = (n, None if mx is None else round(mx, 6), round(dt, 1), 'v2: listed %d, v2-violated %d, phantoms %d%s, DP %.1fs' % (
                    nl_, nv_, nl_ - nv_, ' (top-K cap reached: CROWDED, see v2r/README)' if nl_ >= K and nv_ < nl_ else '', time.time() - tv_))
                continue
            for r_ in rr:
                if r_[0] == 'V':
                    NVIOL[0] += 1
                    mx = max(mx or -1e9, float(r_[1]) - (d - 6 + t))
                    if 'dbg' in FLAGS and n == 0:
                        cf = recv_coef_R2(d, r_[2], r_[3], xon)
                        val = sum(v * (MV2(k[1]) if k[0] == 'M' else max([QV.get(kk, 0.0) for kk in q7keys(k[1])] or [0.0]) if k[0] == 'Q' else min([VV.get(kk, 0.0) for kk in sigv_keys(k[1])] or [0.0]) if k[0] == 'V' else xv[cols[k]] if k in cols and cols[k] < len(xv) else 0) for k, v in cf.items())
                        log('  DBG d=%d sep %s row %.9f' % (d, r_[1], val))
                    if dry or recv(d, r_[2], r_[3]):
                        n += 1
                        if not dry or 'ctlrows' in FLAGS: rowlog.write('R %d %s %s\n' % (d, r_[2], r_[3]))   # s75 ctlrows: a dry control also writes the rows it finds
            added += n; per[d] = (n, None if mx is None else round(mx, 6), round(dt, 1))
        if V2R and V2RESCAN > 0 and (V2ROUND[0] % V2RESCAN == 0 or not added):   # s86 v2r: DP on every known d = 7 / 8 receiver not listed this round
            tr_ = time.time(); n = 0; nv_ = 0; mx = None; nsc = 0
            for (d, lk_, sv_) in list(V2REC):
                if (d, lk_, sv_) in v2seen: continue
                nsc += 1; vio, add_, ex, rho, _, _ = v2recv(d, lk_, sv_, t, dry, canon=False)
                if not vio: continue
                NVIOL[0] += 1; nv_ += 1; mx = max(mx or -1e9, ex)
                if add_ or dry:
                    n += 1
                    if not dry or 'ctlrows' in FLAGS: rowlog.write('V2 %d %s %s %s\n' % (d, lk_, sv_, rho))
            added += n; per['v2scan'] = (n, None if mx is None else round(mx, 6), round(time.time() - tr_, 1), 'rescanned %d known receivers, v2-violated %d' % (nsc, nv_))
        if V2R: per['v2dp'] = ('dp', None, round(V2T['dp'], 1), '%d DP calls, %.2f ms each; known receivers %d, realisation rows %d' % (V2T['n'], 1000 * V2T['dp'] / max(1, V2T['n']), len(V2REC), sum(V2REC.values())))
        if not added and tail:
            W9 = Wc.get(9); Mr = relaxed_M(W9)
            for d in range(DMAX + 1, DTAIL + 1):
                if closed_max(Mr, d) <= d - 6 + t + TOL: continue
                rr, dt, ni = run_sep(d, W9, d - 6 + t + TOL, K, 2, pats=False); n = 0
                for r_ in rr:
                    if r_[0] == 'V': NVIOL[0] += 1
                    if r_[0] == 'V' and (dry or recv(d, r_[2], r_[3])):
                        n += 1
                        if not dry or 'ctlrows' in FLAGS: rowlog.write('R %d %s %s\n' % (d, r_[2], r_[3]))   # s75 ctlrows: a dry control also writes the rows it finds
                added += n; per[d] = (n, 'tail', round(dt, 1))
            lam = karp(Mr); log('  Karp lambda %.6f d0 %.2f' % (lam, (6 - t) / (1 - lam) if lam < 1 else 1e9))
        return added, per, nc, worst
    def soldict(xv):   # s75: the sol json of any column vector (the writer used at the end of the run; also per-iteration / in-point checkpoints)
        t = xv[jt]
        return {'t': float(t), 'model': 'R6x2', 'apex': AP, 'xon': xon,
         'y': {rname(k[1]): float(xv[i]) for k, i in cols.items() if k[0] == 'y' and xv[i] > 0},
         'g': [[list(k[1]), float(xv[i])] for k, i in cols.items() if k[0] == 'g' and xv[i] > 0],
         'h': [[list(k[1]), float(xv[i])] for k, i in cols.items() if k[0] == 'h' and xv[i] > 0],
         'z': [[list(k[1]), float(xv[i])] for k, i in cols.items() if k[0] == 'z' and xv[i] > 0], 'zh': ZH, 'fy': FY, 'fy2': FY2, 'apexcls': AC,
         'zr': [[list(k[1]), float(xv[i])] for k, i in cols.items() if k[0] == 'zr' and xv[i] > 0], 'zrflag': ZR,
         'q': [[list(k[1]), float(xv[i])] for k, i in cols.items() if k[0] == 'q' and xv[i] > 0], 'q7': Q7, 'q7m': Q7M,
         'v': [[list(k[1]), float(xv[i])] for k, i in cols.items() if k[0] == 'v' and xv[i] > 0], 'v6': V6,
         'f': [[list(k[1]), float(xv[i])] for k, i in cols.items() if k[0] == 'f' and xv[i] > 0], 'face5': F5,
         'r': [[list(k[1]), float(xv[i])] for k, i in cols.items() if k[0] == 'r' and xv[i] > 0], 'hat5': H5,
         'rr': [[list(k[1]), float(xv[i])] for k, i in cols.items() if k[0] == 'rr' and xv[i] > 0], 'hatrr': HRR,
         'D': [[repr(k[1]), float(xv[i])] for k, i in cols.items() if k[0] == 'D' and xv[i] > 0], 'big2': DD,
         'lq': [[list(k[1]), float(xv[i])] for k, i in cols.items() if k[0] == 'lq' and xv[i] > 0],
         'lQ': [[list(k[1]), float(xv[i])] for k, i in cols.items() if k[0] == 'lQ' and xv[i] > 0], 'l3q': L3Q,
         'z6': [[list(k[1]), float(xv[i])] for k, i in cols.items() if k[0] == 'z6' and xv[i] > 0], 'Z6': [[list(k[1]), float(xv[i])] for k, i in cols.items() if k[0] == 'Z6' and xv[i] > 0], 'l6r': L6R,
         'fb': [[list(k[1]), float(xv[i])] for k, i in cols.items() if k[0] == 'fb' and xv[i] > 0], 'fbflag': FB,
         'V': [[list(k[1]), float(xv[i]), min([float(xv[cols[('v', kk)]]) if ('v', kk) in cols else 0.0 for kk in sigv_keys(k[1])] or [0.0])] for k, i in cols.items() if k[0] == 'V'],
         'x': {str(k[1]): float(xv[i]) for k, i in cols.items() if k[0] == 'x' and xv[i] > 0},
         'xo': {str(k[1]): float(xv[i]) for k, i in cols.items() if k[0] == 'xo' and xv[i] > 0}, 'xoflag': XO,   # s51
         'ks': [[k[1], float(xv[i])] for k, i in cols.items() if k[0] == 'ks' and xv[i] > 0], 'kstar': KSTAR}   # s78
    def padv(v): return np.concatenate([v, np.zeros(len(names) - len(v))]) if len(v) < len(names) else v   # columns created after v was taken are 0 in v
    def dumpsol(xv, fn):   # s75: atomic write
        json.dump(soldict(padv(xv)), open(fn + '.tmp', 'w')); os.replace(fn + '.tmp', fn)
    def move_in(xb, xold, how, it):   # s75: the feasible blend becomes the in-point (FEAS); written to sol_<tag>_in.json for upperR2 / resume (feas=<it> feasall)
        global FEAS
        xb = padv(xb); FEAS = {k: float(xb[i]) for k, i in cols.items() if xb[i] != 0.0}; FEAS[('t',)] = float(xb[jt])
        fn = os.path.join(HERE, 'sol_%s_in.json' % OPT.get('tag', 'run')); dumpsol(xb, fn)
        INMOVES.append((it, how, float(xb[jt]))); dumpsol(xb, os.path.join(HERE, 'sol_%s_in%02d.json' % (OPT.get('tag', 'run'), len(INMOVES))))
        log('  in-point MOVED (%s, iter %d): t_in %.12f -> %.12f  [candidate only: run upperR2 on %s]' % (how, it, float(xold[jt]), float(xb[jt]), fn))
    def inject_in():   # s86: an external point that passed upperR2 on this family (repair ladder) replaces the in-point when its t is lower; file sol dir inject_<tag>.json, renamed .used
        global FEAS
        fn = os.path.join(HERE, 'inject_%s.json' % OPT.get('tag', 'run'))
        if FEAS is None or not os.path.exists(fn): return
        try: F2 = load_feas_cols(fn)
        except Exception as e: log('  inject: cannot read %s: %s' % (fn, e)); os.replace(fn, fn + '.bad'); return
        os.replace(fn, fn + '.used')
        if F2[('t',)] >= FEAS[('t',)] - 1e-12: log('  inject: t %.12f not below t_in %.12f, ignored' % (F2[('t',)], FEAS[('t',)])); return
        for k_ in F2: col(k_)
        log('  in-point INJECTED: t_in %.12f -> %.12f (%s, %d columns)' % (FEAS[('t',)], F2[('t',)], fn + '.used', len(F2))); FEAS = F2
    if 'inoutctl' in OPT:   # s70: control -- separate at lam*raw + (1-lam)*feas without any LP (dry run, nothing added)
        lamc = float(OPT['inoutctl']); FEAS0 = load_feas_cols(OPT['feas']) if 'feasall' in FLAGS else inout_feas(OPT['feas'])
        RAWD = load_feas_cols(OPT['rawsol']) if 'rawsol' in OPT else FEAS0
        for k_ in list(FEAS0) + list(RAWD): col(k_)
        xf = np.zeros(h.getNumCol()); xr = np.zeros(h.getNumCol())
        for k_, v_ in FEAS0.items(): xf[cols[k_]] = v_
        for k_, v_ in RAWD.items(): xr[cols[k_]] = v_
        xb = inout_blend(xr, xf, lamc)
        if lamc >= 1.0: assert np.array_equal(xb, xr), 'lam=1 blend is not the raw point'
        if lamc <= 0.0: assert np.array_equal(xb, xf), 'lam=0 blend is not the feasible point'
        if 'ctlteps' in OPT: xb = xb.copy(); xb[jt] -= float(OPT['ctlteps']); log('inoutctl: t lowered by ctlteps = %s (finds the rows with slack < ctlteps at the blend)' % OPT['ctlteps'])   # s75
        badS = 0; worstS = 0.0
        for wd, cf, bits in SR:
            v_ = sum(c_ * xb[cols[k_]] for k_, c_ in cf.items()) + xb[jt]
            if v_ < 1 - 1e-9: badS += 1; worstS = max(worstS, 1 - v_)
        log('inoutctl lam=%g: t_sep=%.9f; sender rows violated %d (worst %.3g) of %d' % (lamc, xb[jt], badS, worstS, len(SR)))
        T1 = time.time(); added, per, nc, worst = sepround(xb, float(xb[jt]), False, True)
        log('inoutctl lam=%g: cons rows violated %d (worst %.3g); receiver violations by d (count, max excess, sec): %s; total %d; %.0fs' % (lamc, nc, worst, {d: v for d, v in per.items() if d != "cons"}, added - nc, time.time() - T1))
        if 'ctlwrite' in OPT: dumpsol(xb, OPT['ctlwrite']); log('inoutctl: blended vector written to %s (t = %.12f); check it with upperR2' % (OPT['ctlwrite'], xb[jt]))   # s75
        return
    for it in range(MAXIT):
        t1 = time.time()
        injf = os.path.join(HERE, 'inject_%s.txt' % OPT.get('tag', 'run'))   # s75: rows dropped into eng/inject_<tag>.txt are admitted before the next LP (file renamed .done)
        if os.path.exists(injf):
            ni_ = 0; os.replace(injf, injf + '.reading')
            for line in open(injf + '.reading'):
                m = re.match(r'^R (\d+) (\d+) (\d+)', line)
                if m and admissible(int(m.group(1)), m.group(2), m.group(3)) is None and recv(int(m.group(1)), m.group(2), m.group(3)):
                    ni_ += 1; rowlog.write(line)
                mc_ = re.match(r'^C ([5-9]{6}) ([5-9]{6})\s*$', line)   # s86 consk
                if mc_ and addcons(tuple(map(int, mc_.group(1))), tuple(map(int, mc_.group(2)))): ni_ += 1; rowlog.write(line)
            os.replace(injf + '.reading', injf + '.done'); rowlog.flush(); log('  inject: %d new rows admitted from %s' % (ni_, injf))
        if 'ipm0' in FLAGS: h.setOptionValue('solver', 'ipm' if it == 0 else 'simplex')
        LPMAX = float(OPT.get('lpmax', '0'))   # s33z: per-LP time limit (s); on a stalled simplex re-run with IPM (+ simplex polish)
        if 'lext' in FLAGS:   # s85 (swarm 05:45Z): lexicographic pure t. Phase 1: minimise t alone on the current rows (t1, a valid lower
            # estimate of the family's t* on this stack, [M] until lowerR2 checks its cert); phase 2 (the LP below): the run's own costs
            # (penalties) with t <= t1 + 1e-9; separation then happens at the phase-2 point.  lextcert: phase-1 cert written when t1 > 1e-9.
            tl_ = time.time(); nC_ = h.getNumCol(); ix_ = np.arange(nC_, dtype=np.int32); C_ = np.array(h.getCols(nC_, ix_)[2], dtype=np.float64)
            z_ = np.zeros(nC_); z_[jt] = 1.0; h.changeColsCost(nC_, ix_, z_); h.changeColBounds(jt, -highspy.kHighsInf, highspy.kHighsInf)
            if LPMAX: h.setOptionValue('time_limit', h.getRunTime() + LPMAX)
            h.run()
            if LPMAX and h.getModelStatus() == highspy.HighsModelStatus.kTimeLimit:
                h.setOptionValue('time_limit', highspy.kHighsInf); h.setOptionValue('solver', 'ipm'); h.run(); h.setOptionValue('solver', 'simplex'); h.run()
            if LPMAX: h.setOptionValue('time_limit', highspy.kHighsInf)
            st1_ = h.modelStatusToString(h.getModelStatus()); s1_ = h.getSolution(); t1_ = float(s1_.col_value[jt])
            if V2R and V2INNER > 0:   # s86 v2r (v2inner=k): up to k cutting-plane rounds on the KNOWN d = 7 / 8 receivers at the phase-1 point,
                # each followed by a warm phase-1 re-solve (rows only added, objective unchanged); no separator call (they run after phase 2 as before)
                for ii_ in range(V2INNER):
                    xv1_ = np.array(s1_.col_value); nx1_ = len(xv1_); ti_ = time.time(); na_ = 0
                    v2pt_set((lambda k_, a_=xv1_, n_=nx1_: float(a_[cols[k_]]) if (k_ in cols and cols[k_] < n_) else 0.0),
                             np.array([float(xv1_[cols[('ks', nm_)]]) if (('ks', nm_) in cols and cols[('ks', nm_)] < nx1_) else 0.0 for nm_ in GKNAMES]))
                    for (d_, lk_, sv_) in list(V2REC):
                        vio_, add_, ex_, rho_, _, _ = v2recv(d_, lk_, sv_, t1_, False, canon=False)
                        if add_: na_ += 1; rowlog.write('V2 %d %s %s %s\n' % (d_, lk_, sv_, rho_))
                    rowlog.flush(); nC2_ = h.getNumCol()
                    if nC2_ > nC_:   # columns the new rows created: cost 0 in phase 1, their own cost restored with the others after it
                        ix2_ = np.arange(nC_, nC2_, dtype=np.int32); C2_ = np.array(h.getCols(nC2_ - nC_, ix2_)[2], dtype=np.float64)
                        h.changeColsCost(nC2_ - nC_, ix2_, np.zeros(nC2_ - nC_)); C_ = np.concatenate([C_, C2_]); nC_ = nC2_; ix_ = np.arange(nC_, dtype=np.int32)
                    log('  v2inner it %d.%d: t1 = %.12f; DP on %d known d = 7 / 8 receivers: %d realisation rows added (%.0fs)%s' % (it, ii_, t1_, len(V2REC), na_, time.time() - ti_, '' if na_ else '; none violated'))
                    if not na_: break
                    tl2_ = time.time()
                    if V2INNERCOLD: h.clearSolver()   # v2innercold=1 (default): re-solve from scratch with presolve (the smoke: warm re-solve without presolve 6x slower)
                    if LPMAX: h.setOptionValue('time_limit', h.getRunTime() + LPMAX)
                    h.run()
                    if LPMAX and h.getModelStatus() == highspy.HighsModelStatus.kTimeLimit:
                        h.setOptionValue('time_limit', highspy.kHighsInf); h.setOptionValue('solver', 'ipm'); h.run(); h.setOptionValue('solver', 'simplex'); h.run()
                    if LPMAX: h.setOptionValue('time_limit', highspy.kHighsInf)
                    st1_ = h.modelStatusToString(h.getModelStatus()); s1_ = h.getSolution(); t1_ = float(s1_.col_value[jt])
                    log('  v2inner it %d.%d: phase 1 re-solve t1 = %.12f, status %s, %.0fs' % (it, ii_, t1_, st1_, time.time() - tl2_))
            LEXT.append(t1_)
            if 'lextcert' in FLAGS and t1_ > 1e-9:
                cf_ = os.path.join(HERE, 'cert_%s_p1.json' % OPT.get('tag', 'run')); rd_ = s1_.row_dual
                json.dump([{'w': float(dv), 'row': info[i]} for i, dv in enumerate(rd_) if abs(dv) > 1e-11], open(cf_, 'w'), indent=0)
                dumpsol(np.array(s1_.col_value), os.path.join(HERE, 'sol_%s_p1.json' % OPT.get('tag', 'run')))
            log('  lext it %d: phase 1 (t alone) t1 = %.12f, status %s, %.0fs; best t1 so far %.12f%s' % (it, t1_, st1_, time.time() - tl_, max(LEXT), ('; phase-1 cert written' if 'lextcert' in FLAGS and t1_ > 1e-9 else '')))
            h.changeColsCost(nC_, ix_, C_); h.changeColBounds(jt, -highspy.kHighsInf, t1_ + 1e-9)
        if LPMAX: h.setOptionValue('time_limit', h.getRunTime() + LPMAX)
        h.run()
        if LPMAX and h.getModelStatus() == highspy.HighsModelStatus.kTimeLimit:
            t_ = time.time(); h.setOptionValue('time_limit', highspy.kHighsInf); h.setOptionValue('solver', 'ipm'); h.run()
            h.setOptionValue('solver', 'simplex'); h.run()
            log('  lpmax: simplex hit %.0fs at iter %d; IPM + simplex %.1fs, status %s' % (LPMAX, it, time.time() - t_, h.modelStatusToString(h.getModelStatus())))
        if LPMAX: h.setOptionValue('time_limit', highspy.kHighsInf)
        if 'ipm0' in FLAGS and it == 0 and 'polish' in FLAGS:   # stage 33: re-run simplex from the IPM crossover basis (vertex duals for lowerR2)
            t_ = time.time(); h.setOptionValue('solver', 'simplex'); h.run(); log('  polish: simplex from the IPM basis %.1fs, status %s' % (time.time() - t_, h.modelStatusToString(h.getModelStatus())))
        xv = np.array(h.getSolution().col_value); t = xv[jt]
        if 'lext' in FLAGS: st2_ = h.modelStatusToString(h.getModelStatus()); h.changeColBounds(jt, -highspy.kHighsInf, highspy.kHighsInf); log('  lext it %d: phase 2 status %s, t = %.12f' % (it, st2_, t))   # status read before the bound reset (which clears it)
        y = np.array([xv[cols[('y', r_)]] for r_ in ROOTS])
        if 'q7rc' in FLAGS:   # s67: report the three W5 keys (value, reduced cost = col_dual, min convention) and the q mass
            cdl = h.getSolution().col_dual; kk3 = [(7, 6, 6, 5, 5, 5, 7), (7, 5, 5, 5, 6, 6, 7), (7, 5, 7, 5, 5, 6, 6)]
            log('  q7rc it %d: t=%.9f; q cols %d, with value>0 %d, sum q %.6f; Q cols %d; keys %s' % (it, t, sum(1 for k in cols if k[0] == 'q'), sum(1 for k, i in cols.items() if k[0] == 'q' and xv[i] > 1e-12), sum(xv[i] for k, i in cols.items() if k[0] == 'q'), sum(1 for k in cols if k[0] == 'Q'),
                ' '.join('%s:%s' % (''.join(map(str, k)), ('val=%.5g rc=%.5g' % (xv[cols[('q', k)]], cdl[cols[('q', k)]])) if ('q', k) in cols else 'no-col') for k in kk3)))
        log('  rrz it %d: cols rr %d z %d zr %d; positive (>1e-9) rr %d z %d zr %d; sum rr %.4f z %.4f zr %.4f' % (it, *[sum(1 for k in cols if k[0] == f) for f in ('rr', 'z', 'zr')], *[sum(1 for k, i in cols.items() if k[0] == f and xv[i] > 1e-9) for f in ('rr', 'z', 'zr')], *[sum(xv[i] for k, i in cols.items() if k[0] == f) for f in ('rr', 'z', 'zr')]))   # s69 logging (added after the first K run started)
        if KSTAR or EGNAMES:   # s78: K* / EDGE amounts and reduced costs (col_dual, min convention) every iteration
            cdl = h.getSolution().col_dual
            log('  kstar it %d: t=%.9f %s (cap %g)' % (it, t, ' '.join('%s = %.9f rc %.6g' % (k_[1], xv[i_], cdl[i_]) for k_, i_ in sorted(cols.items()) if k_[0] == 'ks'), KSCAP))
        tlp = time.time() - t1
        if 'nosep' in FLAGS:
            if 'conssep' in FLAGS:   # s83: separate cons2 rows only (receivers stay the warm set); repeat until none is violated
                GVc = {k[1]: xv[i] for k, i in cols.items() if k[0] == 'g'}; HVc = {k[1]: xv[i] for k, i in cols.items() if k[0] == 'h'}
                ncs = 0; wcs = 0.0
                for Lc in RW:
                    Dc = cons2_delta(Lc, GVc, HVc)
                    for idx in ((int(np.argmax(Dc)),) if C6LE else (int(np.argmax(Dc)), int(np.argmin(Dc)))):
                        viol = float(Dc[idx] - t) if C6LE else abs(float(Dc[idx]))
                        if viol > 1e-9:
                            wcs = max(wcs, viol)
                            if addcons(Lc, tuple(LET[v] for v in SALL[idx])): ncs += 1
                log('  conssep it %d: t = %.12f, %d cons2 rows added (worst %.3g)' % (it, t, ncs, wcs))
                if ncs: continue
            log('nosep: LP over the warm rows only, t = %.12f (a lower bound once lowerR2 checks the cert)' % t); break
        tsep = time.time(); rounds = []
        dumpsol(xv, os.path.join(HERE, 'sol_%s_lp.json' % OPT.get('tag', 'run')))   # s75: per-iteration LP point checkpoint
        if INOUT is None:
            added, per, nc_, worst_ = sepround(xv, t, True); rounds.append('raw:%d' % added)
        else:
            inject_in(); xv = padv(xv)   # s86: columns an injected in-point created are 0 at x_LP
            xf = np.zeros(len(xv))
            for k_, v_ in FEAS.items():
                i_ = cols.get(k_)
                if i_ is not None: xf[i_] = v_
            if (it + 1) % INOUTK == 0 or LAM[0] >= 1.0 or INOUT[2] <= 0:   # scheduled raw check (also adds its cuts)
                added, per, nc_, worst_ = sepround(xv, t, True); rounds.append('raw:%d' % added)
            else:
                nmove = 0
                while True:
                    l_ = LAM[0]; xb = inout_blend(xv, xf, l_)
                    added, per, nc_, worst_ = sepround(xb, float(xb[jt]), INOUTMOVE or l_ >= 1.0); rounds.append('lam%.3f(t=%.6f):%d' % (l_, xb[jt], added))
                    if added:
                        lp_ = l_
                        for ip_ in range(INOUTNPROBE if (INOUTPROBE > 0 and l_ < 1.0) else 0):   # s75: probes nearer the in-point (lam*f, lam*f^2, ...); their rows are violated at x_LP too; the first probe with no violated row becomes the in-point
                            nc0 = h.getNumCol(); xv = np.concatenate([xv, np.zeros(nc0 - len(xv))]); xf = np.concatenate([xf, np.zeros(nc0 - len(xf))])   # new columns from earlier rounds = 0 at both points
                            lp_ = lp_ * INOUTPROBE; xb2 = inout_blend(xv, xf, lp_)
                            a2, per2, nc2_, w2_ = sepround(xb2, float(xb2[jt]), INOUTMOVE); rounds.append('probe%.4f(t=%.6f):%d/v%d' % (lp_, xb2[jt], a2, NVIOL[0]))
                            for d_, v_ in per2.items():
                                if d_ != 'cons' and v_[0]: per['p%d%s' % (ip_, d_)] = v_
                            added += a2
                            if NVIOL[0] == 0:
                                if INOUTMOVE: move_in(xb2, xf, 'probe', it); xf = xb2
                                break
                        if added < INOUTMIN and LAM[0] < INOUT[1]: LAM[0] = min(LAM[0] + INOUT[2], INOUT[1])
                        break
                    if INOUTMOVE and l_ < 1.0 and nmove < INOUTMAXMOVE and NVIOL[0] == 0:   # s75: the blend is feasible (no violated row at all, tail included): it becomes the in-point
                        move_in(xb, xf, 'blend', it); xf = xb; nmove += 1; continue
                    if LAM[0] < INOUT[1]: LAM[0] = min(LAM[0] + INOUT[2], INOUT[1]); continue
                    added, per, nc_, worst_ = sepround(xv, t, True); rounds.append('raw:%d' % added); break
            log('  in-point: t_in = %.12f (%s; moves so far %d)' % (FEAS[('t',)], OPT['feas'] if not INMOVES else 'sol_%s_in.json' % OPT.get('tag', 'run'), len(INMOVES)))
        rowlog.flush()
        tsep = time.time() - tsep
        log('iter %d t=%.12f rows %d cols %d added %d  lp %.1fs sep %.1fs total %.0fs  rounds %s  %s' % (it, t, h.getNumRow(), h.getNumCol(), added, tlp, tsep, time.time() - T0, ' '.join(rounds), {d: v for d, v in per.items() if v[0]}))
        if not added and XPEN[0] and 'keeppen' in FLAGS:
            log('  converged with x penalty; keeppen: stopping here (no violated row at this solution; sol = this solution)'); break
        if not added and XPEN[0]:
            XPEN[0] = 0.0
            for k, i in cols.items():
                if k[0] in ('x', 'xo', 'D', 'lq', 'z6', 'fb', 'ks') or (ZR and k[0] in ('z', 'zr', 'rr')) or (Q7PEN[0] and k[0] == 'q') or (HPEN[0] and k[0] == 'h'): h.changeColCost(i, 0.0)
            log('  converged with x penalty; penalty removed, continuing'); continue
        if not added: break
    sol = h.getSolution(); xv = np.array(sol.col_value); t = xv[jt]; duals = np.array(sol.row_dual)
    tag = OPT.get('tag', 'run')
    S = soldict(xv)   # s75: factored out (same fields)
    json.dump(S, open(os.path.join(HERE, 'sol_%s.json' % tag), 'w'))
    cert = [{'w': float(dv), 'row': info[i]} for i, dv in enumerate(duals) if abs(dv) > 1e-11]
    json.dump(cert, open(os.path.join(HERE, 'cert_%s.json' % tag), 'w'), indent=0)
    log('LP t* = %.12f ; dual rows %d ; wrote sol_%s.json cert_%s.json' % (t, len(cert), tag, tag))
    for c in sorted(cert, key=lambda c: -abs(c['w'])):
        if c['row'][0] in ('senderR2', 'receiverR2', 'receiverV2'): log('  %+.9f %s' % (c['w'], ' '.join(map(str, c['row'][:5]))))
    if L3Q: log('  l3q: q total %.9f, %d q > 0: %s; Q total %.9f' % (sum(LQV.values()), sum(1 for v in LQV.values() if v > 1e-12), sorted(((k, round(v, 9)) for k, v in LQV.items() if v > 1e-12), key=str), sum(LQQ.values())))
    log('  (+ %d cons2 / mrowR2 rows)' % sum(1 for c in cert if c['row'][0] in ('cons2', 'mrowR2')))
    if XO: log('  xo: %d xo > 0 (total %.9f, max %.9f); %d XQ columns, %d mrowX rows in the LP, %d in the cert' % (sum(1 for k, i in cols.items() if k[0] == 'xo' and xv[i] > 1e-12), sum(float(xv[i]) for k, i in cols.items() if k[0] == 'xo'), max([float(xv[i]) for k, i in cols.items() if k[0] == 'xo'] or [0.0]), len(xqsig), sum(1 for r_ in info if r_[0] == 'mrowX'), sum(1 for c in cert if c['row'][0] == 'mrowX')))
def cons2_block(L):
    """dense conservation block of link L over all 5^6 apex words: (matrix, local key list)"""
    terms = []
    for i in range(6):
        if L[i] == 5: terms.append((i, 1.0, [[('g', g2_of(L[(i + 1) % 6], L[(i + 2) % 6], L[(i + 3) % 6], L[(i + 4) % 6], L[(i + 5) % 6], LET[a], LET[b])) for b in range(5)] for a in range(5)]))
    for j in range(6):
        if L[j] >= 7:
            m = tuple(L[(j + i) % 6] for i in range(6))
            terms.append((j, -1.0, [[('h', h2_of(m, LET[a], LET[b])) for b in range(5)] for a in range(5)]))
            if V6 and L[j] == 7: terms.append((j, 1.0, [[('v', v_of(m, LET[a], LET[b])) for b in range(5)] for a in range(5)]))
        if L6R and L[j] == 6:
            if 5 in L: terms.append((j, -1.0, [[('z6', zkey6_ab(L, j, LET[a], LET[b])) for b in range(5)] for a in range(5)]))
            terms.append((j, 1.0, [[('Z6', zsig6_ab(L, j, LET[a], LET[b])) for b in range(5)] for a in range(5)]))
    keys = {}
    for _, _, T in terms:
        for rw in T:
            for k in rw: keys.setdefault(k, len(keys))
    A = np.zeros((len(SALL), len(keys))); rid = np.arange(len(SALL))
    for i, sgn, T in terms:
        I = np.array([[keys[k] for k in rw] for rw in T])
        np.add.at(A, (rid, I[SALL[:, i], SALL[:, (i - 1) % 6]]), sgn)
    return A, list(keys)
def cmd_structR2():
    FLAGS.add('structonly')
    h, cols, info, conset, RW, SR = cmd_solveR2()
    # full conservation system over all L in RW x all 5^6 apex words. h keys are private to one L (the key fixes L),
    # so rank = sum_L rank(H_L) + rank of the stacked g-only consequences of each block.
    allg = {}; allh = set(); allv = set(); nrows = 0; rH = 0; Gstack = []; rL_tot = 0; gonly = set()
    for L in RW:
        A, ks = cons2_block(L)
        U_ = np.unique(A, axis=0); U_ = U_[np.abs(U_).sum(1) > 0]
        hi = [c for c, k in enumerate(ks) if k[0] != 'g']; gi = [c for c, k in enumerate(ks) if k[0] == 'g']
        for k in ks:
            if k[0] == 'g': allg.setdefault(k, len(allg))
            elif k[0] == 'h': allh.add(k)
            else: allv.add(k)
        if not hi:
            for r_ in U_: gonly.add(tuple((ks[c], r_[c]) for c in np.nonzero(r_)[0]))
        else: nrows += len(U_)
        if not len(U_) or not len(ks): continue
        u, sv, vt = np.linalg.svd(U_, full_matrices=False); r = int((sv > 1e-9 * max(1, sv[0])).sum()); B = vt[:r]
        rL_tot += r
        Bh = B[:, hi]
        if hi:
            u2, s2, v2 = np.linalg.svd(Bh, full_matrices=True); r2 = int((s2 > 1e-9 * max(1, s2[0] if len(s2) else 1)).sum())
            N = u2[:, r2:].T            # combos with zero h part
        else: r2 = 0; N = np.eye(r)
        rH += r2
        if len(N):
            Gp = N @ B[:, gi]; G = np.zeros((len(N), 0))
            Gstack.append((Gp, [allg[ks[c]] for c in gi]))
    nrows += len(gonly)
    Gall = np.zeros((sum(len(g) for g, _ in Gstack), len(allg))); o = 0
    for g, idx in Gstack: Gall[o:o + len(g), idx] = g; o += len(g)
    rG = np.linalg.matrix_rank(Gall) if len(Gall) else 0
    sg = set()
    for U in BIGL:
        for t7 in itertools.product(LET, repeat=6):
            wr, sr, sl, wl, wrr, wll = t7
            if not AP and (wrr != 5 or wll != 5): continue
            s_ = sig2_of(U, wr, sr, sl, wl, wrr, wll)
            if F16:   # one signature per allowed-private set seen in some window (s_{j-2}, s_{j+1} free)
                for s0, s3 in itertools.product(LET, repeat=2):
                    x_ = s_ + (amask(U, wll, wl, wr, wrr, s0, sl, sr, s3),)
                    if sig2_keys(x_): sg.add(x_)
                continue
            if sig2_keys(s_): sg.add(s_)
    nm = sum(len(sig2_keys(s_)) for s_ in sg)
    gs = sum(1 for k in cols if k[0] == 'g')
    out = ['s12 structural summary (%s)' % ('full s12 keys' if AP else 'fallback = s10 keys'),
           'registry: %s + RSST-D + L2 (xcap 3)' % os.path.basename(OPT.get('args', '?')).replace('.txt', ''),
           'key counts by type:',
           '  y (five -> big, s1 roots): %d' % len(ROOTS),
           '  g (five -> 6): %d in conservation rows, %d of them read by sender rows' % (len(allg), gs),
           '  h (6 -> big): %d' % len(allh),
           '  M (receiver inflow signatures): %d' % len(sg),
           '  x (big-big, tau codes): lazy',
           '6-types (canonical non-R6 6-links%s): %d' % ('' if V6 else ' with a five', len(RW)),
           'conservation rows (distinct, all 6-types x all apex words): %d' % nrows,
           'conservation rank: %d (= %d from h-blocks + %d g-only)' % (rH + rG, rH, rG),
           '  g-only part: rank %d on %d g keys; g directions left free: %d' % (rG, len(allg), len(allg) - rG),
           'row counts at start of solve: sender %d ; conservation %d (rest by separation) ; M-rows if all used %d ; receivers by separation' % (len(SR), len(conset), nm)]
    if V6:
        vs = set()
        for t7 in itertools.product(LET, repeat=6):
            s_ = sigv_of(7, *t7)
            if F16:
                wr, sr, sl, wl, wrr, wll = t7
                for s0, s3 in itertools.product(LET, repeat=2):
                    x_ = s_ + (amask(7, wll, wl, wr, wrr, s0, sl, sr, s3),)
                    if sigv_keys(x_): vs.add(x_)
                continue
            if sigv_keys(s_): vs.add(s_)
        out.insert(6, '  v (new in s16): %d' % len(allv)); out.insert(7, '  V (new in s16, signatures): %d; V-rows if all used %d' % (len(vs), sum(len(sigv_keys(x)) for x in vs)))
        out[0] = 's16 structural summary (stage 15 class on the reduced 6-centred relay)'
        out = [l.replace('from h-blocks', 'from private blocks') for l in out]
    if ZH:
        zk = set()
        for wd, cf, b in SR: zk.update(k for k in cf if k[0] == 'z')
        out.insert(4, '  z (big -> five, second split): %d' % len(zk))
    open(OPT.get('structout', os.path.join(HERE, 's12_struct%s.txt' % ('' if AP else '_noapex'))), 'w').write('\n'.join(out) + '\n')
    for l in out: log(l)
def lr2_xsolve(eqs):
    """exact sparse Gaussian elimination: eqs = [(dict var->Fraction, rhs)]; free variables 0; None if inconsistent"""
    piv = []
    for e0, r in eqs:
        e = dict(e0)
        for v, pe, pr in piv:
            f = e.pop(v, None)
            if f:
                for u, a in pe.items():
                    if u != v:
                        x = e.get(u, 0) - f * a
                        if x: e[u] = x
                        else: e.pop(u, None)
                r -= f * pr
        if not e:
            if r != 0: return None
            continue
        v = max(e, key=lambda u: (abs(e[u]), -hash(u) % 7))
        a = e[v]; pe = {u: b / a for u, b in e.items()}; piv.append((v, pe, r / a))
    x = {}
    for v, pe, pr in reversed(piv):
        x[v] = pr - sum(a * x.get(u, 0) for u, a in pe.items() if u != v)
    return x
def lr2_exactbasis(RW, capof):
    """s77 (W7 exact.py method, on our own rows): dual LP over the cert's rows (weights w_j with their signs: sender >= 0, receiver/mrow <= 0,
    cons2 free; t-normalisation sum tc_j w_j = 1; uncapped columns tot_k <= 0; capped columns priced at cap via s_k >= tot_k), solved by HiGHS
    simplex, then its optimal basis solved EXACTLY over Fractions.  Returns exact weights (list aligned with RW) or None.  The caller rechecks
    the result with the unchanged exact check (norepair)."""
    try:   # maclane: highspy when installed, else the numpy / scipy shim hshim.py next to pcheck.py (HSHIM_FORCE=1 forces the shim)
        if __import__('os').environ.get('HSHIM_FORCE', '0') not in ('', '0'): raise ImportError('HSHIM_FORCE')
        import highspy
    except ImportError:
        import sys as _hs_sys
        if HERE not in _hs_sys.path: _hs_sys.path.insert(0, HERE)
        import hshim as highspy
    nW = len(RW); colk = {}
    for j, r in enumerate(RW):
        for k in r[3]: colk.setdefault(k, {})[j] = Fraction(r[3][k])
    Ks = sorted(colk, key=str); Cp = [k for k in Ks if capof(k) is not None]; sidx = {k: nW + i for i, k in enumerate(Cp)}
    nV = nW + len(Cp); inf = highspy.kHighsInf
    MU = Fraction(OPT.get('exbmu', '1e-9'))
    lb = np.zeros(nV); ub = np.full(nV, inf); cost = np.zeros(nV)
    for j, r in enumerate(RW):
        kd = r[1]
        if kd == 'senderR2': lb[j], ub[j] = 0.0, inf
        elif kd == 'cons2': lb[j], ub[j] = (-inf, 0.0) if C6LE else (-inf, inf)   # s83
        else: lb[j], ub[j] = -inf, 0.0   # receiverR2, mrow*
        cost[j] = -float(r[5])
    for k in Cp: cost[sidx[k]] = float(capof(k))
    EQ = []   # (dict var -> Fraction, lo, hi) exact rows
    for k in Ks:
        e = dict(colk[k])
        if k in sidx: e[sidx[k]] = Fraction(-1)
        EQ.append((e, None, Fraction(0) if k in sidx else -MU))   # s77: margin MU on uncapped columns (exact rc >= MU > 0 there)
    EQ.append(({j: Fraction(r[4]) for j, r in enumerate(RW) if r[4]}, Fraction(1), Fraction(1)))
    h = highspy.Highs(); h.setOptionValue('output_flag', False); h.setOptionValue('threads', 1)
    h.addVars(nV, lb, ub); h.changeColsCost(nV, np.arange(nV, dtype=np.int32), cost)
    st = []; ix = []; vl = []; lo = []; hi = []
    for e, l_, u_ in EQ:
        st.append(len(ix))
        for v, a in e.items(): ix.append(v); vl.append(float(a))
        lo.append(-inf if l_ is None else float(l_)); hi.append(inf if u_ is None else float(u_))
    h.addRows(len(EQ), np.array(lo), np.array(hi), len(ix), np.array(st, dtype=np.int32), np.array(ix, dtype=np.int32), np.array(vl))
    for o_ in ('primal_feasibility_tolerance', 'dual_feasibility_tolerance'): h.setOptionValue(o_, float(OPT.get('exbtol', '1e-10')))
    h.setOptionValue('solver', 'simplex'); t0 = time.time(); h.run()
    log('EXACTBASIS: dual LP %d vars (%d weights, %d capped s) x %d rows: %s, bound %.12f, %.1fs' % (nV, nW, len(Cp), len(EQ), h.modelStatusToString(h.getModelStatus()), -h.getInfo().objective_function_value, time.time() - t0))
    if h.getModelStatus() != highspy.HighsModelStatus.kOptimal: return None
    Bs = h.getBasis(); BS = highspy.HighsBasisStatus
    basic = [v for v in range(nV) if Bs.col_status[v] == BS.kBasic]
    nonb = [q for q in range(len(EQ)) if Bs.row_status[q] != BS.kBasic]
    log('EXACTBASIS: basic vars %d, nonbasic rows %d' % (len(basic), len(nonb)))
    if len(basic) != len(nonb): return None
    bset = set(basic); eqs = []
    for q in nonb:
        e, l_, u_ = EQ[q]; rhs = u_ if u_ is not None else l_
        eqs.append(({v: a for v, a in e.items() if v in bset}, rhs))
    # singleton peeling, then Gaussian elimination on the core
    t0 = time.time(); x = {}; live = list(range(len(eqs))); E = [dict(e) for e, _ in eqs]; R = [r for _, r in eqs]
    byvar = collections.defaultdict(set)
    for i, e in enumerate(E):
        for v in e: byvar[v].add(i)
    stack = [i for i in range(len(E)) if len(E[i]) == 1]; done = set()
    while stack:
        i = stack.pop()
        if i in done or len(E[i]) != 1: continue
        (v, a), = E[i].items(); x[v] = R[i] / a; done.add(i)
        for i2 in byvar[v]:
            if i2 in done: continue
            a2 = E[i2].pop(v, None)
            if a2 is not None:
                R[i2] -= a2 * x[v]
                if len(E[i2]) == 1: stack.append(i2)
    rest = [(E[i], R[i]) for i in range(len(E)) if i not in done]
    log('EXACTBASIS: %d unknowns by singleton peeling, %d equations left for elimination (%.1fs)' % (len(x), len(rest), time.time() - t0))
    for e, r in rest:
        if not e and r != 0: log('EXACTBASIS: inconsistent'); return None
    xs = lr2_xsolve([(e, r) for e, r in rest if e])
    if xs is None: log('EXACTBASIS: core system inconsistent'); return None
    x.update(xs); log('EXACTBASIS: exact solve done (%.1fs)' % (time.time() - t0))
    return [x.get(j, Fraction(0)) for j in range(nW)]
def cmd_lowerR2():
    """exact check from signed duals (as lowerR): senderR2 >= (w>=0), cons2 = (any sign), mrowR2 h - M <= 0 (w<=0),
    receiverR2 <= (w<=0); rows re-derived from labels; rescale so t's reduced cost is 0; x priced at its cap.
    s44: string weights are exact; tiny float noise on uncapped columns is repaired exactly (see port_repair.py)."""
    load_patterns()
    xon = 'xon' in FLAGS; XCAP = Fraction(OPT.get('xcap', '3')); C = json.load(open(OPT['cert']))
    SR = {(wd, tuple(map(str, b))): cf for wd, cf, b in R2_sender_rows()}
    ok = True; cnt = collections.Counter(); RW = []   # RW: (cert index, kind, w, unit coefficients, t coefficient, D coefficient)
    for ci, c in enumerate(C):
        w = Fraction(c['w']) if isinstance(c['w'], str) else Fraction(c['w']).limit_denominator(int(float(OPT.get('wden', '1e7'))))   # s33: wden=; s44: "p/q" exact
        row = c['row']; cnt[row[0]] += 1; cf = None; tc = 0; dc = 0
        if row[0] == 'senderR2':
            cf = SR.get((row[1], tuple(map(str, row[2]))))
            if cf is None: log('  NOT A SENDER ROW', row); ok = False; continue
            if w < 0: log('  WRONG SIGN', row); ok = False; continue
            tc = 1; dc = 1
        elif row[0] == 'cons2':
            L = tuple(row[1]); s = tuple(row[2])
            if isR6(L) or len(L) != 6 or len(s) != 6 or any(v not in LET for v in L + s): log('  BAD CONS2', row); ok = False; continue
            cf = cons2_coef(L, s)
            if C6LE:   # s83: cf - t <= 0, a <= row: weight <= 0, t coefficient -1, constant 0
                if w > 0: log('  WRONG SIGN', row); ok = False; continue
                tc = -1; dc = 0
        elif row[0] == 'mrowR2':
            sg = tuple(row[1]); k = tuple(row[2])
            g0 = sg[:-1] if F16 else sg
            if F16 and not (0 <= sg[-1] < 32): log('  BAD MASK', row); ok = False; continue
            if len(g0) != (7 if AP else 5) or g0 != sig2_of(*(g0 if AP else g0 + (5, 5))): log('  NONCANON SIG', row); ok = False; continue
            if k not in sig2_keys(sg): log('  BAD MROW', row); ok = False; continue
            if w > 0: log('  WRONG SIGN', row); ok = False; continue
            cf = {('h', k): 1, ('M', sg): -1}
        elif row[0] == 'mrowX':   # s51 51.6
            qq = row[1]; ee = row[2]
            try:
                good = (XO and len(qq) == 4 and qq[0] in (7, 8, 9) and qq[1] in (7, 8, 9) and all(len(z) == 5 and all(v in LET for v in z[:4]) and isinstance(z[4], int) and 1 <= z[4] <= 31 for z in qq[2:])
                        and tuple(qq[2]) <= tuple(qq[3]) and len(ee) == 2 and ee[0] in LET and ee[1] in LET and (qq[2][4] >> LI[ee[0]]) & 1 and (qq[3][4] >> LI[ee[1]]) & 1)
            except TypeError: good = False
            if not good: log('  BAD MROWX', row); ok = False; continue
            if w > 0: log('  WRONG SIGN', row); ok = False; continue
            q = (qq[0], qq[1], tuple(qq[2]), tuple(qq[3]))
            cf = [c_ for c_, e_ in xo_mrows(q) if e_ == list(ee)][0]
        elif row[0] == 'mrowV':
            sg = tuple(row[1]); k = tuple(row[2])
            g0 = sg[:7]
            if g0 != sigv_of(*g0) or len(sg) != (8 if F16 else 7) or k not in sigv_keys(sg): log('  BAD MROWV', row); ok = False; continue
            if w > 0: log('  WRONG SIGN', row); ok = False; continue
            cf = {('V', sg): 1, ('v', k): -1}
        elif row[0] == 'mrowQ':
            sg = tuple(row[1]); k = tuple(row[2])
            if sg != q7sig(*sg) or k not in q7keys(sg): log('  BAD MROWQ', row); ok = False; continue
            if w > 0: log('  WRONG SIGN', row); ok = False; continue
            cf = {('q', k): 1, ('Q', sg): -1}
        elif row[0] == 'mrowZ':
            K = tuple(row[1])
            if not L6R or K not in set(z6_first()): log('  BAD MROWZ', row); ok = False; continue
            if w > 0: log('  WRONG SIGN', row); ok = False; continue
            cf = {('z6', K): 1, ('Z6', zsig6_of_key(K)): -1}
        elif row[0] == 'mrowL':
            sg = tuple(row[1]); k = tuple(row[2])
            if len(sg) == 4 and sg[0] in LQVX and len(k) == 4 and k[0] == sg[0]: sg_, k_ = sg[1:], k[1:]   # s45: V >= 8 label
            else: sg_, k_ = sg, k
            if not L3Q or len(sg_) != 3 or sg_[0] > 6 or sg_[1] > 6 or k_[:2] != sg_[:2] or k_[2] not in l3q_mask_letters(sg_[2]): log('  BAD MROWL', row); ok = False; continue
            if w > 0: log('  WRONG SIGN', row); ok = False; continue
            cf = {('lq', k): 1, ('lQ', sg): -1}
        elif row[0] == 'receiverV2':   # s86 v2r: KEYSPEC v2 realisation row, rebuilt from (d, link, apex, rho) alone (v2r_row)
            if not V2R: log('  receiverV2 ROW WITHOUT THE v2r FLAG', row); ok = False; continue
            try:
                assert len(row) == 5, 'row length'
                d, lk, sv, rho = int(row[1]), row[2], row[3], row[4]
                _v2r_parse_row(d, lk, sv); v2r_rho_parse(rho, d)
            except (AssertionError, TypeError, ValueError) as e_: log('  BAD receiverV2 LABEL', row, e_); ok = False; continue
            why = admissible(d, lk, sv)
            if why: log('  RECEIVER NOT ADMISSIBLE', row, why); ok = False; continue
            if w > 0: log('  WRONG SIGN', row); ok = False; continue
            try: cf = v2r_row(d, lk, sv, rho)
            except AssertionError as e_: log('  BAD receiverV2 ROW', row, e_); ok = False; continue
            tc = -1; dc = d - 6
        elif row[0] == 'receiverR2':
            d, lk, sv = int(row[1]), row[2], row[3]
            if V2R and d in (7, 8): log('  MASKED d = 7 / 8 RECEIVER ROW IN A v2r CERT (stronger than the v2 row, KEYSPEC2 4.5; not allowed)', row); ok = False; continue
            why = admissible(d, lk, sv)
            if why: log('  RECEIVER NOT ADMISSIBLE', row, why); ok = False; continue
            if w > 0: log('  WRONG SIGN', row); ok = False; continue
            tau = None
            if FY2:   # s43: the cell must be one of the row's cells
                cm = dict(fy2_cells(d, [int(ch) for ch in lk], [int(ch) for ch in sv]))
                if len(row) != 5 or row[4] not in cm: log('  BAD CELL', row); ok = False; continue
                tau = cm[row[4]]
            cf = recv_coef_R2(d, lk, sv, xon, tau); tc = -1; dc = d - 6
        else: log('  UNKNOWN', row); ok = False; continue
        RW.append((ci, row[0], w, cf, tc, dc))
    UCAP = Fraction(OPT['ucap']) if 'ucap' in OPT else None
    def capof(k):   # the cap a family is priced at, None if uncapped
        if k[0] in ('x', 'xo'): return XCAP   # s51: xo priced at xcap as x
        if k[0] == 'D': return Fraction(OPT.get('dcap', '3'))   # stage 24: D is capped like x (RELAY_SPEC 19.5)
        if k[0] == 'fb' and FBCAP is not None: return Fraction(OPT['fbcap'])   # s44: fb priced at its cap when capped
        if k[0] == 'lq': return Fraction(OPT.get('lqcap', '3'))   # stage 28
        if ZR and k[0] in ('z', 'zr', 'rr'): return Fraction(OPT.get('zcap', '3'))   # stage 33
        if k[0] == 'z6': return Fraction(OPT.get('z6cap', '3'))   # RELAY_SPEC_s23.5
        if k[0] == 'q' and Q7CAP is not None: return Fraction(OPT['q7cap'])   # 5 Nov (Team C): q is boxed at q7cap in solveR2, so price it there (bound is for the capped LP, like z/zr/rr)   [s78: ported from s75 18:09Z]
        if k[0] == 'ks': return Fraction(OPT.get('kscap', '3'))   # s78 K*
        return UCAP   # s33 ucap=: every other column priced at UCAP (only if the LP family had that cap)
    def evaluate(ws):
        tot = collections.defaultdict(Fraction); tco = Fraction(0); D = Fraction(0)
        for (ci, kd, w0, cf, tc, dc), w in zip(RW, ws):
            for k, v in cf.items(): tot[k] += w * v
            tco += w * tc; D += w * dc
        return tot, tco, D
    if 'exactbasis' in FLAGS and ok:   # s77: replace the float weights by the exact optimal-basis weights of the support dual LP, then recheck unchanged (norepair)
        XW = lr2_exactbasis(RW, capof)
        if XW is None: log('LOWER-R2: INVALID (exactbasis failed)'); return
        C2 = [dict(C[r[0]], w=str(w)) for r, w in zip(RW, XW) if w != 0]
        out = re.sub(r'\.json$', '', OPT['cert']) + '_exb.json'; json.dump(C2, open(out, 'w'))
        log('EXACTBASIS: exact cert (%d nonzero rows) written to %s; rechecking it from the file (norepair)' % (len(C2), out))
        OPT['cert'] = out; FLAGS.discard('exactbasis'); FLAGS.add('norepair'); cmd_lowerR2(); return
    WS = [r[2] for r in RW]
    tot, tco, D = evaluate(WS)
    if tco <= 0: log('  t coefficient sum not positive'); ok = False; tco = Fraction(1)
    def price(tot, tco, D):
        D = D / tco; neg = []; nu = 0; du = Fraction(0)
        for k, v in tot.items():
            rc = -v / tco
            if k[0] == 'XQ':   # s51: XQ in [-xcap, xcap], priced at its box
                D -= XCAP * abs(rc); continue
            if rc < 0:
                cp = capof(k)
                if cp is not None:
                    D += rc * cp
                    if UCAP is not None and cp is UCAP: nu += 1; du += rc * UCAP
                else: neg.append((k, rc))
        if UCAP is not None: log('  ucap=%s: %d uncapped columns priced at cap, total %.3g' % (UCAP, nu, float(du)))
        return D, neg
    Dp, neg = price(tot, tco, D)
    if neg: log('  negative reduced costs:', len(neg), sorted(neg, key=lambda kv: kv[1])[:5])
    if 'q7rc' in FLAGS: log('  q7rc: q columns by reduced cost (min convention):', sorted(((''.join(map(str, k[1])), str(-v / tco)) for k, v in tot.items() if k[0] == 'q'), key=lambda kv: Fraction(kv[1]))[:12], '| nonzero q rc:', sum(1 for k, v in tot.items() if k[0] == 'q' and v != 0))
    log('rows by type: %s' % dict(cnt))
    rep = ok and neg and 'norepair' not in FLAGS
    log('LOWER-R2%s: %s  t >= %s = %.9f  (%d rows)' % (' (unrepaired)' if rep else '', 'VALID' if ok and not neg else 'INVALID', Dp, float(Dp), len(C)))
    if not rep: return
    # s44 repair: only uncapped columns with tiny negative rc; only free (cons2) and strictly negative mrow* weights move.
    TOL = Fraction(OPT.get('reptol', '1e-9')); RMAX = Fraction(OPT.get('repmax', '1e-6'))
    worst = min(rc for _, rc in neg)
    if worst < -TOL: log('REPAIR: refused (worst rc %.3g beyond reptol %s)' % (float(worst), OPT.get('reptol', '1e-9'))); log('LOWER-R2: INVALID  t >= %s = %.9f  (%d rows)' % (Dp, float(Dp), len(C))); return
    adj = [j for j, r in enumerate(RW) if (r[1] == 'cons2' and (not C6LE or r[2] < 0)) or (r[1].startswith('mrow') and r[2] < 0)]
    if 'repall' in FLAGS: adj = [j for j, r in enumerate(RW) if (r[1] == 'cons2' and (not C6LE or r[2] < 0)) or ((r[1].startswith('mrow') or r[1] in ('receiverR2', 'receiverV2')) and r[2] < 0) or (r[1] == 'senderR2' and r[2] > 0)]; adj = [j for j in adj if RW[j][1] == 'cons2' or abs(RW[j][2]) >= Fraction(OPT.get('repwmin', '0'))]   # s77: repall (repwmin=: only weights of at least this size move) also moves receiver (w<0) / sender (w>0) weights; signs re-checked below, final check unchanged (norepair rerun)
    colrows = collections.defaultdict(dict)
    for j in adj:
        for k, v in RW[j][3].items():
            if v: colrows[k][j] = Fraction(v)
    tot0 = tot; E = {}; ws = None
    for rnd in range(30):
        for k, _ in neg: E[k] = True
        eqs = [(colrows.get(k, {}), -tot0[k]) for k in E]
        x = lr2_xsolve(eqs)
        if x is None: log('REPAIR: round %d: no exact solution on %d columns' % (rnd, len(E))); break
        big = max([abs(v) for v in x.values()] or [0])
        if big > RMAX: log('REPAIR: round %d: largest weight move %.3g beyond repmax' % (rnd, float(big))); x = None; break
        ws = list(WS)
        for j, v in x.items(): ws[j] += v
        if any(RW[j][1].startswith('mrow') and ws[j] > 0 for j in x): log('REPAIR: round %d: an mrow weight would change sign' % rnd); x = None; break
        if any(((RW[j][1] in ('receiverR2', 'receiverV2') and ws[j] > 0) or (RW[j][1] == 'senderR2' and ws[j] < 0)) for j in x): log('REPAIR: round %d: a receiver/sender weight would change sign' % rnd); x = None; break   # s77 repall
        tot, tco, D = evaluate(ws); Dr, neg = price(tot, tco, D)
        log('REPAIR: round %d: %d columns pinned to rc 0, %d weights moved (max %.3g); %d negative columns left' % (rnd, len(E), len(x), float(big), len(neg)))
        if not neg: break
        if min(rc for _, rc in neg) < -TOL: x = None; log('REPAIR: round %d: a moved column went beyond reptol' % rnd); break
    if x is None or neg: log('LOWER-R2: INVALID  t >= %s = %.9f  (%d rows; repair failed)' % (Dp, float(Dp), len(C))); return
    C2 = json.loads(json.dumps(C))
    for (ci, kd, w0, cf, tc, dc), w in zip(RW, ws): C2[ci]['w'] = str(w)
    out = re.sub(r'\.json$', '', OPT['cert']) + '_rep.json'; json.dump(C2, open(out, 'w'))
    log('REPAIR: exact cert written to %s; rechecking it from the file (norepair)' % out)
    OPT['cert'] = out; FLAGS.add('norepair'); cmd_lowerR2()
def all6_words():
    out = set()
    for L in itertools.product(LET, repeat=6):
        c = canon6(L)
        if c not in out and not isR6(c): out.add(c)
    return sorted(out)
def cmd_upperR2():
    load_patterns()
    xon = 'xon' in FLAGS
    p = os.path.join(WORK, 'clsR2_%d%s%s%s%s%s%s.bin' % (int(xon), 'z' if ZH else '', 'y' if FY else '', 'f' if F16 else '', 'h' if H5 else '', 'D' if DD else '', 'o' if XO else '') + (('g' + GKMD5) if GKON else ''))
    if not os.path.exists(p): class_table_R2(xon).tofile(p)
    CLSFILE[0] = p
    Sj = json.load(open(OPT['sol'])); t = Sj['t']
    y = np.zeros(len(ROOTS))
    for k, v in Sj['y'].items():
        u, rest = k.split('|'); r_ = root(list((int(u),) + tuple(int(c) for c in rest)), 0); y[RIX[r_]] = v
    GV = {tuple(k): v for k, v in Sj['g']}; HV2 = {tuple(k): v for k, v in Sj['h']}
    ZV.clear(); ZV.update({tuple(k): v for k, v in Sj.get('z', [])})
    if Sj.get('z') and not ZH: log('SOLUTION HAS z BUT zh FLAG OFF'); return
    if bool(Sj.get('fy2', False)) != FY2: log('fy2 FLAG DIFFERS FROM THE SOLUTION (level-1 and level-2 z keys differ in h2)'); return
    ZRV.clear(); ZRV.update({tuple(k): v for k, v in Sj.get('zr', [])})
    if Sj.get('zr') and not ZR: log('SOLUTION HAS zr BUT zr FLAG OFF'); return
    Z6V.clear(); Z6V.update({tuple(k): v for k, v in Sj.get('z6', [])}); Z6W.clear(); Z6W.update({tuple(k): v for k, v in Sj.get('Z6', [])})
    if (Sj.get('z6') or Sj.get('Z6')) and not L6R: log('SOLUTION HAS z6 BUT l6r FLAG OFF'); return
    if any(v < 0 or v > Z6CAP + 1e-9 for v in Z6V.values()) or any(v < 0 for v in Z6W.values()): log('z6 VALUE OUTSIDE [0, z6cap] or Z6 < 0'); return
    if L6R:
        nz = sum(1 for K, v in Z6V.items() if v > Z6W.get(zsig6_of_key(K), 0.0) + 1e-9)
        bz = sum(1 for K in Z6V if K not in set(z6_first()))
        log('l6r: %d z6 > 0 (total %.9f), %d Z6 > 0; mrowZ violated %d; z6 keys outside the first family %d' % (len(Z6V), sum(Z6V.values()), len(Z6W), nz, bz))
        if nz or bz: log('UPPER-R2: INFEASIBLE (mrowZ)'); return
    if ZR and any(v < 0 or v > ZCAP + 1e-9 for v in list(ZV.values()) + list(ZRV.values()) + [v_ for k_, v_ in Sj.get('rr', [])]): log('z / zr / rr VALUE OUTSIDE [0, zcap]'); return
    QV.clear(); QV.update({tuple(k): v for k, v in Sj.get('q', [])})
    if Sj.get('q') and not Q7: log('SOLUTION HAS q BUT q7 FLAG OFF'); return
    if bool(Sj.get('q7m', False)) != Q7M: log('q7m FLAG DIFFERS FROM THE SOLUTION'); return
    if Q7: log('bonus links: %d' % write_bonus())
    VV.clear(); VV.update({tuple(k): v for k, v in Sj.get('v', [])})
    if Sj.get('v') and not V6: log('SOLUTION HAS v BUT v6 FLAG OFF'); return
    RV.clear(); RV.update({tuple(k): v for k, v in Sj.get('r', [])})
    if Sj.get('r') and not H5: log('SOLUTION HAS r BUT hat5 FLAG OFF'); return
    RRV.clear(); RRV.update({tuple(k): v for k, v in Sj.get('rr', [])})
    if Sj.get('rr') and not HRR: log('SOLUTION HAS rr BUT hatrr FLAG OFF'); return
    DV.clear(); DV.update({eval(k): v for k, v in Sj.get('D', [])})
    if Sj.get('D') and not DD: log('SOLUTION HAS D BUT big2 FLAG OFF'); return
    if any(v < 0 or v > DCAP + 1e-9 for v in DV.values()): log('D VALUE OUTSIDE [0, dcap]'); return
    LQV.clear(); LQV.update({tuple(k): v for k, v in Sj.get('lq', [])}); LQQ.clear(); LQQ.update({tuple(k): v for k, v in Sj.get('lQ', [])})
    if (Sj.get('lq') or Sj.get('lQ')) and not L3Q: log('SOLUTION HAS lq BUT l3q FLAG OFF'); return
    FBV.clear(); FBV.update({tuple(k): v for k, v in Sj.get('fb', [])})
    if Sj.get('fb') and not FB: log('SOLUTION HAS fb BUT fb FLAG OFF'); return
    if FBCAP is not None and any(v > FBCAP + 1e-9 for v in FBV.values()): log('fb VALUE ABOVE fbcap'); return
    if any(v < 0 or v > LQCAP + 1e-9 for v in LQV.values()) or any(v < 0 for v in LQQ.values()): log('lq VALUE OUTSIDE [0, lqcap]'); return
    _bk = [k for k in LQV if len(k) != 3 and not (len(k) == 4 and k[0] in LQVX and k[1] in (5, 6) and k[2] in (5, 6) and k[3] in LET)]
    _bk += [k for k in LQQ if len(k) != 3 and not (len(k) == 4 and k[0] in LQVX and k[1] in (5, 6) and k[2] in (5, 6) and 0 <= k[3] < 32)]
    if _bk: log('SOLUTION HAS lq / lQ KEYS OF A FAMILY THAT IS OFF OR MALFORMED (l3qV=%s): %s' % (','.join(map(str, LQVS)), _bk[:5])); return   # s47
    if LQVX: log('l3qV: %d V >= 8 q > 0 (total %.9f), %d V >= 8 Q > 0%s' % (sum(1 for k in LQV if len(k) == 4), sum(v for k, v in LQV.items() if len(k) == 4), sum(1 for k in LQQ if len(k) == 4), ' (BROKEN-SIGN CONTROL)' if LQBROKEN else ''))
    if L3Q: write_l3q(); log('l3q: %d q > 0 (total %.9f); Q taken as max(sol, max q over mask) for every mask' % (len(LQV), sum(LQV.values())))
    FV.clear(); FV.update({tuple(k): v for k, v in Sj.get('f', [])})
    if Sj.get('f') and not F5: log('SOLUTION HAS f BUT face5 FLAG OFF'); return
    KSV.clear(); KSV.update({str(k): float(v) for k, v in Sj.get('ks', [])})   # s78 K*
    if KSV.get('K1', 0.0) != 0.0 and not KSTAR: log('SOLUTION HAS ks BUT kstar FLAG OFF'); return
    if any(k != 'K1' and v != 0.0 and k not in EGNAMES and k not in GKNAMES for k, v in KSV.items()): log('SOLUTION HAS ks KEYS NOT IN edgekeys: %s' % sorted(KSV)); return
    if any(v < 0 or v > KSCAP + 1e-9 for v in KSV.values()) and 'ksnorange' not in FLAGS: log('ks VALUE OUTSIDE [0, kscap]: %s' % KSV); log('UPPER-R2: INFEASIBLE (ks range)'); return
    if EGNAMES: log('edgekeys: amounts %s (cap %g)' % (' '.join('%s = %.12f' % (k_, KSV.get(k_, 0.0)) for k_ in EGNAMES), KSCAP))
    if KSTAR: log('kstar: K1 = %.12f (cap %g)%s' % (KSV.get('K1', 0.0), KSCAP, ' (CONTROL ksplant: python payee mask without f2b extra7)' if KSPLANT else ' (CONTROL ksnowin: no window bound)' if KSNOWIN else ''))
    xd = {int(k): v for k, v in Sj.get('x', {}).items()}
    XOV.clear(); XOV.update({int(k): v for k, v in Sj.get('xo', {}).items()})   # s51 51.5
    if XOV and not XO: log('SOLUTION HAS xo BUT xo FLAG OFF'); return
    if XO and xd: log('SOLUTION HAS OLD x BUT xo FLAG ON'); return
    if XO and not Sj.get('xoflag'): log('SOLUTION WAS NOT SOLVED WITH xo'); return
    if any(v < 0 or v > float(OPT.get('xcap', '3')) + 1e-9 for v in XOV.values()): log('xo VALUE OUTSIDE [0, xcap]'); return
    if XO: log('xo: %d xo > 0 (total %.9f, max %.9f); XQ taken as max over the candidates%s' % (len(XOV), sum(XOV.values()), max(XOV.values() or [0.0]), ' (BROKEN %s CONTROL)' % XOB if XOB else ''))
    if any(v < 0 for v in list(GV.values()) + list(HV2.values()) + list(y) + list(FV.values()) + list(RV.values()) + list(RRV.values()) + list(ZV.values()) + list(ZRV.values())): log('NEGATIVE VALUE'); bad_neg = 1
    else: bad_neg = 0
    bad = 0
    for wd, cf, bits in R2_sender_rows():
        v = sum(c * (y[RIX[k[1]]] if k[0] == 'y' else KSV.get(k[1], 0.0) if k[0] == 'ks' else ZV.get(k[1], 0.0) if k[0] == 'z' else ZRV.get(k[1], 0.0) if k[0] == 'zr' else FV.get(k[1], 0.0) if k[0] == 'f' else RV.get(k[1], 0.0) if k[0] == 'r' else RRV.get(k[1], 0.0) if k[0] == 'rr' else GV.get(k[1], 0.0)) for k, c in cf.items())
        if v < 1 - t - EPS: bad += 1
    log('sender rows violated: %d' % bad); bad += bad_neg
    nc = 0; worst = 0.0; A6 = all6_words(); NEG6 = [0, 0.0]
    for L in A6:   # every non-R6 6-arrangement, with or without a five, every apex word
        Dl = cons2_delta(L, GV, HV2); m = max(0.0, float(Dl.max()) - t) if C6LE else float(np.abs(Dl).max()); worst = max(worst, m)
        if C6LE and float(Dl.min()) < -1e-9: NEG6[0] += 1; NEG6[1] = min(NEG6[1], float(Dl.min()))   # s83: a 6 that ends strictly below 0
        if m > 1e-9:
            nc += 1
            if nc <= 8: log("  cons off: L=%s five=%s worst %.4g" % (L, 5 in L, m))
    if C6LE: log('conservation (c6le: 6 ends <= t): %d canonical non-R6 links x 5^6 apex words; links with in - out > t + 1e-9: %d (worst excess %.3g); links where some 6 ends below 0: %d (lowest in - out %.6g)' % (len(A6), nc, worst, NEG6[0], NEG6[1]))
    else: log('conservation: %d canonical non-R6 links x 5^6 apex words; links with |in - out| > 1e-9: %d (worst %.3g)' % (len(A6), nc, worst))
    bad += nc
    mcache = {}
    def MV2(sg):
        if sg not in mcache:
            ks = sig2_keys(sg); mcache[sg] = max(HV2.get(k, 0.0) for k in ks) if ks else None
        return mcache[sg]
    F2B_MV2[0] = MV2
    if 'f2bself' in OPT: f2b_selftest(y, xd, MV2, t, int(OPT['f2bself'])); return
    if 'ksdump' in OPT: ks_dump(y, xd, MV2, t); return   # s78: K* / EDGE row-value dump (eng/ksdump.py)
    for d in range(7, DMAX + 1):
        W = window_table_R2(min(d, 9), y, xd, MV2)
        res, dt, ni = run_sep(d, W, d - 6 + t + EPS, int(float(OPT.get('vK', '20'))), 0)   # s33z (from s30t): vK = max rows reported
        v = [r for r in res if r[0] == 'V']; bad += len(v)
        log('d=%d: %d violated (exhaustive, %.1fs)' % (d, len(v), dt))
        if 'vfile' in OPT:   # s33z: every reported violated row to a file: d load excess link sv
            with open(OPT['vfile'], 'a') as vf:
                for r_ in v: vf.write('%d %s %.9f %s %s\n' % (d, r_[1], float(r_[1]) - (d - 6 + t), r_[2], r_[3]))
    W9 = window_table_R2(9, y, xd, MV2); M = relaxed_M(W9)
    for d in range(DMAX + 1, DTAIL + 1):
        v = closed_max(M, d)
        if v > d - 6 + t + EPS:
            res, dt, ni = run_sep(d, W9, d - 6 + t + EPS, 20, 0, pats=False); nv = sum(1 for r in res if r[0] == 'V'); bad += nv
            log('d=%d relaxed %.6f > cap; exact pattern-free: %d violated' % (d, v, nv))
    lam = karp(M); d0 = (6 - t) / (1 - lam) if lam < 1 else 1e9
    log('Karp lambda %.9f d0 %.3f' % (lam, d0))
    if d0 > DTAIL + 1: bad += 1
    log('UPPER-R2: %s at t = %.12f' % ('FEASIBLE' if bad == 0 else 'INFEASIBLE (%d)' % bad, t))
def cmd_ctxR2():
    """sender rows of the listed words in the context 'all hats and fans big' (bits all 1): value breakdown"""
    Sj = json.load(open(OPT['sol'])); t = Sj['t']
    GV = {tuple(k): v for k, v in Sj['g']}; YV = Sj['y']; GV.update({tuple(k): v for k, v in Sj.get('z', [])})
    def yv(r_): return YV.get(rname(r_), 0.0)
    for wd, cf, bits in R2_sender_rows():
        if wd not in OPT.get('words', '55677,56687').split(',') : continue
        b = [x for x in bits if x != '|']
        if not all(x == 1 for x in b): continue
        parts = ['%s%s=%.5f' % (k[0], ''.join(map(str, k[1])) if k[0] in 'gz' else rname(k[1]), (yv(k[1]) if k[0] == 'y' else GV.get(k[1], 0.0))) for k in cf]
        tot = sum(c * (yv(k[1]) if k[0] == 'y' else GV.get(k[1], 0.0)) for k, c in cf.items())
        log('%s all-big ring: total %.5f vs 1-t %.5f  %s' % (wd, tot, 1 - t, ' '.join(parts)))
def cmd_consbasisR2():
    """per 6-type L: a maximal independent set of actual conservation rows (L, s) (QR with column pivoting on A_L^T);
    together they imply every (L, s) row. Written as JSON [[L, s], ...]."""
    import scipy.linalg as sla
    out = []; tot = 0
    for L in (all6_words() if V6 else relay_words()):
        A, ks = cons2_block(L)
        U_, idx = np.unique(A, axis=0, return_index=True)
        keep = np.abs(U_).sum(1) > 0; U_ = U_[keep]; idx = idx[keep]
        if not len(U_): continue
        R, P = sla.qr(U_.T, mode='r', pivoting=True)
        dg = np.abs(np.diag(R)); r = int((dg > 1e-9 * max(1.0, dg[0])).sum())
        for q in P[:r]: out.append([list(L), [LET[v] for v in SALL[idx[q]]]])
        tot += r
    json.dump(out, open(OPT.get('out', os.path.join(HERE, 'cons2basis.json')), 'w'))
    log('conservation basis: %d rows over %d 6-types' % (tot, len(all6_words() if V6 else relay_words())))
def cmd_rowR2():
    """one receiver row at a solution: each term's value, load vs cap, slack, and its dual weight in cert"""
    load_patterns(); xon = 'xon' in FLAGS
    Sj = json.load(open(OPT['sol'])); t = Sj['t']; d = int(OPT['d']); lk = OPT['lk']; sv = OPT['sv']
    YV = Sj['y']; HV2 = {tuple(k): v for k, v in Sj['h']}; ZV.clear(); ZV.update({tuple(k): v for k, v in Sj.get('z', [])})
    XOV.clear(); XOV.update({int(k): v for k, v in Sj.get('xo', {}).items()})   # s51
    XV = {int(k): v for k, v in Sj.get('x', {}).items()}; QV.clear(); QV.update({tuple(k): v for k, v in Sj.get('q', [])}); VV.clear(); VV.update({tuple(k): v for k, v in Sj.get('v', [])})
    KSV.clear(); KSV.update({str(k): float(v) for k, v in Sj.get('ks', [])})   # s78
    def MV2(sg):
        ks = sig2_keys(sg); return max(HV2.get(k, 0.0) for k in ks) if ks else 0.0
    tot = 0.0; parts = []
    for k, c in sorted(recv_coef_R2(d, lk, sv, xon).items(), key=str):
        v = KSV.get(k[1], 0.0) if k[0] == 'ks' else xo_eff(k[1]) if k[0] == 'XQ' else YV.get(rname(k[1]), 0.0) if k[0] == 'y' else dict((tuple(a), b) for a, b in Sj.get('r', [])).get(k[1], 0.0) if k[0] == 'r' else dict((tuple(a), b) for a, b in Sj.get('rr', [])).get(k[1], 0.0) if k[0] == 'rr' else dict((eval(a), b) for a, b in Sj.get('D', [])).get(k[1], 0.0) if k[0] == 'D' else ZV.get(k[1], 0.0) if k[0] == 'z' else XV.get(k[1], 0.0) if k[0] == 'x' else QV.get(k[1], 0.0) if k[0] == 'q' else VV.get(k[1], 0.0) if k[0] == 'v' else min([VV.get(kk, 0.0) for kk in sigv_keys(k[1])] or [0.0]) if k[0] == 'V' else max([QV.get(kk, 0.0) for kk in q7keys(k[1])] or [0.0]) if k[0] == 'Q' else MV2(k[1])
        tot += c * v
        if abs(c * v) > 1e-12: parts.append('%s%s:%+g*%.5f' % (k[0], rname(k[1]) if k[0] == 'y' else ''.join(map(str, k[1])) if k[0] != 'x' else k[1], c, v))
    w = 0.0
    if 'cert' in OPT:
        for c in json.load(open(OPT['cert'])):
            if c['row'][0] == 'receiverR2' and int(c['row'][1]) == d and c['row'][2] == lk and c['row'][3] == sv: w = c['w']
    log('row d=%d %s/%s: load %.9f cap %.9f slack %.3g dual %.9f admissible=%s' % (d, lk, sv, tot, d - 6 + t, d - 6 + t - tot, w, admissible(d, lk, sv)))
    log('  terms: ' + ' '.join(parts))
def _canon_row(d, lk, sv):
    """(link, sv) up to the 2d rotations / reflections (w_i -> w_{-i}, s_i -> s_{-i-1}, as pcheck instances)"""
    out = []
    for r in range(d):
        for refl in (False, True):
            W_ = [None] * d; S_ = [None] * d
            for i in range(d):
                j = (i + r) % d if not refl else (r - i) % d; W_[j] = lk[i]
                j = (i + r) % d if not refl else (r - i - 1) % d; S_[j] = sv[i]
            out.append((''.join(W_), ''.join(S_)))
    return min(out)
def cmd_binderR2():
    """s33z: for receiver rows row=d:link:sv[,..] -> the row's dual in cert= (rank by |w|) and the load split by column family in sol=;
    plus the top receiver binders of the cert (top=N)."""
    load_patterns(); xon = 'xon' in FLAGS
    Sj = json.load(open(OPT['sol'])); t = Sj['t']; C = json.load(open(OPT['cert'])) if 'cert' in OPT else []
    VAL = {('y', k): v for k, v in Sj['y'].items()}
    for fam in ('g', 'h', 'z', 'zr', 'r', 'rr', 'lq', 'lQ', 'z6', 'Z6', 'q', 'f', 'fb'):
        for k, v in Sj.get(fam, []): VAL[(fam, tuple(k))] = v
    for k, v in Sj.get('D', []): VAL[('D', eval(k))] = v
    for k, v in Sj.get('x', {}).items(): VAL[('x', int(k))] = v
    XOV.clear(); XOV.update({int(k): v for k, v in Sj.get('xo', {}).items()})   # s51
    HV2 = {tuple(k): v for k, v in Sj['h']}
    if L3Q: l3q_load()
    def val(k):
        if k[0] == 'y': return VAL.get(('y', rname(k[1])), 0.0)
        if k[0] == 'M': return max([HV2.get(tuple(h), 0.0) for h in sig2_keys(k[1])] or [0.0])
        if k[0] == 'XQ': return xo_eff(k[1])   # s51
        return VAL.get(k, 0.0)
    GRP = {'XQ': 'xo XQ', 'y': 'base y', 'x': 'base x', 'M': 'base M (hat6)', 'r': 'hat5 r', 'rr': 'RR rr', 'z': 'zh z', 'zr': 'ZR zr', 'lq': 'l3q lq', 'lQ': 'l3q lQ', 'D': 'D', 'Q': 'q7', 'q': 'q7', 'V': 'v6'}
    rec = [(c['w'], c['row']) for c in C if c['row'][0] == 'receiverR2']
    rk = sorted(rec, key=lambda x: x[0])   # receiver duals are <= 0; most negative = strongest binder
    idx = {(r[1],) + _canon_row(r[1], r[2], r[3]): (i, w) for i, (w, r) in enumerate(rk)}
    totw = sum(-w for w, r in rec) or 1.0
    log('cert: %d rows, %d receiverR2 (sum |w| %.6f); t = %.9f' % (len(C), len(rec), totw, t))
    def show(d, lk, sv):
        cf = recv_coef_R2(d, lk, sv, xon); g = collections.defaultdict(float); top = []
        for k, c in cf.items():
            v = val(k)
            if v and c: g[GRP.get(k[0], k[0])] += c * v; top.append((c * v, k))
        tot = sum(g.values()); key = (d,) + _canon_row(d, lk, sv)
        i, w = idx.get(key, (None, 0.0))
        log('row d=%d %s/%s: dual %s%s; load %.9f vs cap %.9f (slack %.3g); admissible: %s' % (d, lk, sv, '%.9g' % w if i is not None else 'not in cert',
            ' (rank %d of %d by |w|, %.2f%% of receiver |w|)' % (i + 1, len(rk), 100 * -w / totw) if i is not None else '', tot, d - 6 + t, d - 6 + t - tot, admissible(d, lk, sv) or 'yes'))
        log('   by family: ' + ', '.join('%s %+.6f' % (a, b) for a, b in sorted(g.items(), key=lambda x: -abs(x[1]))))
        log('   top terms: ' + '; '.join('%s %+.6f' % (repr(k), v) for v, k in sorted(top, key=lambda x: -abs(x[0]))[:12]))
    for spec in [s_ for s_ in OPT.get('row', '').split(',') if s_]:
        d, lk, sv = spec.split(':'); show(int(d), lk, sv)
    for w, r in rk[:int(OPT.get('top', '0'))]: show(r[1], r[2], r[3])
