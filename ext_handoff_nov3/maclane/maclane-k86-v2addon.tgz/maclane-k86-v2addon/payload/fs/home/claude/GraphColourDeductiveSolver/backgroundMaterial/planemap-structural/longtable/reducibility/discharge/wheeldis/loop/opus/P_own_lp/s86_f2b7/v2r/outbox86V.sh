# maclane v2 add-on: v2 lower lane outbox (copy of outbox86L.sh for eng_v2 / outbox/v2lower).  Every time eng_v2/cert_<tag>_p1.json changes (a new lext phase-1 cert), copy it (once it parses as
# JSON and its size is stable) to <outbox>/cert_<tag>_p1_NN_<md5 8>.json, with sol_<tag>_p1.json likewise, refresh K_<tag>.log, and add a
# line to P1.txt: NN  md5  t1 (the latest 'lext it N: phase 1 ... t1 = ...' line of K.log)  iteration  filed-at.  usage: nohup bash outbox86L.sh <tag> &
N=/tmp/maclane-k86/fs/home/claude/GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp/s86_f2b7
PATH=/tmp/maclane-k86/macshim:$PATH; export PATH
TAG=${1:-k86GV1}; O=${OUTBOX_V2:-/tmp/maclane-k86/outbox/v2lower}; mkdir -p $O
C=$N/eng_v2/cert_${TAG}_p1.json; S=$N/eng_v2/sol_${TAG}_p1.json; K=$N/runK_$TAG/K.log
LAST=""; [ -s $O/.last ] && LAST=$(cat $O/.last)
while true; do
  [ -s $K ] && cp $K $O/K_$TAG.log
  grep "lext it .*phase 1" $K 2>/dev/null > $O/P1_lines_$TAG.txt; grep -E "v2inner it|CROWDED" $K 2>/dev/null > $O/V2_lines_$TAG.txt
  if [ -s $C ]; then
    s1=$(wc -c < $C); sleep 10; s2=$(wc -c < $C)
    if [ "$s1" = "$s2" ] && python3 -c "import json,sys; json.load(open(sys.argv[1]))" $C 2>/dev/null; then
      m=$(md5sum $C | awk '{print $1}')
      if [ "$m" != "$LAST" ]; then
        n=$(ls $O | grep -c "^cert_${TAG}_p1_[0-9]*_.*\.json$"); n=$(printf '%02d' $((n + 1)))
        cp $C $O/cert_${TAG}_p1_${n}_$(echo $m | cut -c1-8).json
        [ -s $S ] && cp $S $O/sol_${TAG}_p1_${n}.json
        l=$(grep "lext it .*phase 1" $K | tail -1); it=$(echo "$l" | sed -n 's/.*lext it \([0-9]*\):.*/\1/p'); t1=$(echo "$l" | sed -n 's/.* t1 = \([0-9.e-]*\),.*/\1/p')
        echo "$n    $m    t1 $t1    it $it    $(date -u +%Y-%m-%dT%H:%M:%SZ)" >> $O/P1.txt
        echo $m > $O/.last; LAST=$m
        (cd $O && md5sum $(ls | grep -v '^MD5SUMS$' | grep -v "^K_" | grep -v "^P1_lines" | grep -v "^V2_lines") > MD5SUMS)
        echo "$(date -u +%H:%M:%SZ) [maclane-outboxV-$TAG] filed phase-1 cert $n (md5 $m, it $it, t1 $t1)" >> $N/run.log
      fi
    fi
  fi
  sleep ${OUTBOX_POLL:-60}
done
