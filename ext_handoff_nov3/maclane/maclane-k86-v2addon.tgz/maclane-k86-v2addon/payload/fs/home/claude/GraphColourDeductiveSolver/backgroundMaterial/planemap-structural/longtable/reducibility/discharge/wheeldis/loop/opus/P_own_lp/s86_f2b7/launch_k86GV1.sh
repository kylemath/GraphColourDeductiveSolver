# maclane v2 add-on: KEYSPEC v2 lower lane k86GV1 = the container's launch_k86GV1.sh (78f13aee) with this pack's paths: k86GL6's family on
# args K3gB5b (args_A97_F_W13K3gB5b.txt, container md5 5e399535: K3gB + K5H01 + K5b L1-L3 / U1-U2) with flag v2r on the engine copy eng_v2
# (every d = 7 / 8 receiver is the KEYSPEC v2 max-row, added lazily as realisation rows by an exact max-plus DP; v2r/README.md), keys
# p1r/cg_keys_r13w16_16fik.txt (240; 89 payer-7 keys -> eng_v2/bin/jsepf_gk_k192), seed point v2r/seed_sol_k86GL5_p1.json (e537d18d),
# v2rescan=1, v2inner=$V2INNER (default 4).  Warm = maclane_warm_v2.txt (k86GL6's launch list + k86GL6's own rows at add-on time, the
# container launcher's warm set) + this Mac's k86ML1 rows when non-empty (V2_WARM_ML1=0 skips them; rows the family does not admit are
# dropped on admission).  Only the phase-1 values and phase-1 certs are wanted from the Mac: outbox86V.sh files each new
# eng_v2/cert_<tag>_p1.json into outbox/v2lower.  lowerR2 exactbasis / dual export (watchL86v / dualwatch86v) run in the container, not here.
# GV1 replaces the k86ML1 control lane on the Mac (core budget): stop it first (bash stop.sh lower); ALLOW_ML1=1 overrides the check.
# Knobs (env): V2_THREADS (2), V2INNER (4), MAXIT (200), TAG (k86GV1), V2_WARM_ML1 (1), HSHIM_SOLVER (ipm).
# Requires: install_v2.sh done (eng_v2 binaries), smoke_v2.sh passed (it writes smoke_v2.ok).
R=/tmp/maclane-k86
N=/tmp/maclane-k86/fs/home/claude/GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp/s86_f2b7; B=$(dirname $N)
PATH=$R/macshim:$PATH; export PATH
TAG=${TAG:-k86GV1}; TH=${V2_THREADS:-2}; MI=${MAXIT:-200}; V2I=${V2INNER:-4}
for b in jsepf_gk_k192 jsepf_gk jsep3; do [ -x $N/eng_v2/bin/$b ] || { echo "launch_k86GV1: eng_v2/bin/$b missing: run install_v2.sh first" >&2; exit 2; }; done
[ -f $R/smoke_v2.ok ] || [ "${FORCE:-0}" = 1 ] || { echo "launch_k86GV1: smoke_v2.sh has not passed here (no $R/smoke_v2.ok); FORCE=1 overrides" >&2; exit 2; }
pgrep -f "tag=$TAG " > /dev/null && { echo "launch_k86GV1: a run with tag=$TAG is already going" >&2; exit 3; }
if pgrep -f "tag=k86ML1 " > /dev/null && [ "${ALLOW_ML1:-0}" != 1 ]; then
  echo "launch_k86GV1: the k86ML1 control lane is still running; GV1 replaces it on this Mac (core budget): bash $R/stop.sh lower first (ALLOW_ML1=1 overrides)" >&2; exit 3
fi
export STACK=s77 ARGS=${ARGSV:-$N/args_A97_F_W13K3gB5b.txt} KEYS=${KEYSV:-$N/p1r/cg_keys_r13w16_16fik.txt} FEAS=$N/cand/sol_k85C_in03.json
export XF="c6le f2b7 f2b=$N/rules/A5final/rules_c67fa1d1_plus_A5_twins.json rpatN=$N/rpat/rpatN3_rotation_justified.txt,$N/offc/offc_K3g_2f4f0f02.txt p1r v2r v2seed=$N/v2r/seed_sol_k86GL5_p1.json v2rescan=1 v2inner=$V2I"
WARM=$(cat $N/maclane_warm_v2.txt)
if [ "${V2_WARM_ML1:-1}" != 0 ] && [ -s $N/eng_p1r/rows_k86ML1.txt ]; then
  python3 -c "import sys; b = open(sys.argv[1], 'rb').read(); open(sys.argv[2], 'wb').write(b[:b.rfind(b'\n') + 1])" $N/eng_p1r/rows_k86ML1.txt $N/v2r/rows_k86ML1_snap_$TAG.txt   # complete lines only
  WARM=$WARM,$N/v2r/rows_k86ML1_snap_$TAG.txt
fi
export WARM
echo "$(date -u +%H:%M:%SZ) [maclane] launch $TAG (v2): ARGS $(basename $ARGS) ($(md5sum < $ARGS | cut -c1-8) in this pack), keys $(basename $KEYS) ($(md5sum < $KEYS | cut -c1-8)), threads $TH, v2inner $V2I, $(echo $WARM | tr ',' '\n' | grep -c .) warm files" >> $N/run.log
mkdir -p $N/logs
nohup bash $N/v2r/runK86v.sh $MI $TH $TAG lext lextcert q7pen=1e-3 consk=20 consfrac=0.25 > $N/logs/runK_$TAG.out 2>&1 &
sleep 5
cd $N && nohup bash $N/v2r/outbox86V.sh $TAG > $N/logs/outbox86V_$TAG.out 2>&1 &
sleep 2; echo "launched $TAG: K run log $N/runK_$TAG/K.log, outbox $R/outbox/v2lower/P1.txt, status: bash $R/status_v2.sh"
