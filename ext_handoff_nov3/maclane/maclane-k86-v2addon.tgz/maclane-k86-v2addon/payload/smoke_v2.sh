#!/bin/bash
# maclane v2 add-on smoke test (run after install_v2.sh; about 10 min).  Prints OK / FAIL per step; must end with "SMOKE-V2: PASS".
#  1 the add-on is installed in this (relocated) pack and the eng_v2 binaries are built
#  2 the highspy shim of eng_v2 (hshim 1.1): the 40 reference LPs of tools/hshim_ref.json, and its two new calls (getLp, clearSolver)
#  3 every eng_v2 module parses under this python
#  4 pcheck.py v2rtest (v2r/NOTES.md validation step 1) on the GL5 phase-1 cert def2afcc: 24 / 24 W6b test vectors, and the DP vs p1r_core /
#    brute-force statistics identical to the container's log ref/v2/v2rtest_b2_GL5.log (paths / timings normalised)
#  5 the restricted-LP gate: pcheck.py v2restricted v2mode=v2 on the same cert must reach t = -0.076947399076 (container: 17 LP solves,
#    4790 realisation rows, 174 s with highspy) within 1e-9 (the cutting-plane path may differ here: LPs from scratch with the shim)
#  6 the start of a k86GV1 run (the lane's command, maxit 1, stopped once its patterns are loaded): its log lines up to "patterns:"
#    identical to the container's k86GV1 setup smoke (ref/v2/smoke_GV1.log).  SMOKE_V2_HEAD=0 skips.
# Writes smoke_v2.ok on PASS (launch_v2.sh requires it).  Logs: smoke_v2.log, smoke_v2_*.log.
R=/tmp/maclane-k86
B=$R/fs/home/claude/GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp; N=$B/s86_f2b7; NN=$N
CERT=$R/fs/mnt/project-files/swarm/round6/W12-studio-K/from_opus/s86_k86GL5/cert_p1_00_def2afcc.json
PATH=$R/macshim:$PATH; export PATH
NF=0; LOG=$R/smoke_v2.log; E=$N/eng_v2; TV=-0.076947399076
say() { echo "$*" | tee -a $LOG; }
ok() { say "   OK   $*"; }
bad() { say "   FAIL $*"; NF=$((NF + 1)); }
: > $LOG; rm -f $R/smoke_v2.ok
say "maclane v2 add-on smoke $(date -u +%Y-%m-%dT%H:%M:%SZ) on $(uname -sm)"

say "1. add-on installed"
HERE=$(cd "$(dirname "$0")" && pwd -P); MISS=""
for b in jsepf_gk_k192 jsepf_gk jsep3; do [ -x $E/bin/$b ] || MISS="$MISS eng_v2/bin/$b"; done
for f in $E/v2r.py $E/hshim.py $N/v2r/runK86v.sh $N/v2r/outbox86V.sh $N/launch_k86GV1.sh $N/args_A97_F_W13K3gB5b.txt $N/maclane_warm_v2.txt $N/v2r/seed_sol_k86GL5_p1.json $CERT $R/ref/v2/v2rtest_b2_GL5.log; do [ -s $f ] || MISS="$MISS $(basename $f)"; done
if [ "$(cd $R 2>/dev/null && pwd -P)" != "$HERE" ]; then bad "the scripts point at $R but smoke_v2.sh is in $HERE: run install_v2.sh (and relocate.sh) first"; echo "smoke_v2: stopping"; exit 1
elif [ -n "$MISS" ]; then bad "missing:$MISS (run install_v2.sh)"; echo "smoke_v2: stopping"; exit 1
else ok "eng_v2 ($(grep -o "hshim-[0-9.]*" $E/hshim.py | head -1)), binaries jsepf_gk_k192 jsepf_gk jsep3, lane scripts, args K3gB5b, seed, gate cert"; fi

say "2. eng_v2 shim"
if HSHIM_QUIET=1 python3 $R/tools/hshim_check.py $E $R/tools/hshim_ref.json > $R/smoke_v2_hshim.log 2>&1 && python3 $R/tools/v2shimcheck.py $E >> $R/smoke_v2_hshim.log 2>&1; then
  ok "$(grep '^\[ipm\]' $R/smoke_v2_hshim.log | cut -c1-110); $(grep '^\[getLp' $R/smoke_v2_hshim.log)"
else bad "see $R/smoke_v2_hshim.log"; tail -5 $R/smoke_v2_hshim.log | tee -a $LOG; fi

say "3. eng_v2 modules parse"
if python3 -c "
import ast, sys
for f in sys.argv[1:]: ast.parse(open(f).read(), f)
print(len(sys.argv) - 1)" $E/*.py > $R/smoke_v2_parse.log 2>&1; then ok "$(cat $R/smoke_v2_parse.log) files"; else bad "$(tail -3 $R/smoke_v2_parse.log)"; fi

# the container's v2r_run.sh environment: K3g args, 16fi keys (220), c6le f2b7 rules c67fa1d1, rpatN3 + offc_K3g, threads 1
export STACK=s77 ARGS=$N/args_A97_F_W13K3g.txt KEYS=$N/p1r/cg_keys_r13w16_16fi.txt FAM=full KS=0; unset EGK; . $NN/env86.sh; N=$NN
XFT="c6le f2b7 f2b=$N/rules/A5final/rules_c67fa1d1_plus_A5_twins.json rpatN=$N/rpat/rpatN3_rotation_justified.txt,$N/offc/offc_K3g_2f4f0f02.txt"
WK=$SD/v2smoke_$$; mkdir -p $WK

say "4. v2rtest on the GL5 cert def2afcc (about 2-3 min)"
T0=$(date +%s)
(cd $E && nice -n 12 python3 pcheck.py v2rtest $F $X $A threads=1 work=$WK gkeys=$KEYS gkwin gkleaf $XFT v2r cert=$CERT > $R/smoke_v2_test.log 2>&1)
if python3 $R/tools/cmp_v2.py $R/ref/v2/v2rtest_b2_GL5.log $R/smoke_v2_test.log "V2R-TEST: " > $R/smoke_v2_test_cmp.log 2>&1; then
  ok "identical to the container's log ($(( $(date +%s) - T0 ))s): $(grep '^V2R-TEST (a)' $R/smoke_v2_test.log); $(grep '^V2R-TEST: ' $R/smoke_v2_test.log)"
else bad "differs from the container's log ($(( $(date +%s) - T0 ))s; $R/smoke_v2_test_cmp.log):"; head -20 $R/smoke_v2_test_cmp.log | tee -a $LOG; fi

say "5. restricted-LP gate: v2restricted v2mode=v2 on the GL5 cert (about 3-10 min)"
T0=$(date +%s)
(cd $E && nice -n 12 python3 pcheck.py v2restricted $F $X $A threads=1 work=$WK gkeys=$KEYS gkwin gkleaf $XFT cert=$CERT xcap=3 v2mode=v2 \
   v2seed=$N/v2r/seed_sol_k86GL5_p1.json v2json=$R/smoke_v2_rlp.json v2out=$R/smoke_v2_rlp_cert.json > $R/smoke_v2_rlp.log 2>&1)
L=$(grep '^V2RESTRICTED v2: t = ' $R/smoke_v2_rlp.log | tail -1)
if [ -n "$L" ] && python3 -c "import sys; t = float(sys.argv[1].split('t = ')[1].split()[0]); sys.exit(0 if abs(t - float(sys.argv[2])) <= 1e-9 else 1)" "$L" "$TV"; then
  ok "$(echo "$L" | cut -c1-140) ($(( $(date +%s) - T0 ))s; container t = $TV)"
else bad "${L:-no V2RESTRICTED line} (want t = $TV within 1e-9; $(( $(date +%s) - T0 ))s; $R/smoke_v2_rlp.log)"; tail -5 $R/smoke_v2_rlp.log | cut -c1-200 | tee -a $LOG; fi
rm -rf $WK

if [ "${SMOKE_V2_HEAD:-1}" != 0 ]; then
  say "6. start of a k86GV1 run (the lane's command, stopped after its patterns are loaded)"
  T0=$(date +%s)
  (
    export STACK=s77 ARGS=$N/args_A97_F_W13K3gB5b.txt KEYS=$N/p1r/cg_keys_r13w16_16fik.txt FAM=full KS=0; unset EGK; . $NN/env86.sh; N=$NN
    XF="c6le f2b7 f2b=$N/rules/A5final/rules_c67fa1d1_plus_A5_twins.json rpatN=$N/rpat/rpatN3_rotation_justified.txt,$N/offc/offc_K3g_2f4f0f02.txt p1r v2r v2seed=$N/v2r/seed_sol_k86GL5_p1.json v2rescan=1 v2inner=4"
    WK=$SD/v2head_$$; mkdir -p $WK; cd $N/eng_v2
    PYTHONUNBUFFERED=1 nice -n 12 python3 pcheck.py solveR2 $F $X keeppen tag=v2smokehead $A $CB warm=$(cat $N/maclane_warm_v2.txt) feas=$N/cand/sol_k85C_in03.json xcap=3 xpen=1e-3 lpmax=45 \
      threads=1 maxit=1 work=$WK gkeys=$KEYS gkwin gkleaf $XF lext lextcert q7pen=1e-3 consk=20 consfrac=0.25 > $R/smoke_v2_head.log 2>&1 &
    P=$!; S=0
    while kill -0 $P 2>/dev/null && [ $S -lt 900 ]; do grep -q '^patterns:' $R/smoke_v2_head.log && break; sleep 1; S=$((S + 1)); done
    kill $P 2>/dev/null; sleep 1; kill -9 $P 2>/dev/null; wait $P 2>/dev/null
    rm -rf $WK; rm -f $N/eng_v2/rows_v2smokehead.txt $N/eng_v2/sol_v2smokehead*.json $N/eng_v2/cert_v2smokehead*.json $N/eng_v2/inject_v2smokehead.*
  )
  NL=$(awk '/^patterns:/{print NR; exit}' $R/ref/v2/smoke_GV1.log)
  if python3 $R/tools/cmp_v2.py $R/ref/v2/smoke_GV1.log $R/smoke_v2_head.log "patterns:" $NL > $R/smoke_v2_head_cmp.log 2>&1; then
    ok "first $NL lines identical to the container's ($(( $(date +%s) - T0 ))s): $(grep '^gkeys: 89' $R/smoke_v2_head.log | cut -c1-40)...; $(grep '^patterns:' $R/smoke_v2_head.log | cut -c1-60)"
  else bad "differs from the container's first $NL lines ($(( $(date +%s) - T0 ))s; $R/smoke_v2_head_cmp.log):"; head -20 $R/smoke_v2_head_cmp.log | tee -a $LOG; fi
fi
say ""
if [ $NF = 0 ]; then say "SMOKE-V2: PASS (log $LOG)"; date -u +%Y-%m-%dT%H:%M:%SZ > $R/smoke_v2.ok; else say "SMOKE-V2: FAIL ($NF failed steps; log $LOG)"; fi
[ $NF = 0 ]
