#!/bin/bash
# maclane v2 add-on stop: stops the v2 lane (outbox first, then the K run).  usage: bash stop_v2.sh   (TAG_V2 overrides k86GV1)
# Results already written stay: outbox/v2lower/, runK_<tag>/K.log, eng_v2/rows_<tag>.txt (warm rows for a restart).
R=/tmp/maclane-k86
N=$R/fs/home/claude/GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp/s86_f2b7
TV=${TAG_V2:-k86GV1}
kill_tree() {   # children first (BSD / GNU pgrep -P)
  local c
  for c in $(pgrep -P $1 2>/dev/null); do kill_tree $c; done
  kill $1 2>/dev/null
}
stop_pat() {
  local p n=0
  for p in $(pgrep -f "$1" 2>/dev/null); do [ "$p" = "$$" ] && continue; kill_tree $p; n=$((n + 1)); done
  [ $n -gt 0 ] && echo "  stopped $n: $1"
  return 0
}
echo "v2 lane $TV:"
stop_pat "outbox86V.sh $TV"; stop_pat "runK86v.sh [0-9]+ [0-9]+ $TV "; stop_pat "tag=$TV "
sleep 2
left=$(pgrep -f "tag=$TV " 2>/dev/null | wc -l | tr -d ' ')
echo "processes of $TV still running: $left"
exit 0
