#!/bin/bash
# maclane v2 add-on build: compile the separators of the engine copy eng_v2 (the v2 lane runs eng_v2/bin/jsepf_gk_k192 for the 89 payer-7
# keys, jsepf_gk and jsep3; about 1 min).  It does not touch eng/ or eng_p1r/ (the running upper / lower lanes use their binaries).
# install_v2.sh runs it; usage: bash build_v2.sh   [env as build.sh: CXX, CXXFLAGS, ARCHFLAG]
# Same compiler flags as build.sh: -std=c++17 -O3 -pthread -ffp-contract=off -include cstdint (+ -mcpu=native when accepted).
# eng_v2's jsepf_gk.cpp and jsepf_gk_k192.cpp are byte-identical to eng_p1r's (the binaries the k86ML1 lane already runs here).
R=/tmp/maclane-k86
N=$R/fs/home/claude/GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp/s86_f2b7
E=$N/eng_v2
[ -f $E/v2r.py ] || { echo "build_v2.sh: $E/v2r.py not found: run install_v2.sh first" >&2; exit 2; }
if [ -z "$CXX" ]; then for c in clang++ c++ g++; do command -v $c > /dev/null 2>&1 && { CXX=$c; break; }; done; fi
CXXFLAGS=${CXXFLAGS:--std=c++17 -O3 -pthread -ffp-contract=off -include cstdint}
if [ -z "${ARCHFLAG+x}" ]; then
  T=${TMPDIR:-/tmp}/maclane_arch_$$; echo 'int main(){return 0;}' > $T.cpp
  if $CXX -mcpu=native -o $T $T.cpp > /dev/null 2>&1; then ARCHFLAG=-mcpu=native; else ARCHFLAG=""; fi; rm -f $T $T.cpp
fi
echo "build_v2: $($CXX --version 2>&1 | head -1); flags $CXXFLAGS $ARCHFLAG"
FAIL=0; T0=$(date +%s); mkdir -p $E/bin
for s in jsep3 jsepf_gk jsepf_gk_k192; do
  if $CXX $CXXFLAGS $ARCHFLAG -o $E/bin/$s.new $E/$s.cpp 2> $E/bin/$s.build.log; then
    mv -f $E/bin/$s.new $E/bin/$s; echo "  ok   eng_v2/bin/$s  <- $s.cpp $( [ -s $E/bin/$s.build.log ] && echo "(warnings: $E/bin/$s.build.log)")"
  else rm -f $E/bin/$s.new; echo "  FAIL eng_v2/bin/$s  <- $s.cpp: see $E/bin/$s.build.log"; FAIL=1; fi
  [ -s $E/bin/$s.build.log ] || rm -f $E/bin/$s.build.log
done
echo "build_v2: $([ $FAIL = 0 ] && echo OK || echo FAILED) in $(( $(date +%s) - T0 )) s"
exit $FAIL
