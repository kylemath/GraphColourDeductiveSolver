"""v2shimcheck.py <engine dir> -- the two shim calls the v2 engine adds, checked without highspy: on random LPs built with addVar / addRow
(t free with cost 1, ranged and one-sided rows, as v2restricted builds them) getLp() must return exactly the stored model (costs, bounds,
row bounds, the column-wise matrix) and solving getLp()'s model with scipy must give run()'s optimum; clearSolver() + run() after added
rows (the v2inner pattern) must give the optimum of a fresh model with the same rows.  The same calls were compared with the real
highspy 1.15.1 in the container (60 LPs, 180 re-solves, 0 failures).  Prints 'V2 SHIM CHECK: PASS' / 'FAIL'."""
import sys, os
import numpy as np, scipy.sparse as sp
from scipy.optimize import linprog
sys.path.insert(0, os.path.abspath(sys.argv[1])); os.environ['HSHIM_QUIET'] = '1'
import hshim
rng = np.random.default_rng(11); bad = 0; maxd = 0.0; inf = hshim.kHighsInf


def model(n, rows, lb, ub):
    h = hshim.Highs(); h.setOptionValue('output_flag', False)
    for j in range(n): h.addVar(lb[j], ub[j])
    h.changeColCost(0, 1.0)
    for lo, hi, idx, val in rows: h.addRow(lo, hi, len(idx), np.array(idx, dtype=np.int32), np.array(val))
    return h


for k in range(40):
    n = int(rng.integers(3, 30)); m = int(rng.integers(2, 40))
    lb = [-inf] + [(-inf if rng.random() < 0.2 else float(rng.uniform(-2, 0))) for _ in range(n - 1)]
    ub = [inf] + [(inf if rng.random() < 0.3 else float(rng.uniform(0.5, 3))) for _ in range(n - 1)]
    rows = []
    for i in range(m):
        idx = sorted(rng.choice(np.arange(1, n), size=min(n - 1, int(rng.integers(1, 5))), replace=False).tolist()) + [0]
        val = [float(v) for v in rng.integers(-3, 4, len(idx) - 1)] + [-1.0]; b = float(rng.uniform(-1, 2)); kind = int(rng.integers(0, 3))
        rows.append((-inf, b, idx, val) if kind == 0 else ((b - 1, inf, idx, val) if kind == 1 else (b - 1.5, b, idx, val)))
    h = model(n, rows, lb, ub); h.run()
    L = h.getLp(); M = L.a_matrix_
    A = sp.csc_matrix((np.array(M.value_), np.array(M.index_), np.array(M.start_)), shape=(L.num_row_, L.num_col_))
    D = np.zeros((m, n))
    for i, (lo, hi, idx, val) in enumerate(rows):
        for j, v in zip(idx, val): D[i, j] += v
    ok = int(M.format_) == 1 and L.num_col_ == n and L.num_row_ == m and np.array_equal(A.toarray(), D)
    ok = ok and np.array_equal(np.array(L.row_lower_), np.array([r[0] for r in rows])) and np.array_equal(np.array(L.row_upper_), np.array([r[1] for r in rows]))
    ok = ok and np.array_equal(np.array(L.col_lower_), np.array(lb)) and np.array_equal(np.array(L.col_upper_), np.array(ub)) and list(L.col_cost_) == [1.0] + [0.0] * (n - 1)
    if not ok: bad += 1; print('lp%d: getLp differs from the stored model' % k); continue
    if h.modelStatusToString(h.getModelStatus()) == 'Optimal':   # getLp's model re-solved with scipy (as v2restricted's cross-check does)
        ru, rl = np.array(L.row_upper_), np.array(L.row_lower_); Ar = A.tocsr()
        Aub = sp.vstack([Ar[np.isfinite(ru)], -Ar[np.isfinite(rl)]]); bub = np.concatenate([ru[np.isfinite(ru)], -rl[np.isfinite(rl)]])
        bnd = [(None if not np.isfinite(a) else a, None if not np.isfinite(b) else b) for a, b in zip(L.col_lower_, L.col_upper_)]
        r2 = linprog(np.array(L.col_cost_), A_ub=Aub, b_ub=bub, bounds=bnd, method='highs')
        d = abs(r2.fun - h.getInfo().objective_function_value) / (1 + abs(r2.fun)); maxd = max(maxd, d)
        if r2.status != 0 or d > 1e-9: bad += 1; print('lp%d: getLp model re-solve %s %.12g vs run %.12g' % (k, r2.status, r2.fun, h.getInfo().objective_function_value))
    for r in range(3):   # v2inner: rows added, clearSolver, run == a fresh model with the same rows
        idx = [1 + int(rng.integers(0, n - 1)), 0]; val = [float(rng.integers(1, 4)), -1.0]; b = float(rng.uniform(-1, 1))
        rows.append((-inf, b, idx, val)); h.addRow(-inf, b, 2, np.array(idx, dtype=np.int32), np.array(val)); h.clearSolver()
        if h.getSolution().value_valid or h.modelStatusToString(h.getModelStatus()) != 'Not Set': bad += 1; print('lp%d.%d: clearSolver kept a solution' % (k, r))
        h.run(); g = model(n, rows, lb, ub); g.run()
        s1, s2 = h.modelStatusToString(h.getModelStatus()), g.modelStatusToString(g.getModelStatus())
        if s1 != s2: bad += 1; print('lp%d.%d: status %s vs fresh %s' % (k, r, s1, s2)); continue
        if s1 == 'Optimal':
            d = abs(h.getInfo().objective_function_value - g.getInfo().objective_function_value); maxd = max(maxd, d)
            if d > 1e-9: bad += 1; print('lp%d.%d: objective %.12g vs fresh %.12g' % (k, r, h.getInfo().objective_function_value, g.getInfo().objective_function_value))
print('[getLp / clearSolver] 40 LPs, 120 re-solves after clearSolver: max objective difference %.2e, %d failures' % (maxd, bad))
print('V2 SHIM CHECK: %s' % ('PASS' if not bad else 'FAIL')); sys.exit(1 if bad else 0)
