#!/bin/bash
# maclane v2 add-on: start the KEYSPEC v2 lower lane k86GV1 (fs/.../s86_f2b7/launch_k86GV1.sh).  It replaces the k86ML1 control lane:
# run  bash stop.sh lower  first.  Knobs: V2_THREADS (2), V2INNER (4), MAXIT (200), TAG (k86GV1), V2_WARM_ML1 (1), ALLOW_ML1, FORCE.
exec bash /tmp/maclane-k86/fs/home/claude/GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp/s86_f2b7/launch_k86GV1.sh
