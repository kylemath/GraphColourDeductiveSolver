#!/bin/bash
# maclane v2 add-on collect: one tarball of what the v2 lane sends back (outbox/v2lower, its K.log and rows file, run.log, the v2 smoke
# logs), written next to the pack folder.  usage: bash collect_v2.sh     -> ../maclane-k86-v2-out-<UTC time>.tgz and its md5
R=/tmp/maclane-k86
N=$R/fs/home/claude/GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp/s86_f2b7
PATH=$R/macshim:$PATH; export PATH
TV=${TAG_V2:-k86GV1}
S=$(date -u +%Y%m%dT%H%MZ); T=$(dirname $R)/maclane-k86-v2-out-$S.tgz; L=$R/collect_v2_list.txt
cd $R
{ [ -d outbox/v2lower ] && echo outbox/v2lower
  for f in smoke_v2.log smoke_v2_hshim.log smoke_v2_test.log smoke_v2_test_cmp.log smoke_v2_rlp.log smoke_v2_rlp.json smoke_v2_head.log smoke_v2_head_cmp.log; do [ -f $f ] && echo $f; done
  for f in $N/run.log $N/runK_$TV/K.log $N/runK_$TV/warmlist.txt $N/eng_v2/rows_$TV.txt $N/eng_v2/sol_${TV}_p1.json $N/logs/runK_$TV.out $N/logs/outbox86V_$TV.out \
           $N/eng_v2/bin/*.build.log; do [ -f $f ] && echo ${f#$R/}; done
} > $L
tar -czf $T -T $L && echo "wrote $T ($(du -k $T | cut -f1) KB, md5 $(md5sum $T | cut -c1-32)): $(wc -l < $L | tr -d ' ') entries"
