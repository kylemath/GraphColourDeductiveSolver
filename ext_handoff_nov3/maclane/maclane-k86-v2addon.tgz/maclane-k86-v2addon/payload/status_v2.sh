#!/bin/bash
# maclane v2 add-on status: the v2 lane (k86GV1): processes, phase-1 / v2inner / iteration lines of K.log, outbox/v2lower/P1.txt, run.log.
# usage: bash status_v2.sh [lines, default 6]      (bash status.sh still shows the upper and lower lanes)
R=/tmp/maclane-k86
N=$R/fs/home/claude/GraphColourDeductiveSolver/backgroundMaterial/planemap-structural/longtable/reducibility/discharge/wheeldis/loop/opus/P_own_lp/s86_f2b7
. $N/maclib.sh
K=${1:-6}; TV=${TAG_V2:-k86GV1}
up() { if pgrep -f "$1" > /dev/null 2>&1; then echo "running"; else echo "-"; fi; }
echo "== maclane v2 $(date -u +%Y-%m-%dT%H:%M:%SZ)  load:$(uptime | sed 's/.*load average[s]*://')  available memory $(memavail_mb) MB"
echo "== V2 LOWER $TV   K run: $(up "tag=$TV ")  outbox: $(up "outbox86V.sh $TV")   (k86ML1 K run: $(up "tag=k86ML1 "))"
if [ -f $N/runK_$TV/K.log ]; then
  grep -E 'lext it [0-9]+: phase 1|v2inner it|CROWDED|^hshim: run|^iter |warm rows admitted|Traceback|Error' $N/runK_$TV/K.log | tail -n $((K * 2)) | cut -c1-220
else echo "  (no K.log yet)"; fi
echo "-- outbox/v2lower/P1.txt (phase-1 certs: NN  md5  t1  it  filed-at), last $K:"
[ -f $R/outbox/v2lower/P1.txt ] && tail -n $K $R/outbox/v2lower/P1.txt
echo
echo "== run.log (last $K)"
[ -f $N/run.log ] && tail -n $K $N/run.log | cut -c1-260
