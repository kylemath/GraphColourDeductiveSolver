# W13 stack for Opus runs (6 Nov 2026, 21:25Z)

The swarm asked at 21:25Z whether the proof stack loads W13's 115 kill patterns. It did not. Before this change, `args_A97_F.txt` (A97 + patched298 + route F) loaded 288 pattern files, with d = 7 at 9,239 patterns (D 18,101, C 598). Adding W13 gives d = 7 9,354, D 18,128 and C 686, so all 27 D and 88 C were new. No W13 C name is held out by exname.

`args_A97_F_W13.txt` (md5 5faa1ad6) is `args_A97_F.txt` plus these four entries:

    pat=<dir>/pat_W13_all_D.out:all      (27 D; = swarm round4/pat_W13_all_D.out, sha256 9a943529d47e)
    cpat=<dir>/pat_W13r2_C.cfast          (48 C; = round2/pat_W13_C.cfast)
    cpat=<dir>/pat_W13r3_C.cfast          (36 C; = round3/pat_W13r3_C.cfast)
    cpat=<dir>/pat_W13r4_C.cfast          (4 C;  = round4/pat_W13r4_C.cfast)

The names in the three .cfast files make up exactly the 88 names of round4/pat_W13_all_C.out (sha256 33e353648741). MD5SUMS covers the copies here. W17 should add the same four entries to the second-engine args for any point from the W13 stack (k86W, k86M).

## Effect on the k86L lower

`lxW13_k86L_0.log` evaluates the k86L it-5 phase-1 cert on the W13 stack:

- W13 kills 62 of the cert's receivers. They carry |w| 0.0525, which is 20.6% of its d = 7 receiver weight.
- With those rows gone the cert is INVALID (-1.56). So the 0.000421 lower is for f2b7 + 140 keys **without** W13 only.

## Runs on this stack

- **k86W (OP-10):** in-out upper from k86B in10, f2b7 + cg_keys_r13 (151 keys). Points will go to `from_opus/s86_k86W/`.
- **k86M (OP-9):** lext pure-t lower on the same family. Certs will go to `from_opus/s86_k86M/`.
- **Carry-over:** uppers from the smaller family (k86B, no W13, 140 keys) remain uppers here, because more kills and extra keys at 0 only lower loads.
