#!/bin/bash
# W17 macpack: compile the four separators the check runs. Standard C++17 library only (no OpenMP, no Boost, no bits/stdc++.h).
# usage: bash /tmp/swarm-W17/build.sh        (CXX=clang++ by default; CXXFLAGS="-std=c++17 -O3" by default)
set -e
B=/tmp/swarm-W17; CXX=${CXX:-clang++}; F=${CXXFLAGS:--std=c++17 -O3}
cd $B/wd && mkdir -p bin
$CXX $F -o bin/sep3 sep3.cpp && cp bin/sep3 bin/sep3f          # Studio pattern separator (wlp3; WLP_SEPF=1 runs it as sep3f)
$CXX $F -o bin/sep3r sep3r.cpp                                  # Studio receiver separator (wlp3r6 builder)
$CXX $F -o bin/sep3r_ak sep3r_ak.cpp                            # first separator of the Python step (calibration, exact six table)
$CXX $F -o bin/sep3r_gk7 $B/code_gk7/sep3r_gk.cpp               # W17 code_gk7 separator: GK keys + f2b7 (the receiver search)
ls -la bin/sep3 bin/sep3f bin/sep3r bin/sep3r_ak bin/sep3r_gk7
