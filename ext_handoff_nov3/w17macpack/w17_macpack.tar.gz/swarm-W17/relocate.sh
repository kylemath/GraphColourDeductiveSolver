#!/bin/bash
# W17 macpack: only needed when the bundle is NOT unpacked as /tmp/swarm-W17. usage: bash relocate.sh /new/root/swarm-W17
# Rewrites every '/tmp/swarm-W17' in the bundle's text files (scripts, code, args, MD5 lists) to the new root.
set -e; N=${1:?new root}; O=/tmp/swarm-W17
cd "$N" && grep -rlI "$O" . | while read f; do sed -i.bak "s#$O#$N#g" "$f" && rm -f "$f.bak"; done; echo "relocated to $N"
