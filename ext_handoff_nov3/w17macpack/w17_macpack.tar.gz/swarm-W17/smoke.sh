#!/bin/bash
# W17 macpack smoke test (~3-4 min, one to three cores): run after build.sh. Rerunnable (each run starts its two tags fresh).
#  (1) PASS run: k86B in11 (2db802ad) on the default family (W13 args, rules_zcons_minus_W18rejects, 151 keys) through the whole pipeline on d = 24..26 only:
#      the Python step (senders, cons2, mrowL, the C++ vs Python self-tests, DP / Karp tail) + 3 separator parts + summary.
#      Must end 'RESULT: PARTIAL PASS'.
#  (2) planted control that must FAIL: same point and family, q[7665657] raised by 1 (kept by the f2b7 7-side mask of the admissible
#      d = 7 row 5776667 / 9567857), separator search restricted to that row: it must be reported above the bound ('F2B7ROWS FAIL').
B=/tmp/swarm-W17; export PATH=$B/macshim:$PATH; S=$B/sol/sol_k86B_in11.json; ok=1; mkdir -p $B/logs
FAM="C6LE=1 NOCLAMP=1 F2B7=1 F2BRULES=${F2BRULES:-$B/tab/rules_zcons_minus_W18rejects.json} ARGSF=$B/args_A97F_W13_x_studio.txt EXPECT_PAT=18128,686,158"
cd $B; rm -rf $B/logs/smoke_pass $B/q/smoke_pass
echo "$(date -u +%H:%M:%SZ) smoke (1): PASS run d = 24..26"
env $FAM GK=$B/tab/cg_keys_r13.txt EXNAME=$B/tab/exname_keep95p131f.txt NPROC=3 NPROCMAX=16 DMAXP=26 DLIST=24,25,26 \
  bash $B/code_gk7/w17_upper.sh $S $B/kill/patched298 smoke_pass > $B/logs/smoke_pass_run.out 2>&1
R1=$(grep -h "^RESULT" $B/logs/smoke_pass/summary.txt 2>/dev/null); echo "  $R1"
case "$R1" in "RESULT: PARTIAL PASS"*) echo "  (1) OK";; *) echo "  (1) NOT OK: see logs/smoke_pass_run.out and logs/smoke_pass/p0.log"; ok=0;; esac
grep -h "^F2B rules" $B/logs/smoke_pass/p0.log | head -1 | cut -c1-220
echo "$(date -u +%H:%M:%SZ) smoke (2): planted control (must FAIL)"
env $FAM SOL=$S TAG=smoke_ctl GKF=$B/tab/cg_keys_r13.txt W17QPLANT=7665657:1 F2B7ROWS=7:5776667:9567857 DLIST=none GKST=0 W10STN=200 \
  bash $B/code_gk7/run_f2b7st.sh > $B/logs/smoke_ctl.log 2>&1
R2=$(grep -h "^VERDICT" $B/logs/smoke_ctl.log); echo "  $R2" | cut -c1-200
case "$R2" in *"F2B7ROWS FAIL"*"reported above the bound"*) echo "  (2) OK (the control failed, as it must)";; *) echo "  (2) NOT OK: the planted row was not caught; see logs/smoke_ctl.log"; ok=0;; esac
echo "$(date -u +%H:%M:%SZ) done"
[ $ok = 1 ] && echo "SMOKE: PASS" || echo "SMOKE: FAIL"
