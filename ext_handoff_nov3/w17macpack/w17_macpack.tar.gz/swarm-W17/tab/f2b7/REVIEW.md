# f2b7 adversarial review (6 Nov 2026)

Reviewer: independent subagent. I read every file named in the task and re-derived the kills. I did not run any pcheck.py solves. Scratch scripts and outputs are in `/tmp/claude-0/-home-claude/501dd3ae-0fa3-53a8-b24b-82020727c8dd/scratchpad/review_f2b7/`.

## Verdict

**Unsound as deployed.** The code change is correct. The rule file it switches on is not.

- **The plumbing is right.** Slot identity, side and direction, offsets, the C++/python agreement and the 2-ball geometry all check out. Nothing in the gate change assumes c, ap <= 6.
- **The rules are not.** The f2b7 gate switches on rules that until now could never fire: 77 d7_w7 rules and 27 d8_w7 rules per side, which fire only where c >= 7 or ap >= 7. No valid derivation I can run reproduces them.
  - The published Studio extractor does not emit them.
  - Our strict full-row embedding test does not justify them, even with a registry of 13,217 configurations. That pool is a superset of keep95p131 in the RSST and nl51 classes; it lacks the 97 Tier A k3x names outside A97 (not on disk) and the 10 k3p configurations.
  - Every one of them is reproduced by a reading that is invalid for a single-slot mask:
    - the kill belongs to A's other private (slot swap);
    - the kill needs A's other private at a fixed letter (a joint kill);
    - the kill needs privates of other link vertices.
- **The k85CL dual uses them.** 41 of the 1,073 7-sides have such a kill, so their masks lose letter 5 without justification.

**Sound given one assumption.** f2b7 becomes sound if it applies only 7-side rules that the strict reading (A) re-derives. Of the rules that can fire on a 7-side, 265 of 349 (d7) and 108 of 135 (d8) per side pass my test. Another 7 d7 rules per side are attributed to a Tier A configuration that is missing from my pool.

## What I checked, and how

1. **Slot identity in the frame.** `extract_full2ball_rules` builds its frame with link `[7] + [5]*(D-1)` and all apexes 6 (`build_upgraded_kills.py:271-377`). I rebuilt that frame with grow.py's `build2` for D = 7 and 8. I also rebuilt it with c = 7 and c- = 8 in the link and with all-6 links (scratch `frame.py`).
   - `('p',0,1)` is always adjacent to `s[D-1]` = s[j-1].
   - `('p',0,2)` is always adjacent to `s[0]` = s[j].
   - `filter_extra_w7` maps side -1 to `('p',0,1)` and side +1 to `('p',0,2)` (`build_upgraded_kills.py:380-387`).
2. **Slot identity in the rule file.** The provenance map `s63_minconf/prov.pkl` comes from the extractor run on Tier A. Every attributed rule in group "1" carries `('p',0,2)`, and every attributed rule in group "-1" carries `('p',0,1)` (scratch `prov_check.py`). The "1" and "-1" groups are exact mirrors under w-offset k -> -k and s-offset j -> -1-j, for d7 and for d8.
3. **Slot identity in the q7 key.** The q7m code builds the key as `qkey((U, w[j+1], s[j], p1, p2, s[j-1], w[j-1]))` (`prelay2.py:222-232`, `f2bglue.py:131-151`). This is A's cyclic neighbourhood, so p1 is next to s[j] and p2 is next to s[j-1], and reversal keeps that pairing.
   - Python: `ms[0]` is side +1 and becomes m1; `ms[1]` is side -1 and becomes m2 (`f2bglue.py:41-58`).
   - C++: `m[0]` is side +1 and `m[1]` is side -1, read through `QTM[...][m[0]][m[1]]`, and `R7B[0]` is filled from `d*_w7_1` (`jsepf_gk.cpp:254-277`, `:544`; `f2bglue.py:126`).
   - The two sides agree.
4. **Hidden geometry.** Can A's private next to the apex be a different vertex when c >= 7 or ap >= 7?
   - In every one of about 1,700 real-geometry tests (rows with c, ap in 5..9), I asserted that the slot's named neighbours are exactly {w_j, its apex, A's other private}. The assertion never failed.
   - By argument, a coincidence or extra adjacency would need a separating 3-, 4- or 5-cycle around A, w[j±1] and the apex. The same argument covers 6-sides; nothing in it depends on c or ap.
5. **Derivation assumptions.** The published extractor has no gate on c or ap.
   - It handles a link vertex w[k] >= 6 by allowing the frame's s[k-1]~s[k] edge and then writing w_req[k] = (6,7,8,9) or (5,) (`:303`, `:327`, `:361`). That treatment is the same for c = 6 and c = 7.
   - It uses exactly one private (`:308`) and an exact centre (`u_exact`).
   - Syntactically, every rule pins the link letter between any two apexes it uses (0 violations). So a kill that is valid in one completion of the row is valid in all of them.
6. **Offsets and direction.** In the file, w offsets run 1..d-1 and s offsets run 0..d-1. (The SPEC's "1..d" is slightly off; it does not matter.)
   - Python matches `w[(j+off)%d]` and `s[(j+off)%d]` (`f2b.py:43-55`).
   - The C++ `f2bExtra` packs `L[2p]` / `L[2p+1]` at `5*off`, and the rule masks use `o % d` (`jsepf_gk.cpp:139-146`).
   - Buckets keyed by (s[i-1], s[i]) fall back to "any" for offsets that are not -1 or 0. No rule is lost.
7. **Spec claims about 7-side rule counts and kills.**
   - The file has 346 d7 and 135 d8 rules per side whose c or apex requirement is >= 7; 3 more d7 rules (c open or {6,7,8,9}) also fire on 7-sides.
   - On the k85CL dual (`s85_k85CL/f2b7_all.json`), the comparison reproduces the SPEC: 1,073 sides, 897 equal, 176 sides where only the rule file kills, 0 sides where we kill a letter the file keeps, every kill letter 5.

## Concrete counterexamples

**Method.** I built the row's true 2-ball with its actual link letters (s16_filter `build`). Every link and apex letter is exact (9 is never exact). The slot is the only free vertex. Every other private is unusable, per strict rule 14'. The registry is s16 `registry()` with donly=0 (RSST D2 + C2cons, 582), plus the A97 k3x names, nl51 (md5 b9bc6e8b), kpriv (14), the 51 RSST configurations with no verdict and the exname-held configurations. That is 13,217 configurations in total; 12,428 remain after exname (scratch `rejust.py`, `ext.py`).

**Calibration of the test.**
- It re-justifies 265 of the 272 outside-attributed live d7 rules. The other 7 rest on Tier A's k3xC `f7_..57575_...55..`, which is not in my pool.
- It re-justifies all 108 attributed d8 rules.
- It re-justifies 135 of the 176 extra sides. For those, "the Studio's registry is larger" is the right explanation.

**Row 1.** d = 7, link 7557757, apex 7576556, j = 0, side +1 (c = 5, ap = 7).
- The rule `(5, w{1:5, 2:5, 6:7}, s{0:7, 1:5, 5:5, 6:6})` (group d7_w7 "1") fires and sets m1 = 30.
- Strict test: no configuration embeds through p1.
- With A's other private p2 also free, the only kills are (p1,p2) = (5,5) [rsst110], (5,6) [rsst123], (6,5) [rsst288], and p2 = 5 alone [rsst252].
- So p1 = 5 with p2 in {7,8,9} is not excluded. The correct mask is m1 = 31.
- Keys wrongly dropped: 7575667, 7575767, 7575867 and 7575967. In the dual, 7575767 carries mrowQ weight -0.0139.

**Row 2 (heaviest).** d = 7, link 5677757, apex 7656555, j = 4, side -1 (c = 7, ap = 6); row weight -0.00577.
- The rule `(5, w{1:5, 2:7, 3:5, 6:7}, s{0:5, 1:5, 2:5, 5:5, 6:6})` fires.
- Strict test: no embedding.
- Joint kills only: (5,5) [rsst023], (5,6) [rsst025], other = 5 [rsst241].
- So p2 = 5 is possible with the other private in {7,8,9}.

**All of them.**
- **41 sides** in 33 rows (row weight -0.0365). Of these, 40 Q payee terms (payee weight -0.0358) lose keys they should keep.
- **Effect on the SPEC's relief figure.** With only the justified kills, figure A falls from 14.45% to 12.37%, and B from 37.1% to 33.4% (scratch `impact.py`).
- **Where the 104 rules per side come from.** For the 77 d7 rules per side:
  - 12 are exactly the published extractor's kills of the other private (a slot swap);
  - 33 need A's other private at a fixed letter;
  - 32 need privates of other link vertices.

  For the 27 d8 rules: 1 swap, 18 and 8 respectively.
- **The published extractor.** Run on my full pool, `extract_full2ball_rules` emits no rule that implies any of the 84 d7 / 27 d8 rules that fail my test (scratch `outside_run.py`). So the SPEC's line "the Studio's extract_full2ball_rules / filter_extra_w7 already emit these" is false for these rules. They come from the Studio's unpublished DERIVE; s63 SCOPE.md:22 already lists 3,163 unattributed rules.
- **Lists:** `unjustified_rules_d7_side+1.json`, `unjustified_rules_d8_side+1.json` and `unjustified_sides.json` in the scratch folder. The -1 side is the mirror.

## Pre-existing, outside f2b7

The same rule file feeds the existing 6-side f2b, via the lQ rows and the q7m masks L3T & ~extra7.
- **In the dual.** 300 of the 841 <=6 sides get an extra7 kill beyond L3T. 6 of those (row weight -0.0028) fail the same strict test (scratch `six_sides.py`).
- **Generic rules.** In a random sample of 40 unattributed <=6 rules, 38 also fail as generic rules. Most are redundant with L3T in practice.

I recommend auditing the rule file as a whole, not only its 7-side part.

## Minor

- **A latent hazard at d = 8.** If q7m and f2b7 were run without `l3qV` containing 8:
  - the python side would skip all q7m masks at d = 8 (`T is None`);
  - the C++ side would still apply the 7-side masks;
  - the C++ leaf would then sit below the row value, and the separator could miss violated rows.

  The current runs have l3qV=7,8: f2bself7.log shows w7d8 fires. Still, an assert would help.
- **The selftest.** `f2bself7.log` PASS shows only that python and C++ agree. It cannot detect wrong rules.

## Fix suggestion

On 7-sides, apply only rules that the strict reading re-derives. Two ways to get them:
- run the published `extract_full2ball_rules` on the keep set, without `filter_extra_w7` (and check that the remaining k3x/k3p configurations are added);
- use per-row kills from an f2ball7-style test with the broad registry.

Alternatively, drop the 77 / 27 rules per side from the f2b7 path. Then re-run k86B/k86L. Their current upper points and certificates belong to the unsound family.

## What I could not check

- **The Studio's DERIVE code.** It is not in the tree. A justifying configuration outside my pool cannot be excluded: the 97 Tier A k3x names beyond A97, the 10 k3p configurations, or any newer Studio configuration. But every failing rule is reproduced by an invalid reading, and none by the published extractor.
- **Reducibility of the configurations themselves.** It is the same premise as the rest of the stack.
- **d = 8 receiver sides in a dual.** I checked the d8 rules only generically (one completion per rule, which is sufficient by item 5). No d = 8 sides appear in f2b7_all.json.
- **The k86B / k86L outputs.**
