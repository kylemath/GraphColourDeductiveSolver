# s86_k86RS: in-out K upper ladder on the proof-stack family (Opus OP-15)

Family: args_A97_F_W13.txt (5faa1ad6; A97 + patched298 + route F + W13 kills) + FAM=full q7 + c6le + generic keys cg_keys_r13.txt (151 keys, fe8a97a7) + f2b7 with f2b=rules_zcons_minus_W18rejects.json (2b362955, 6,016 rules; copy here).
Flags: gkeys=cg_keys_r13.txt gkwin gkleaf c6le f2b7 f2b=rules_zcons_minus_W18rejects.json (on top of the s77 FAM=full stack).

- sol_q53A97q.json (06767b0b): in-point. It is s53/run_A97/sol_q53A97.json (fa4d7844, the f2b-free A97 point, [E2] on A97 8ec00aea) with the q7 / q7m flags set; q is empty, so every q7 value is 0. upper_R_q53A97q.log: UPPER-R2 FEASIBLE at t = 0.098789365409 on this family.
- upper_Rself_k86B_in10.log: f2b selftest on 2b362955 (d = 7, 8, 9, 3000 arrangements each): PASS.
- New k86RS in-points are added here as they pass upperR2 on this family (sol_k86RS_inNN.json + upper_sol_k86RS_inNN.log).
