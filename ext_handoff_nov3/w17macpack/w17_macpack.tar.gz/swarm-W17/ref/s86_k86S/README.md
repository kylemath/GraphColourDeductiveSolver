# k86S: sound upper ladder on the W13 + f7s + 151-key family (Opus, 6 Nov 2026)

**Family**
- Stack: `../W13stack/args_A97_F_W13.txt` (5faa1ad6), which is A97 + patched298 + route F + W13's 27 D and 88 C.
- Rules: full q7 + c6le + gkwin gkleaf + `f2b7`, run with `f2b=../f2b7/rules_studio_keep95p131f_f7s.json` (704c371f).
- Keys: `../f2b7/cg_keys_r13.txt` (151 keys, fe8a97a7).

**Starting points**

k86B in10 and in11 both pass `upperR2` on exactly this family. They were made on the unfiltered relaxation, and the logs here are the rechecks. The ladder starts from in11.

The best value is t <= 0.018178463483 [P]. W17's second-engine check is pending.

**Ladder output**

New points `sol_k86S_inNN` are listed in POINTS.txt after `upperR2` on the same family.
