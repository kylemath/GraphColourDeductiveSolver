# OP-16: face-set (grow.py) embedding audit of the other proof-stack inputs (Opus subagent, 6 Nov 22:20Z - 23:35Z)

Verdict: one input fails the rotation reading: **rpatN3.txt (rpatN=, e153fc41): 46 of 2,287 kill patterns have no rotation-reading witness** in the 12,268-configuration keep pool (all 46 from cut-vertex sources; none covered by another loaded pattern). Everything else is SAFE. [P] single engine (W18 engine.py try_embed, run with python3 -I); please confirm independently (W18 A-3 / Studio ST-8).

| Input | Built by | Matched by | Verdict | Evidence |
|---|---|---|---|---|
| l3q masks tab_+-1 (V7), tabV8_+-1 (V8) | Studio out/job31/l3q_masks.py (git 80287bd3):73, grow.embeddings (grow.py:104-124: faces as vertex sets + induced + exact degrees), keep95p131f | exact key lookup: prelay2.py:355-389, f2bglue.py:41-52, kstar.py:40,74, edge56.py:125 | SAFE [checked] | stack files = Studio reading A (0/5,000 mismatches each); own rebuild 0/10,000; all 68 + 26 embeddings through a2 are rotation embeddings; all 52 Studio requirement sets have a rotation witness; only a2 = 5 is ever killed |
| kill6 U7 / U8 / U9 (incl. KILL7) | st16_filter.py (80287bd3):81, table() :107-138; KILL7 by s77_k6patch/scripts/k6check.py (grow.embeddings) | exact 8-letter index: prelay2.py:24-31; jsepf KM = 31 & ~kill6 (jsepf_gk.cpp:21); edge56.py:115; kstar.py:37,70 | SAFE [checked] | raw md5 7c1fbb7a (base U7) / 5eb52480 (patched U7) / 5ca18d12 (U8 = U9) reproduced; all 394 + 210 + 22 embeddings are rotation embeddings; 1 of the 7 B1 windows has a cut vertex |
| window patterns pat= / cpat= (19,148 names incl. W13, route F, lone) | no containment test: kc line cut at the named positions (gen.py:107-121, ufree.py:55-63, grow.py:126-144, W13 gen3.py), proven directly by dfast / kcc / cfast | dihedral word match pcheck.py:117-160, 199-215 | SAFE | [checked] 4,463/4,463 k3x names (469 with a cut vertex), 601/601 lone; [inferred] W13 and route-F windows (patrot on their kc lines would close this) |
| rpatD.txt (97235725) | Studio loop/studio/rsstD/rsst_rows.py (git 1255834b):74-91, 173-187, face-set; source RSST D2 (72/249 with a cut vertex) | pcheck.py:168-180 | SAFE [checked] | 157 embed their source by rotation; 1 via rsst351 |
| **rpatN3.txt (e153fc41)** | s39o/rpatN_build.py:47-85, face-set, from nl51 (1,677/8,200 with a cut vertex); Studio rpatN_studio.py uses the same reading | pcheck.py:181-190 | **AT RISK [checked]** | 2,142 justified by their source, 99 by another keep configuration, **46 not justified**, 0 of them subsumed by another pattern |
| exname, RSST C2cons keep list, consbasis, keys, f2b, warm / feas | removal only / forbidden-set membership / LP rows / exact table reads / W18 scope / not verified inputs | - | SAFE or N/A | from code |

Worked example: `7 .556.56 ..5..5. # nl2836_r11 c=0`: the centre is a cut vertex with interior blocks (6,5,5) and (5,6) separated by ring gaps; the pattern keeps the first run and reverses the second (the W18 flip around a cut vertex); no other keep configuration embeds there.

Cut-vertex counts in the keep pool (code/cutcount.py, Tarjan articulation points on the interior graphs from pool.jsonl rotations): RSST D2 72/249, RSST C2cons 20/128, k3x D 386/3,096, k3x C 83/590, nl51 1,677/8,200, k3p D 1/4; total 2,239/12,268 (328 with a pendant vertex; none disconnected).

Files: rpatN3_rotation_justified.txt (2,241 patterns + header, md5 8b90a842) = rpatN3 minus the 46; rpatN3_unjustified46.txt; rpatN3_justified_by_other_config.tsv (the 99); code/ (all scripts and logs, incl. k6full*_U7/U8.log md5 matches, run_rpatN3.log, run_rpatD.log).

Consequence (Opus, 7 Nov 01:55Z): every upper that loaded rpatN3 (every A97-based point, incl. sol_q53A97q 0.098789) is rechecked with rpatN=rpatN3_rotation_justified.txt; lowers on rpatN3 stay valid (more kills = relaxation). Opus runs from 01:55Z use the 2,241-pattern file.
