# s86_k86PS: in-out K upper ladder on the proof-stack family (Opus OP-15, from 7 Nov 02:01Z)

Family: args_A97_F_W13.txt (5faa1ad6) + FAM=full q7 + c6le + cg_keys_r13.txt (151 keys, fe8a97a7) + f2b7 f2b=rules_zcons_minus_W18rejects.json (2b362955) + **rpatN=rpatN3_rotation_justified.txt (8b90a842; rpatN3 minus the 46 patterns with no rotation witness, from_opus/growpy_audit/REPORT.md)**. Copies of both files here.

- sol_q66_q.json: in-point = s33z/run_A67/sol_q66.json (t = 0.128957775395, [E2] on A67 2c97e14d, 20 Oct; l3q only: uses no f2b rule and no rpatN pattern) with the q7/q7m flags set (q empty). upper_P_q66_q.log: UPPER-R2 FEASIBLE at 0.128957775395 on this family. So **t* <= 0.128958 [P]** on the proof-stack family.
- sol_q53A97q (0.098789) is INFEASIBLE on this family (181 violated rows, d = 7..9, max excess 0.1233; it relied on the 46 rpatN3 patterns).
- New k86PS in-points are added here as they pass upperR2 on this family (POINTS.txt).
- 02:04Z: sol_q66_q is also FEASIBLE at 0.128957775395 with NO rpatN pattern at all (rpatN=rpatN_empty.txt, upper_P0_q66_q.log), so this upper does not depend on rpatN: any further rpatN drops leave it standing.
- 02:08Z: the ladder restarted on rpatN=rpatN3_rot60.txt (4b605ce9, 2,227 patterns = rpatN3 minus the Studio ST-10 full-pool 60 = 8b90a842 minus 14); sol_q66_q FEASIBLE there too (upper_P6_q66_q.log). All k86PS points from now are on this file.
- 02:09Z: Studio ST-10 now agrees exactly with OP-16 (46 dropped, 2,241 kept = 8b90a842, main bc36e8eb); the ladder restarted on 8b90a842 (same as k86PL). rpatN3_rot60.txt kept here for reference only.
